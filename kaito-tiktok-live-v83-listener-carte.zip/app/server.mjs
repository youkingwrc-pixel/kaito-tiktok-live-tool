import http from "node:http";
import https from "node:https";
import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { fileURLToPath, pathToFileURL } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = 8787;
const HOST = "127.0.0.1";
const execFileAsync = promisify(execFile);
const MAC_SETTINGS_PATH = path.join(__dirname, "mac-settings.json");
let macLidSleepDisabled = false;
const VOICEVOX_DEFAULT_URL = "http://127.0.0.1:50021";
const TIKTOK_SETTINGS_PATH = path.join(__dirname, "tiktok-settings.json");
function loadTikTokUsername() {
  try {
    if (!fs.existsSync(TIKTOK_SETTINGS_PATH)) return "";
    const d = JSON.parse(fs.readFileSync(TIKTOK_SETTINGS_PATH, "utf8"));
    return String(d?.username || "").replace(/^@/, "").trim();
  } catch { return ""; }
}
function saveTikTokUsername(username) {
  fs.writeFileSync(TIKTOK_SETTINGS_PATH, JSON.stringify({username}, null, 2));
}
async function resolveOwnTikTokIdentity(username){
  const clean=normalizedTikTokId(username);
  if(!clean) return null;
  try {
    const params=new URLSearchParams({
      aid:"1988", app_name:"tiktok_web", device_platform:"web_pc",
      app_language:"ja", browser_language:"ja-JP", region:"JP",
      user_is_login:"false", sourceType:"54", staleTime:"600000", uniqueId:clean
    });
    const resp=await fetch(`https://www.tiktok.com/api-live/user/room?${params}`,{
      headers:{"User-Agent":"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/139 Safari/537.36"}
    });
    if(!resp.ok) return null;
    const body=await resp.json();
    const u=body?.data?.user;
    const id=String(u?.id??u?.userId??u?.user_id??u?.user_id_str??"").trim();
    const unique=normalizedTikTokId(u?.uniqueId??u?.unique_id??u?.unique_id_str??clean);
    if(!id) return null;
    OWN_USER_ID=id; OWN_UNIQUE_ID=unique||clean;
    return {id,uniqueId:OWN_UNIQUE_ID};
  } catch { return null; }
}
let USERNAME = loadTikTokUsername();
let OWN_USER_ID = "";
let OWN_UNIQUE_ID = USERNAME;
let activeTikTokClient = null;
const SOUND_CONFIG_PATH = path.join(__dirname, "gift-voice-profiles.json");
const PROFILE_NAMES_PATH = path.join(__dirname, "gift-voice-profile-names.json");
const GIFT_MEMOS_PATH = path.join(__dirname, "gift-memos.json");
const AUDIO_DIR = path.join(__dirname, "public", "custom-audio", "gifts");
const EMOTE_CONFIG_PATH = path.join(__dirname, "emote-se-profiles.json");
const EMOTE_DEBUG_LOG_PATH = path.join(__dirname, "emote-debug.jsonl");
function emoteDebug(label, data){ try { fs.appendFileSync(EMOTE_DEBUG_LOG_PATH, JSON.stringify({time:new Date().toISOString(),label,data})+"\n"); } catch {} }
const SOCIAL_SE_CONFIG_PATH = path.join(__dirname, "social-se-profiles.json");
const LIVE_HISTORY_PATH = path.join(__dirname, "live-history.json");
const BATTLE_HISTORY_PATH = path.join(__dirname, "battle-history.json");
const GLOVE_RECORDS_PATH = path.join(__dirname, "glove-records.json");
const GLOVE_LOGS_PATH = path.join(__dirname, "glove-logs.json");
const MONTHLY_USER_STATS_PATH = path.join(__dirname, "monthly-user-stats.json");
const CUMULATIVE_USER_STATS_PATH = path.join(__dirname, "cumulative-user-stats.json");
const LISTENER_HISTORY_PATH = path.join(__dirname, "listener-history.json");
const LISTENER_PROFILE_PATH = path.join(__dirname, "listener-profiles.json");
const COMMENT_RETENTION_DAYS = 90;
function loadListenerProfiles(){try{if(!fs.existsSync(LISTENER_PROFILE_PATH)){fs.writeFileSync(LISTENER_PROFILE_PATH,JSON.stringify({},null,2));return {};}const raw=JSON.parse(fs.readFileSync(LISTENER_PROFILE_PATH,"utf8"));return raw&&typeof raw==="object"?raw:{};}catch{return {};}}
let listenerProfiles=loadListenerProfiles();
let listenerProfileSaveTimer=null;
function saveListenerProfiles(){if(listenerProfileSaveTimer)return;listenerProfileSaveTimer=setTimeout(()=>{listenerProfileSaveTimer=null;try{fs.writeFileSync(LISTENER_PROFILE_PATH,JSON.stringify(listenerProfiles,null,2));}catch{}},500);}
function blankListenerProfile(id,name="誰か"){return {id:String(id),name:String(name||"誰か"),nickname:"",gender:"",genderIdentity:"",birthDate:"",birthday:"",age:"",birthplace:"",residence:"",job:"",maritalStatus:"",children:"",collab:"",notes:"",sources:{},updatedAt:""};}
function getListenerProfile(id,name){const key=String(id||"").trim();if(!key)return null;if(!listenerProfiles[key])listenerProfiles[key]=blankListenerProfile(key,name);const p=listenerProfiles[key];p.id=key;if(name&&(!p.name||p.name==="誰か"))p.name=String(name);return p;}
function saveProfileField(id,name,field,value,source="manual"){const p=getListenerProfile(id,name);if(!p||!Object.prototype.hasOwnProperty.call(p,field))return p;p[field]=String(value??"").trim();p.updatedAt=new Date().toISOString();if(source){if(!p.sources)p.sources={};p.sources[field]={type:source,updatedAt:p.updatedAt};}saveListenerProfiles();return p;}
function extractListenerProfile(id,name,text){const t=String(text||"").trim();if(!t)return;const p=getListenerProfile(id,name);let m;
  m=t.match(/(?:出身(?:地)?)(?:は|：|:)??\s*(.+?)(?:です|だよ|だ|$)/i);if(m)saveProfileField(id,name,"birthplace",m[1],"comment");
  m=t.match(/(?:今|現在)(?:は|、)?\s*(.+?)(?:に)?住んで(?:います|ます|る)/i)||t.match(/住んでいる(?:場所)?(?:は|：|:)??\s*(.+?)(?:です|だよ|だ|$)/i);if(m)saveProfileField(id,name,"residence",m[1],"comment");
  m=t.match(/(?:仕事|職業)(?:は|が|：|:)??\s*(.+?)(?:です|だよ|だ|$)/i);if(m)saveProfileField(id,name,"job",m[1],"comment");
  m=t.match(/(?:今年|年齢)(?:は)?\s*(\d{1,3})\s*歳/i);if(m)saveProfileField(id,name,"age",m[1],"comment");
  m=t.match(/(?:誕生日|誕生月)(?:は|が|：|:)??\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日/i);if(m)saveProfileField(id,name,"birthday",`${m[1]}月${m[2]}日`,"comment");
  m=t.match(/(?:子ども|子供)(?:は)?\s*(\d+)\s*人/i);if(m)saveProfileField(id,name,"children",m[1],"comment");
  if(/独身/.test(t))saveProfileField(id,name,"maritalStatus","独身","comment");else if(/(?:既婚|結婚して)/.test(t))saveProfileField(id,name,"maritalStatus","既婚","comment");
  m=t.match(/(?:ジェンダー|性自認)(?:は|：|:)??\s*(.{1,30}?)(?:です|だよ|だ|$)/i);if(m)saveProfileField(id,name,"genderIdentity",m[1],"comment");
  m=t.match(/(?:性別)(?:は|：|:)??\s*(.{1,20}?)(?:です|だよ|だ|$)/i);if(m)saveProfileField(id,name,"gender",m[1],"comment");
  m=t.match(/(?:私は|自分は)\s*(MTF|FTM|ノンバイナリー|トランスジェンダー|男性|女性)/i);if(m)saveProfileField(id,name,"genderIdentity",m[1],"comment");
  if(/(?:コラボ|コラボした|コラボ済み)/.test(t))saveProfileField(id,name,"collab","あり","comment");}
function pruneListenerComments(x){const cutoff=Date.now()-COMMENT_RETENTION_DAYS*86400000;if(!Array.isArray(x.comments))x.comments=[];x.comments=x.comments.filter(c=>{const t=Date.parse(c?.time||"");return !Number.isFinite(t)||t>=cutoff;}).slice(0,200);}
const BIRTHDAY_PATH = path.join(__dirname, "birthday-users.json");
const BIRTHDAY_AUDIO_DIR = path.join(__dirname, "public", "custom-audio", "birthday");
fs.mkdirSync(BIRTHDAY_AUDIO_DIR, { recursive: true });
function loadBirthdays(){
  try {
    if(!fs.existsSync(BIRTHDAY_PATH)){ fs.writeFileSync(BIRTHDAY_PATH, JSON.stringify({}, null, 2)); return {}; }
    const raw=JSON.parse(fs.readFileSync(BIRTHDAY_PATH,"utf8"));
    const out={};
    for(const [id,v] of Object.entries(raw||{})){
      const month=Math.floor(Number(v?.month)||0), day=Math.floor(Number(v?.day)||0);
      if(month>=1&&month<=12&&day>=1&&day<=31) out[String(id)]={id:String(id),name:String(v?.name||"誰か"),month,day,updatedAt:String(v?.updatedAt||"")};
    }
    return out;
  } catch { return {}; }
}
let birthdayUsers=loadBirthdays();
const birthdayNotifiedToday=new Set();
function saveBirthdays(){fs.writeFileSync(BIRTHDAY_PATH,JSON.stringify(birthdayUsers,null,2));}
function birthdayTodayMonthDay(){const p=new Intl.DateTimeFormat("ja-JP",{timeZone:"Asia/Tokyo",month:"numeric",day:"numeric"}).formatToParts(new Date());let m=0,d=0;for(const x of p){if(x.type==="month")m=Number(x.value);if(x.type==="day")d=Number(x.value);}return {month:m,day:d};}
function parseBirthday(text){
  const s=String(text||"").trim().replace(/\s+/g,"");
  const m=s.match(/^誕生日(?:は)?(\d{1,2})月(\d{1,2})日$/i);
  if(!m) return null;
  const month=Number(m[1]), day=Number(m[2]);
  if(month<1||month>12||day<1||day>31) return null;
  const max=[31,29,31,30,31,30,31,31,30,31,30,31][month-1];
  if(day>max) return null;
  return {month,day};
}
function birthdayUserId(d,sender){
  const u=d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData ?? {};
  return String(u?.id ?? u?.uid ?? u?.userId ?? u?.user_id ?? u?.uniqueId ?? u?.unique_id ?? d?.userId ?? d?.user_id ?? sender).trim() || sender;
}
function birthdaySnapshot(){return Object.values(birthdayUsers).sort((a,b)=>a.month-b.month||a.day-b.day||a.name.localeCompare(b.name,"ja"));}
fs.mkdirSync(AUDIO_DIR, { recursive: true });

function loadVoiceConfig() {
  try {
    if (!fs.existsSync(SOUND_CONFIG_PATH)) {
      fs.writeFileSync(SOUND_CONFIG_PATH, JSON.stringify({}, null, 2));
      return {};
    }
    const raw = JSON.parse(fs.readFileSync(SOUND_CONFIG_PATH, "utf8"));
    const out = {};
    for (const [gift, value] of Object.entries(raw || {})) {
      const name = String(gift).trim();
      if (!name) continue;
      // Migrate the previous single-sound format to an array.
      if (Array.isArray(value)) {
        out[name] = value.filter(x => x && x.url).map(x => ({
          url: String(x.url),
          name: String(x.name || "sound"),
          volume: Math.max(0, Math.min(1, Number(x.volume ?? 1)))
        }));
      } else if (value?.url) {
        out[name] = [{ url: String(value.url), name: String(value.name || "sound"), volume: Math.max(0, Math.min(1, Number(value.volume ?? 1))) }];
      }
    }
    return out;
  } catch {
    return {};
  }
}

const GIFT_VOICE_EVERY_PATH = path.join(__dirname, "gift-voice-every.json");
function loadGiftVoiceEvery(){ try {
  if(!fs.existsSync(GIFT_VOICE_EVERY_PATH)) fs.writeFileSync(GIFT_VOICE_EVERY_PATH, JSON.stringify({},null,2));
  const raw=JSON.parse(fs.readFileSync(GIFT_VOICE_EVERY_PATH,"utf8")); const out={};
  for(const [profile,val] of Object.entries(raw||{})){ out[profile]={}; for(const [gift,x] of Object.entries(val||{})){ out[profile][gift]={every:Math.max(1,Math.floor(Number(x?.every)||1)),remainder:Math.max(0,Math.floor(Number(x?.remainder)||0))}; } }
  return out;
 }catch{return {}} }
let giftVoiceEvery=loadGiftVoiceEvery();
function saveGiftVoiceEvery(){try{fs.writeFileSync(GIFT_VOICE_EVERY_PATH,JSON.stringify(giftVoiceEvery,null,2));}catch(e){log(`⚠️ ギフトSE回数設定保存失敗: ${e?.message||e}`);}}
function giftVoiceEveryKey(gift){return giftInternalNameForSetting(gift)||String(gift||"").trim();}
function getGiftVoiceEvery(profile,gift){const map=giftVoiceEvery[profile]||{};const key=giftVoiceEveryKey(gift);const x=map[key]||map[String(gift||"").trim()];return {every:Math.max(1,Math.floor(Number(x?.every)||1)),remainder:Math.max(0,Math.floor(Number(x?.remainder)||0)),key};}
function setGiftVoiceEvery(profile,gift,every){if(!giftVoiceEvery[profile])giftVoiceEvery[profile]={};const key=giftVoiceEveryKey(gift);const old=giftVoiceEvery[profile][key]||{};const nextEvery=Math.max(1,Math.floor(Number(every)||1));giftVoiceEvery[profile][key]={every:nextEvery,remainder:Number(old.every)===nextEvery?Math.max(0,Math.floor(Number(old.remainder)||0)):0};saveGiftVoiceEvery();return giftVoiceEvery[profile][key];}

let profiles = loadProfiles();

function loadGiftMemos() {
  try {
    if (!fs.existsSync(GIFT_MEMOS_PATH)) {
      fs.writeFileSync(GIFT_MEMOS_PATH, JSON.stringify({}, null, 2));
      return {};
    }
    const raw = JSON.parse(fs.readFileSync(GIFT_MEMOS_PATH, "utf8"));
    const out = {};
    for (const [pid, memos] of Object.entries(raw || {})) {
      out[pid] = {};
      for (const [gift, memo] of Object.entries(memos || {})) {
        const text = String(memo ?? "").replace(/\r?\n/g, " ").trim().slice(0, 120);
        if (text) out[pid][String(gift)] = text;
      }
    }
    return out;
  } catch { return {}; }
}
function saveGiftMemos() { fs.writeFileSync(GIFT_MEMOS_PATH, JSON.stringify(giftMemos, null, 2)); }
let giftMemos = loadGiftMemos();
function activeGiftMemos() { return giftMemos[activeProfile] || {}; }

let profileNames = loadProfileNames();

function loadProfiles() {
  try {
    if (!fs.existsSync(SOUND_CONFIG_PATH)) {
      const empty = {live1:{}, live2:{}, live3:{}};
      fs.writeFileSync(SOUND_CONFIG_PATH, JSON.stringify(empty, null, 2));
      return empty;
    }
    const raw = JSON.parse(fs.readFileSync(SOUND_CONFIG_PATH, "utf8"));
    let out;
    if (raw && !raw.live1 && !raw.live2 && !raw.live3 && !raw.live4) {
      out = { live1: raw || {} };
    } else {
      out = (raw && typeof raw === "object") ? raw : {};
    }
    // ライブ名ファイルに存在するライブも、SE設定がまだ空なら共有先として扱えるよう
    // 空のライブ設定を自動生成する。旧バージョンで profileNames だけ残っている場合も復旧する。
    try {
      if (fs.existsSync(PROFILE_NAMES_PATH)) {
        const names = JSON.parse(fs.readFileSync(PROFILE_NAMES_PATH, "utf8"));
        for (const id of Object.keys(names || {})) {
          if (/^live\d+$/.test(String(id)) && !out[id]) out[id] = {};
        }
      }
    } catch {}
    for (const id of ["live1","live2","live3"]) if (!out[id]) out[id] = {};
    return out;
  } catch {
    return {live1:{}, live2:{}, live3:{}};
  }
}
function loadEmoteProfiles() {
  try {
    if (!fs.existsSync(EMOTE_CONFIG_PATH)) return {live1:{},live2:{},live3:{}};
    const raw=JSON.parse(fs.readFileSync(EMOTE_CONFIG_PATH,"utf8"));
    const out={};
    for(const [pid, cfg] of Object.entries(raw||{})){
      out[pid]={};
      for(const [id,val] of Object.entries(cfg||{})){
        if(Array.isArray(val)) out[pid][id]=val.filter(x=>x&&x.url).map(x=>({
          url:String(x.url), name:String(x.name||"sound"),
          volume:Math.max(0,Math.min(1,Number(x.volume??1)))
        }));
      }
    }
    return out;
  } catch { return {live1:{},live2:{},live3:{}}; }
}
function saveEmoteProfiles(){ fs.writeFileSync(EMOTE_CONFIG_PATH, JSON.stringify(emoteProfiles,null,2)); }
let emoteProfiles=loadEmoteProfiles();
function activeEmoteConfig(){ return emoteProfiles[activeProfile] || {}; }

function normalizeSocialConfig(cfg) {
  const out = { likeThreshold: 1000, likeSounds: [], followSounds: [] };
  if (!cfg || typeof cfg !== "object") return out;
  const threshold = Number(cfg.likeThreshold);
  if (Number.isFinite(threshold) && threshold >= 1) out.likeThreshold = Math.max(1, Math.floor(threshold));
  for (const key of ["likeSounds","followSounds"]) {
    if (Array.isArray(cfg[key])) {
      out[key] = cfg[key].filter(x => x && x.url).map(x => ({
        url: String(x.url),
        name: String(x.name || "sound"),
        volume: Math.max(0, Math.min(1, Number(x.volume ?? 1))),
        enabled: x.enabled !== false
      }));
    }
  }
  return out;
}
function loadSocialProfiles() {
  const empty = { live1:{likeThreshold:1000,likeSounds:[],followSounds:[]}, live2:{likeThreshold:1000,likeSounds:[],followSounds:[]}, live3:{likeThreshold:1000,likeSounds:[],followSounds:[]} };
  try {
    if (!fs.existsSync(SOCIAL_SE_CONFIG_PATH)) {
      fs.writeFileSync(SOCIAL_SE_CONFIG_PATH, JSON.stringify(empty, null, 2));
      return empty;
    }
    const raw = JSON.parse(fs.readFileSync(SOCIAL_SE_CONFIG_PATH, "utf8"));
    const out = {};
    for (const [pid, cfg] of Object.entries(raw || {})) out[pid] = normalizeSocialConfig(cfg);
    for (const id of Object.keys(profiles)) if (!out[id]) out[id] = normalizeSocialConfig({});
    return out;
  } catch { return empty; }
}
function saveSocialProfiles(){ fs.writeFileSync(SOCIAL_SE_CONFIG_PATH, JSON.stringify(socialProfiles, null, 2)); }
let socialProfiles = loadSocialProfiles();
function activeSocialConfig(){ return socialProfiles[activeProfile] || normalizeSocialConfig({}); }

function loadProfileNames() {
  try {
    const raw = fs.existsSync(PROFILE_NAMES_PATH)
      ? JSON.parse(fs.readFileSync(PROFILE_NAMES_PATH, "utf8"))
      : {};
    const out = {};
    for (const id of Object.keys(profiles)) {
      const n = Number(String(id).replace(/^live/, ""));
      out[id] = String(raw?.[id] || `ライブ${Number.isFinite(n) ? n : id}`);
    }
    if (!Object.keys(out).length) {
      out.live1="ライブ1"; out.live2="ライブ2"; out.live3="ライブ3";
    }
    return out;
  } catch {
    const out = {};
    for (const id of Object.keys(profiles)) out[id]=id;
    return out;
  }
}
function saveProfiles() {
  fs.writeFileSync(SOUND_CONFIG_PATH, JSON.stringify(profiles, null, 2));
}
function saveProfileNames() {
  fs.writeFileSync(PROFILE_NAMES_PATH, JSON.stringify(profileNames, null, 2));
}

function userName(d) {
  const u = d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData;
  return u?.nickname ?? u?.uniqueId ?? u?.unique_id ?? u?.unique_id_str ??
         u?.displayName ?? d?.nickname ?? d?.uniqueId ?? d?.unique_id ?? "誰か";
}

function broadcast(data) {
  const text = `data: ${JSON.stringify(data)}\n\n`;
  for (const res of browserClients) {
    try { res.write(text); } catch {}
  }
}

// 🎵 音声イベントはカウントダウン画面が開いている場合、
// メイン画面とカウントダウン画面の両方で再生すると二重再生になるため、
// カウントダウン側だけへ送る。カウントダウンが閉じている場合は従来通り全画面へ送る。
function broadcastVoiceEvent(data) {
  const text = `data: ${JSON.stringify(data)}\n\n`;
  const gameClients = new Set([...countdownClients, ...timerClients, ...bingoClients]);
  // ゲーム画面を開いている間は、ギフト音声をゲーム画面側だけへ送る。
  // ゲームが開いていない場合のみホーム画面で再生する。
  const targets = gameClients.size ? gameClients : browserClients;
  for (const res of targets) { try { res.write(text); } catch {} }
}

let pendingLogLines=[];
let logBroadcastTimer=null;
function log(message) {
  const line = `[${new Date().toLocaleTimeString("ja-JP")}] ${message}`;
  console.log(line);
  pendingLogLines.push(line);
  if(logBroadcastTimer) return;
  logBroadcastTimer=setTimeout(()=>{
    logBroadcastTimer=null;
    const lines=pendingLogLines.splice(0,pendingLogLines.length);
    for(const item of lines) broadcast({ type:"log", message:item });
  },120);
}

function loadLiveHistory(){
  try {
    if(!fs.existsSync(LIVE_HISTORY_PATH)){ fs.writeFileSync(LIVE_HISTORY_PATH, JSON.stringify([], null, 2)); return []; }
    const raw=JSON.parse(fs.readFileSync(LIVE_HISTORY_PATH,"utf8"));
    return Array.isArray(raw)?raw:[];
  } catch { return []; }
}
function saveLiveHistoryItem(){
  if(!liveStartedAt || liveSessionSaved) return false;
  const hasData = totalComments>0 || totalFollows>0 || totalGiftCount>0 || receivedLikeTotal>0 || viewerStats.size>0;
  if(!hasData) return false;
  const endedAt=Date.now();
  const snap=dashboardSnapshot();
  const item={
    id:`${liveStartedAt}-${endedAt}`, username:USERNAME, startedAt:liveStartedAt, endedAt, durationMs:Math.max(0,endedAt-liveStartedAt),
    totalLikes:snap.totalLikes, receivedLikes:snap.receivedLikes, viewers:snap.viewers, totalGiftCount:snap.totalGiftCount, totalGiftValue:snap.totalGiftValue, totalComments:snap.totalComments, totalFollows:snap.totalFollows,
    likeRanking:snap.likeRanking.slice(0,30), giftRanking:snap.giftRanking.slice(0,30), commentRanking:snap.commentRanking.slice(0,30), entryRanking:snap.entryRanking.slice(0,30), viewerRanking:snap.viewerRanking.slice(0,30), giftTypes:snap.giftTypes.slice(0,30), logs:snap.logs.slice(0,300)
  };
  const history=loadLiveHistory(); history.unshift(item); if(history.length>50) history.length=50; fs.writeFileSync(LIVE_HISTORY_PATH,JSON.stringify(history,null,2));
  liveSessionSaved=true;
  return true;
}
let liveSessionSaved=false;

let currentBattle = null;
function loadBattleHistory(){
  try{
    if(!fs.existsSync(BATTLE_HISTORY_PATH)){ fs.writeFileSync(BATTLE_HISTORY_PATH, JSON.stringify([], null, 2)); return []; }
    const raw=JSON.parse(fs.readFileSync(BATTLE_HISTORY_PATH,"utf8"));
    return Array.isArray(raw)?raw:[];
  }catch{return [];}
}

function loadGloveRecords(){
  try{
    if(!fs.existsSync(GLOVE_RECORDS_PATH)){fs.writeFileSync(GLOVE_RECORDS_PATH,JSON.stringify([],null,2));return [];}
    const raw=JSON.parse(fs.readFileSync(GLOVE_RECORDS_PATH,"utf8"));
    return Array.isArray(raw)?raw:[];
  }catch{return [];}
}
function saveGloveRecords(rows){fs.writeFileSync(GLOVE_RECORDS_PATH,JSON.stringify(rows,null,2));}
function loadGloveLogs(){
  try{
    if(!fs.existsSync(GLOVE_LOGS_PATH)){fs.writeFileSync(GLOVE_LOGS_PATH,JSON.stringify([],null,2));return [];}
    const raw=JSON.parse(fs.readFileSync(GLOVE_LOGS_PATH,"utf8"));
    return Array.isArray(raw)?raw:[];
  }catch{return [];}
}
function saveGloveLogs(rows){if(rows.length>1000) rows=rows.slice(0,1000); fs.writeFileSync(GLOVE_LOGS_PATH,JSON.stringify(rows,null,2));}
function gloveOwnerKey(name){return String(name||"").trim().toLowerCase().replace(/\s+/g," ");}
function addGloveLog(action,name,quantity,note=""){const logs=loadGloveLogs();logs.unshift({id:`glog-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,action,name,quantity:Number(quantity)||0,note,at:Date.now()});saveGloveLogs(logs);}
function expireGloves(){
  const now=Date.now(); const rows=loadGloveRecords(); let changed=false;
  for(const row of rows){
    const recorded=Number(row.recordedAt||now);
    const desiredExpiry=recorded+5*24*60*60*1000;
    if(Number(row.expiresAt||0)!==desiredExpiry){ row.expiresAt=desiredExpiry; changed=true; }
    const expiry=Number(row.expiresAt||0);
    if(expiry<=now && Number(row.quantity||0)>0){
      const qty=Number(row.quantity||0); row.quantity=0; changed=true;
      addGloveLog("expire",row.name,qty,"記録から5日経過");
    }
  }
  if(changed) saveGloveRecords(rows);
  return rows;
}
function aggregateGloves(search=""){
  const rows=expireGloves(); const map=new Map(); const q=String(search||"").trim().toLowerCase();
  for(const row of rows){
    const qty=Math.max(0,Number(row.quantity)||0); if(qty<=0) continue;
    const key=gloveOwnerKey(row.name); if(!key) continue;
    if(q && !String(row.name||"").toLowerCase().includes(q) && !String(row.uniqueId||"").toLowerCase().includes(q) && !String(row.note||"").toLowerCase().includes(q)) continue;
    const cur=map.get(key)||{ownerKey:key,name:row.name,uniqueId:row.uniqueId||"",quantity:0,updatedAt:0,note:"",expiresAt:0};
    cur.quantity+=qty;
    cur.updatedAt=Math.max(cur.updatedAt,Number(row.recordedAt)||0);
    const expiry=Number(row.expiresAt||0);
    // 同じ所有者に複数回追加された場合は、残っているグローブのうち
    // 「最も早く切れる有効期限」を表示する。
    if(expiry>0 && (!cur.expiresAt || expiry<cur.expiresAt)) cur.expiresAt=expiry;
    if(!cur.uniqueId&&row.uniqueId)cur.uniqueId=row.uniqueId; if(row.note)cur.note=row.note; map.set(key,cur);
  }
  return [...map.values()].sort((a,b)=>b.quantity-a.quantity||a.name.localeCompare(b.name,"ja"));
}
function saveBattleHistoryItem(item){
  const history=loadBattleHistory(); history.unshift(item); if(history.length>500) history.length=500;
  fs.writeFileSync(BATTLE_HISTORY_PATH, JSON.stringify(history,null,2));
}
function battleCollection(value){
  if(Array.isArray(value)) return value.map((v,i)=>({value:v,key:String(i)}));
  if(value && typeof value === "object") return Object.entries(value).map(([key,v])=>({value:v,key:String(key)}));
  return [];
}
function battleUserFromAny(v){
  if(!v || typeof v!=="object") return null;
  if(v.user && typeof v.user==="object") return v.user;
  if(v.member && typeof v.member==="object") return v.member;
  if(v.host && typeof v.host==="object") return v.host;
  return v;
}
function battleParticipantNames(data){
  const out=[];
  const add=(u, hostId=null)=>{
    u=battleUserFromAny(u); if(!u || typeof u!=="object") return;
    const id=String(u.id??u.uid??u.userId??u.user_id??hostId??"").trim();
    let uniqueId=String(u.uniqueId??u.unique_id??u.unique_id_str??u.uniqueIdStr??u.displayId??u.display_id??"").replace(/^@/,"").trim();
    let name=String(u.nickname||u.displayName||u.display_name||uniqueId||"参加者");
    // 配信者自身はuniqueIdが省略されたbattle payloadでも、接続IDと
    // 事前取得した数値ユーザーIDで確実に識別する。
    if((OWN_USER_ID && id===String(OWN_USER_ID)) || (OWN_USER_ID && hostId!=null && String(hostId)===String(OWN_USER_ID))){
      uniqueId=OWN_UNIQUE_ID||USERNAME;
      name=name && name!=="参加者" ? name : (OWN_UNIQUE_ID||USERNAME);
    }
    if(!id && !uniqueId) return;
    const existing=out.find(x=>(uniqueId && normalizedTikTokId(x.uniqueId)===normalizedTikTokId(uniqueId)) || (id && String(x.id)===id));
    if(existing){
      if(hostId && (!existing.id || existing.id===existing.uniqueId)) existing.id=String(hostId);
      if(uniqueId && !existing.uniqueId) existing.uniqueId=uniqueId;
      if(name && (!existing.name || existing.name==="参加者")) existing.name=name;
      return;
    }
    out.push({id:id||String(hostId||""),name,uniqueId});
  };
  for(const entry of battleCollection(data?.battleUsers)){
    const x=entry.value;
    const hostId=x?.hostUserId??x?.hostId??entry.key;
    add(x?.battleGroup?.user,hostId);
    add(x?.user,hostId);
    add(x?.userInfo,hostId);
    add(x,hostId);
  }
  for(const itemEntry of battleCollection(data?.battleItems)){
    const item=itemEntry.value; const hostId=item?.hostUserId??item?.host_id??itemEntry.key;
    for(const groupEntry of battleCollection(item?.battleGroups??item?.battle_groups)){
      const group=groupEntry.value;
      for(const uEntry of battleCollection(group?.users??group?.participants)) add(uEntry.value,hostId);
    }
    add(item?.user,hostId);
    add(item?.host,hostId);
  }
  for(const hEntry of battleCollection(data?.hosts??data?.battleArmies)){
    const h=hEntry.value; const hostId=h?.hostUserId??h?.host_user_id??h?.userId??h?.id??hEntry.key;
    add(h?.user,hostId); add(h?.host,hostId); add(h?.member,hostId);
    for(const mEntry of battleCollection(h?.members)) add(mEntry.value, mEntry.value?.userId??mEntry.value?.id);
  }
  for(const aEntry of battleCollection(data?.armies)){
    const a=aEntry.value; const hostId=a?.hostUserId??a?.userId??a?.id??aEntry.key;
    add(a?.user,hostId); add(a?.host,hostId);
  }
  // TikTok LIVE Battle は最大4人（自分を含む）。
  // battleGroups.users には補助情報や空の参加者枠が混ざることがあるため、
  // 実在ユーザーを優先して4人に正規化する。自分は必ず残す。
  const real=out.filter(x => x && (String(x.uniqueId||"").trim() || String(x.name||"") !== "参加者"));
  const fallback=out.filter(x => x && !real.includes(x));
  const target=normalizedTikTokId(OWN_UNIQUE_ID||USERNAME);
  let own=real.find(x => (OWN_USER_ID && String(x.id||"")===String(OWN_USER_ID)) || normalizedTikTokId(x.uniqueId)===target);
  if(!own && OWN_USER_ID){
    own={id:String(OWN_USER_ID),name:OWN_UNIQUE_ID||USERNAME,uniqueId:OWN_UNIQUE_ID||USERNAME};
    real.unshift(own);
  }
  const selected=[];
  if(own) selected.push(own);
  for(const x of real){ if(selected.length>=4) break; if(x!==own && !selected.includes(x)) selected.push(x); }
  for(const x of fallback){ if(selected.length>=4) break; if(!selected.includes(x)) selected.push(x); }
  return selected.slice(0,4);
}
function normalizedTikTokId(v){ return String(v??"").replace(/^@/,"").trim().toLowerCase(); }
function normalizedGiftName(v){ return String(v??"").normalize("NFKC").replace(/[\u200B-\u200D\uFEFF]/g,"").replace(/\s+/g," ").trim().toLowerCase(); }
function findOwnParticipant(participants){
  const target=normalizedTikTokId(OWN_UNIQUE_ID||USERNAME);
  const byId=OWN_USER_ID ? (participants||[]).find(p=>String(p?.id||"")===String(OWN_USER_ID)) : null;
  if(byId) return byId;
  if(!target) return null;
  return (participants||[]).find(p=>normalizedTikTokId(p?.uniqueId)===target) || null;
}
function readProtoVarint(buf, pos){
  let value=0n, shift=0n;
  while(pos < buf.length && shift <= 70n){
    const b=buf[pos++]; value |= BigInt(b & 0x7f) << shift;
    if(!(b & 0x80)) return {value,pos};
    shift += 7n;
  }
  return null;
}
function readProtoFields(buf){
  const fields=[]; let pos=0;
  while(pos < buf.length){
    const tag=readProtoVarint(buf,pos); if(!tag) break; pos=tag.pos;
    const fieldNo=Number(tag.value >> 3n), wire=Number(tag.value & 7n);
    if(!fieldNo) break;
    if(wire===0){ const v=readProtoVarint(buf,pos); if(!v) break; pos=v.pos; fields.push({fieldNo,wire,value:v.value}); }
    else if(wire===1){ if(pos+8>buf.length) break; fields.push({fieldNo,wire,value:buf.subarray(pos,pos+8)}); pos+=8; }
    else if(wire===2){ const len=readProtoVarint(buf,pos); if(!len) break; pos=len.pos; const n=Number(len.value); if(!Number.isSafeInteger(n)||n<0||pos+n>buf.length) break; fields.push({fieldNo,wire,value:buf.subarray(pos,pos+n)}); pos+=n; }
    else if(wire===5){ if(pos+4>buf.length) break; fields.push({fieldNo,wire,value:buf.subarray(pos,pos+4)}); pos+=4; }
    else break;
  }
  return fields;
}
function battleRawScoreMap(base64){
  const out={};
  if(!base64) return out;
  let buf; try{ buf=Buffer.from(base64,'base64'); }catch{return out;}
  const top=readProtoFields(buf);
  // Current and legacy WebcastLinkMicArmies both put battle data in field 3.
  // Newer builds encode it as a map<hostUserId, BattleUserArmies>; older builds
  // encode repeated WebcastLinkMicArmiesItems. Both are length-delimited messages.
  for(const f of top.filter(x=>x.fieldNo===3 && x.wire===2)){
    const entryFields=readProtoFields(f.value);
    const key=entryFields.find(x=>x.fieldNo===1 && x.wire===0);
    const valueMsg=entryFields.find(x=>x.fieldNo===2 && x.wire===2);
    if(key && valueMsg){
      const hostId=key.value.toString();
      const vf=readProtoFields(valueMsg.value);
      // BattleUserArmies's team score/points is a small integer. Ignore IDs,
      // timestamps and other huge varints; use the largest plausible score at
      // the first nested level, which is stable across the old/new battle proto.
      const nums=vf.filter(x=>x.wire===0).map(x=>x.value).filter(v=>v>=0n && v<=1000000000n);
      if(nums.length) out[hostId]=Number(nums.reduce((a,b)=>a>b?a:b,0n));
      continue;
    }
    // Legacy item: field 1 = hostUserId, field 2 = battleGroups[].
    const host=entryFields.find(x=>x.fieldNo===1 && x.wire===0);
    if(!host) continue;
    const nums=[];
    for(const g of entryFields.filter(x=>x.fieldNo===2 && x.wire===2)){
      for(const gf of readProtoFields(g.value)){
        if(gf.wire===0 && gf.fieldNo===2 && gf.value>=0n && gf.value<=1000000000n) nums.push(gf.value);
      }
    }
    if(nums.length) out[host.value.toString()]=Number(nums.reduce((a,b)=>a>b?a:b,0n));
  }
  return out;
}
function battleScoreMap(data){
  const out={};
  const add=(hostId, points)=>{
    if(hostId==null || hostId==="") return;
    const n=Number(points);
    if(!Number.isFinite(n) || n < 0) return;
    const id=String(hostId);
    // Do not overwrite a newer/larger snapshot with a smaller nested value.
    out[id]=Math.max(out[id]||0,n);
  };
  const hasOwn=(o,k)=>o && typeof o === "object" && Object.prototype.hasOwnProperty.call(o,k);

  // The installed piratetok-live-js 0.1.5 schema defines:
  // WebcastLinkMicArmies.battleItems[] -> { hostUserId, battleGroups[] }
  // WebcastLinkMicArmiesGroup -> { users[], points }
  // Walk the decoded payload recursively so this keeps working if the
  // connector wraps the same structure under another property name.
  const seen=new Set();
  const walk=(node, inheritedHostId=null, depth=0)=>{
    if(node==null || depth>8) return;
    if(typeof node !== 'object') return;
    if(seen.has(node)) return;
    seen.add(node);

    let hostId=inheritedHostId;
    if(hasOwn(node,'hostUserId')) hostId=node.hostUserId;
    else if(hasOwn(node,'host_user_id')) hostId=node.host_user_id;
    else if(hasOwn(node,'hostId')) hostId=node.hostId;

    // Exact LinkMicArmies score shape.
    if(Array.isArray(node.battleGroups)){
      for(const g of node.battleGroups){
        if(g && hasOwn(g,'points') && hostId!=null && hostId!=='') add(hostId,g.points);
        walk(g,hostId,depth+1);
      }
    }

    // Other known battle score shapes.
    if(hostId!=null && hostId!==''){
      if(hasOwn(node,'teamTotalScore')) add(hostId,node.teamTotalScore);
      if(hasOwn(node,'totalScore')) add(hostId,node.totalScore);
      if(hasOwn(node,'points') && !Array.isArray(node.points)) add(hostId,node.points);
      if(hasOwn(node,'score') && !Array.isArray(node.score)) add(hostId,node.score);
      if(hasOwn(node,'totalPoints')) add(hostId,node.totalPoints);
    }

    for(const [key,value] of Object.entries(node)){
      if(value==null || typeof value!=='object') continue;
      // Do not treat arbitrary numeric object keys as user IDs. Only known
      // battle containers are allowed to inherit a map key as a host ID.
      let nextHost=hostId;
      if(nextHost==null && (key==='battleItems' || key==='battleArmies' || key==='hosts' || key==='armies')){
        nextHost=null;
      }
      walk(value,nextHost,depth+1);
    }
  };
  walk(data,null,0);

  // Explicit map/array fallbacks for newer battleArmies-style payloads.
  const hostContainers=[data?.hosts,data?.battleArmies,data?.armies,data?.teamArmies,data?.team_armies];
  for(const container of hostContainers){
    for(const entry of battleCollection(container)){
      const h=entry.value;
      if(!h || typeof h!=='object') continue;
      const hostId=h.hostUserId??h.host_user_id??h.hostId??h.userId??h.id;
      if(hostId==null || hostId==='') continue;
      add(hostId,h.teamTotalScore??h.totalScore??h.totalPoints??h.points??h.score);
      for(const mEntry of battleCollection(h.members??h.users??h.contributors)){
        const m=mEntry.value;
        const mid=m?.userId??m?.id??m?.user?.id;
        if(mid!=null) add(mid,m?.score??m?.points??0);
      }
    }
  }
  // Raw protobuf fallback: required for current TikTok battle map payloads
  // that the bundled 0.1.5 schema decodes as an incompatible legacy shape.
  const rawScores=battleRawScoreMap(data?.__rawPayloadBase64);
  for(const [id,score] of Object.entries(rawScores)) out[id]=Math.max(out[id]||0,Number(score)||0);
  return out;
}
function battleTeamSnapshot(data, participants, ownId){
  const candidates=[data?.teamArmies,data?.battleTeamArmies,data?.team_armies,data?.battleTeams,data?.teams];
  const raw=candidates.find(v=>Array.isArray(v)|| (v&&typeof v==="object"));
  const byId=new Map((participants||[]).map(p=>[String(p.id),p]));
  const normTeam=(t,i)=>{
    if(!t || typeof t!=="object") return null;
    const ids=[]; const addId=v=>{if(v==null)return;const id=String(v);if(byId.has(id)&&!ids.includes(id))ids.push(id);};
    for(const v of battleCollection(t.hostUserIds??t.host_user_ids)) addId(v.value);
    for(const v of battleCollection(t.userIds??t.user_ids)) addId(v.value);
    for(const v of battleCollection(t.users)) addId(v.value?.id??v.value?.userId??v.value?.uid??v.value);
    for(const v of battleCollection(t.members)) addId(v.value?.id??v.value?.userId??v.value?.uid??v.value);
    const host=t.hostUserId??t.hostId??t.anchorUserId; addId(host);
    if(!ids.length) return null;
    const points=Number(t.points??t.score??t.totalPoints??t.teamTotalScore??0)||0;
    const name=String(t.teamName??t.name??`チーム${i+1}`);
    return {id:String(t.teamId??t.id??i),name,members:ids.map(id=>byId.get(id)).filter(Boolean),points};
  };
  let teams=battleCollection(raw).map((e,i)=>normTeam(e.value,i)).filter(Boolean);
  if(teams.length<2 && Array.isArray(data?.teamMember)) teams=data.teamMember.map(normTeam).filter(Boolean);
  if(teams.length<2){
    const grouped=new Map();
    for(const p of participants||[]){ const tid=p.teamId??p.teamID??p.team_id??p.groupId??p.groupID; if(tid==null)continue; const key=String(tid); if(!grouped.has(key))grouped.set(key,{id:key,name:`チーム ${key}`,members:[],points:0}); grouped.get(key).members.push(p); }
    teams=[...grouped.values()];
  }
  // TikTok LIVE Battle は最大4人。チーム戦は左右2チーム、各チーム最大2人として正規化。
  teams=teams.slice(0,2).map(t=>({...t,members:(Array.isArray(t.members)?t.members:[]).slice(0,2)}));
  if(teams.length<2) return {mode:"individual",teams:[],ownTeamId:""};
  const ownTeam=teams.find(t=>t.members.some(m=>String(m?.id)===String(ownId)))||null;
  if(!ownTeam) return {mode:"team",teams,ownTeamId:"",ownTeamResolved:false};
  return {mode:"team",teams:[ownTeam,...teams.filter(t=>t!==ownTeam).slice(0,1)],ownTeamId:String(ownTeam.id),ownTeamResolved:true};
}
function finalizeBattle(reason="ended") {
  if(!currentBattle) return false;
  const endedAt=Date.now();
  const scores=currentBattle.scores||{};
  const own=currentBattle.ownHostId;
  const participants=currentBattle.participants||[];
  const opponents=participants.filter(p=>String(p.id)!==String(own));
  const ownScore=Number(scores[String(own)]||0);
  const opponentScores=opponents.map(p=>({id:p.id,name:p.name,uniqueId:p.uniqueId,score:Number(scores[String(p.id)]||0)}));
  const maxOpp=Math.max(0,...opponentScores.map(x=>x.score));
  let result="DRAW";
  if(ownScore>maxOpp) result="WIN"; else if(ownScore<maxOpp) result="LOSE";
  const item={id:`${currentBattle.startedAt}-${endedAt}-${currentBattle.battleId||"battle"}`,battleId:String(currentBattle.battleId||""),username:USERNAME,startedAt:currentBattle.startedAt,endedAt,durationMs:Math.max(0,endedAt-currentBattle.startedAt),result,ownScore,opponents:opponentScores,reason,mode:currentBattle.mode||"individual",teams:currentBattle.teams||[],gloves:currentBattle.gloves||[],scoreHistory:currentBattle.scoreHistory||[]};
  saveBattleHistoryItem(item);
  broadcast({type:"battleHistorySaved",data:item});
  log(`🥊 バトル終了：${opponentScores.map(x=>x.name).join(" / ")||"相手不明"} / ${result} ${ownScore}-${maxOpp}`);
  currentBattle=null;
  return true;
}

const browserClients = new Set();
let pseudoGiftHandler = null;
// 擬似ギフト経路でも常に定義されていることを保証する安全フラグ。
let isPseudoTest = false;
const countdownClients = new Set();
const timerClients = new Set();
const bingoClients = new Set();
let dashboardBroadcastTimer = null;
let dashboardBroadcastPending = false;
function scheduleDashboardBroadcast(immediate=false){
  dashboardBroadcastPending = true;
  if(immediate){
    if(dashboardBroadcastTimer){clearTimeout(dashboardBroadcastTimer); dashboardBroadcastTimer=null;}
    dashboardBroadcastPending=false;
    broadcast({type:"dashboard",data:dashboardSnapshot()});
    return;
  }
  if(dashboardBroadcastTimer) return;
  dashboardBroadcastTimer=setTimeout(()=>{
    dashboardBroadcastTimer=null;
    if(!dashboardBroadcastPending) return;
    dashboardBroadcastPending=false;
    broadcast({type:"dashboard",data:dashboardSnapshot()});
  },250);
}
const recentEmoteEvents = new Map();
// LIVEダッシュボード用統計（LIVE接続ごとにリセット）
let likeRanking = new Map();
let giftRanking = new Map();
let giftTypeRanking = new Map();
let commentRanking = new Map();
let entryRanking = new Map();
let entrySequence = 0;
let viewerStats = new Map();
// 現在のLIVE中に入室・反応を検知したリスナー（履歴とは別の一時データ）
let liveListeners = new Map();
let liveLikeTotal = 0;
let receivedLikeTotal = 0;
let totalGiftCount = 0;
let totalGiftValue = 0;
let totalComments = 0;
let totalFollows = 0;
let eventLog = [];
let liveStartedAt = null;
function resetDashboardStats(){
  likeRanking=new Map(); giftRanking=new Map(); giftTypeRanking=new Map(); commentRanking=new Map(); entryRanking=new Map(); entrySequence=0; viewerStats=new Map(); liveListeners=new Map();
  liveSessionSaved=false;
  liveLikeTotal=0; receivedLikeTotal=0; totalGiftCount=0; totalGiftValue=0; totalComments=0; totalFollows=0; eventLog=[]; liveStartedAt=Date.now();
}
function extractEntryUser(d){
  const normal=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??d?.userData??{};
  const content=d?.content;
  const barrage=(d?.userGradeParam||d?.fansLevelParam)
    ? (d?.userGradeParam||d?.fansLevelParam)
    : (content?.userGradeParam||content?.fansLevelParam||{});
  const u=barrage?.user??normal??{};
  return {u,barrage};
}
function extractBadgeLevel(u, scene){
  const badges=Array.isArray(u?.badgeList)?u.badgeList:(Array.isArray(u?.badges)?u.badges:[]);
  for(const b of badges){
    const bs=Number(b?.badgeScene);
    const n=Number(b?.logExtra?.level ?? b?.level);
    if(Number.isFinite(n)&&n>0 && bs===Number(scene)) return n;
    const raw=JSON.stringify(b||{});
    const re=scene===8?/(?:grade_badge_icon_lite_lv|USER_GRADE).*?(\d+)/i:/(?:fans_badge_icon_lv|FANS).*?(\d+)/i;
    const m=raw.match(re);
    if(m) return Number(m[1])||0;
  }
  return 0;
}
function dashboardEntry(d, meta={}){
  const {u}=extractEntryUser(d);
  const id=String(u?.id??u?.uid??u?.userId??u?.user_id??u?.uniqueId??u?.unique_id??meta.userId??userName(d)).trim()||String(meta.userId||userName(d)||'unknown');
  const name=String(u?.nickname??u?.uniqueId??u?.unique_id??u?.displayName??meta.name??(userName(d)||id));
  if(!entryRanking.has(id)) entryRanking.set(id,{id,name,lastSeen:0,gifterLevel:null,memberLevel:null});
  const x=entryRanking.get(id); x.name=name||x.name; x.lastSeen=++entrySequence;
  if(meta.gifterLevel!=null) x.gifterLevel=Math.max(Number(x.gifterLevel)||0,Number(meta.gifterLevel)||0);
  if(meta.memberLevel!=null) x.memberLevel=Math.max(Number(x.memberLevel)||0,Number(meta.memberLevel)||0);
  const badges = Array.isArray(u?.badgeList) ? u.badgeList : (Array.isArray(u?.badges) ? u.badges : []);
  for(const b of badges){
    const scene=Number(b?.badgeScene);
    const level=Number(b?.logExtra?.level ?? b?.level);
    if(Number.isFinite(level) && level>0){
      if(scene===8) x.gifterLevel=Math.max(Number(x.gifterLevel)||0,level);
      if(scene===10) x.memberLevel=Math.max(Number(x.memberLevel)||0,level);
    }
    const raw=JSON.stringify(b||{});
    let m=raw.match(/(?:grade_badge_icon_lite_lv|USER_GRADE).*?(\d+)/i);
    if(m) x.gifterLevel=Math.max(Number(x.gifterLevel)||0,Number(m[1])||0);
    m=raw.match(/(?:fans_badge_icon_lv|FANS).*?(\d+)/i);
    if(m) x.memberLevel=Math.max(Number(x.memberLevel)||0,Number(m[1])||0);
  }
  const clubLevel=Number(u?.fansClub?.data?.level ?? u?.fansClub?.level);
  if(Number.isFinite(clubLevel)&&clubLevel>0) x.memberLevel=Math.max(Number(x.memberLevel)||0,clubLevel);
  return x;
}
function dashboardBarrageEntry(d){
  // piratetok-live-js の BarrageEvent は content.userGradeParam / content.fansLevelParam。
  // 実際の配信ではラッパーやバージョン差で直下に来る場合もあるため両方を見る。
  const content=d?.content ?? {};
  const commonContent=d?.commonBarrageContent ?? d?.common_barrage_content ?? {};
  const ug=d?.userGradeParam ?? content?.userGradeParam ?? commonContent?.userGradeParam ?? null;
  const fg=d?.fansLevelParam ?? content?.fansLevelParam ?? commonContent?.fansLevelParam ?? null;
  const msgType=Number(d?.msgType ?? d?.msg_type ?? 0);
  // 9 = GRADEUSERENTRANCENOTIFICATION, 11 = FANSLEVELENTRANCE
  if(!ug && !fg && ![9,11].includes(msgType)) return null;

  const pu=ug?.user ?? fg?.user ?? content?.userGradeParam?.user ?? content?.fansLevelParam?.user ?? null;
  const fallbackId=String(ug?.userId ?? ug?.user?.id ?? fg?.user?.id ?? pu?.id ?? '').trim();
  const payloadUser=pu || (fallbackId ? {id:fallbackId, uniqueId:fallbackId, nickname:fallbackId} : null);
  if(!payloadUser) return null;

  const normalized={...d,user:payloadUser};
  const gl=Number(ug?.currentGrade);
  const ml=Number(fg?.currentGrade);
  const meta={userId:fallbackId||payloadUser?.id||payloadUser?.userId||null,name:payloadUser?.nickname||payloadUser?.uniqueId||fallbackId||null};
  if(Number.isFinite(gl) && gl>0) meta.gifterLevel=gl;
  if(Number.isFinite(ml) && ml>0) meta.memberLevel=ml;
  const entry=dashboardEntry(normalized,meta);
  dashboardUser(normalized,meta);
  // 月次/累計保存側にも、Barrageで復元したユーザー情報をそのまま渡す。
  // 元の d には user が存在しないケースがあるため、ここを使わないと
  // 高ギフレベ・メンレベ入室だけ月次/累計に残らない。
  entry._data=normalized;
  return entry;
}
function levelMetaFromUser(u){
  let g=0,m=0;
  const badges=Array.isArray(u?.badgeList)?u.badgeList:(Array.isArray(u?.badges)?u.badges:[]);
  for(const b of badges){
    const scene=Number(b?.badgeScene);
    const lv=Number(b?.logExtra?.level ?? b?.level);
    if(Number.isFinite(lv)&&lv>0){
      if(scene===8) g=Math.max(g,lv);
      if(scene===10) m=Math.max(m,lv);
    }
    const raw=JSON.stringify(b||{});
    let hit=raw.match(/(?:grade_badge_icon_lite_lv|USER_GRADE).*?(\d+)/i); if(hit) g=Math.max(g,Number(hit[1])||0);
    hit=raw.match(/(?:fans_badge_icon_lv|FANS).*?(\d+)/i); if(hit) m=Math.max(m,Number(hit[1])||0);
  }
  const club=Number(u?.fansClub?.data?.level ?? u?.fansClub?.level);
  if(Number.isFinite(club)&&club>0) m=Math.max(m,club);
  return {gifterLevel:g||null,memberLevel:m||null};
}
// 長期リスナー履歴：初見/再訪、配信回数、日別統計、最近の会話を保存。
// 生ログを無制限に貯めず、ユーザーごとの最近100コメント＋直近730日の日別集計に制限。
function loadListenerHistory(){
  try{
    if(!fs.existsSync(LISTENER_HISTORY_PATH)){fs.writeFileSync(LISTENER_HISTORY_PATH,JSON.stringify({},null,2));return {};}
    const raw=JSON.parse(fs.readFileSync(LISTENER_HISTORY_PATH,"utf8"));
    return raw&&typeof raw==="object"?raw:{};
  }catch{return {};}
}
let listenerHistory=loadListenerHistory();
let listenerHistorySaveTimer=null;
function saveListenerHistory(){
  if(listenerHistorySaveTimer)return;
  listenerHistorySaveTimer=setTimeout(()=>{
    listenerHistorySaveTimer=null;
    try{fs.writeFileSync(LISTENER_HISTORY_PATH,JSON.stringify(listenerHistory,null,2));}catch{}
  },1000);
}
const listenerSessionSeen=new Set();
function listenerUserInfo(d,meta={}){
  const u=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??d?.userData??{};
  const id=String(u?.id??u?.uid??u?.userId??u?.user_id??u?.uniqueId??u?.unique_id??meta.userId??userName(d)).trim()||String(meta.userId||userName(d));
  const name=String(userName(d)||meta.name||"誰か");
  return {id,name};
}
function listenerToday(){return new Intl.DateTimeFormat("ja-JP",{timeZone:"Asia/Tokyo",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date()).replaceAll("/","-");}
function pruneListenerDays(x){
  const cutoff=Date.now()-730*86400000;
  for(const day of Object.keys(x.days||{})){
    const t=Date.parse(`${day}T00:00:00+09:00`);
    if(Number.isFinite(t)&&t<cutoff) delete x.days[day];
  }
}
function touchListener(d,kind="event",amount=0,diamondValue=0,text="",meta={}){
  const {id,name}=listenerUserInfo(d,meta); if(!id)return null;
  if(!listenerHistory[id]) listenerHistory[id]={id,name,firstSeen:new Date().toISOString(),lastSeen:new Date().toISOString(),visitCount:0,visitDates:[],days:{},comments:[]};
  getListenerProfile(id,name);
  const x=listenerHistory[id]; x.name=name||x.name||"誰か";
  const now=new Date(); x.lastSeen=now.toISOString();
  const sessionKey=String(liveStartedAt||"");
  if(sessionKey && !listenerSessionSeen.has(id)){
    listenerSessionSeen.add(id); x.visitCount=Number(x.visitCount||0)+1;
    const day=listenerToday(); if(!Array.isArray(x.visitDates))x.visitDates=[]; if(!x.visitDates.includes(day))x.visitDates.push(day); x.visitDates=x.visitDates.slice(-730);
  }
  const day=listenerToday(); if(!x.days||typeof x.days!=="object")x.days={};
  if(!x.days[day])x.days[day]={likes:0,gifts:0,giftValue:0,comments:0,visits:0};
  const ds=x.days[day];
  if(kind==="like") ds.likes+=Math.max(0,Math.floor(Number(amount)||0));
  if(kind==="gift"){ds.gifts+=Math.max(0,Math.floor(Number(amount)||0));ds.giftValue+=Math.max(0,Number(diamondValue)||0);}
  if(kind==="comment") ds.comments+=Math.max(0,Math.floor(Number(amount)||0));
  if(kind==="entry") ds.visits+=1;
  if(kind==="comment" && String(text||"").trim()){
    const commentText=String(text).trim();
    if(!Array.isArray(x.comments))x.comments=[];
    x.comments.unshift({time:now.toISOString(),text:commentText});
    pruneListenerComments(x);
    extractListenerProfile(id,name,commentText);
    liveListeners.set(id,{id,name:x.name,visitCount:Number(x.visitCount||0),lastActivity:now.toISOString(),lastComment:commentText});
  } else {
    const prev=liveListeners.get(id)||{};
    liveListeners.set(id,{...prev,id,name:x.name,visitCount:Number(x.visitCount||0),lastActivity:now.toISOString(),lastComment:prev.lastComment||""});
  }
  pruneListenerDays(x); saveListenerHistory(); return x;
}
function listenerHistorySnapshot(){
  return Object.values(listenerHistory).filter(x=>x&&x.id).map(x=>({id:x.id,name:x.name,firstSeen:x.firstSeen,lastSeen:x.lastSeen,visitCount:Number(x.visitCount||0),visitDates:Array.isArray(x.visitDates)?x.visitDates:[],comments:Array.isArray(x.comments)?x.comments:[],days:x.days&&typeof x.days==="object"?x.days:{},profile:getListenerProfile(x.id,x.name)}));
}

function dashboardUser(d, meta={}){
  const u=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??d?.userData??{};
  const id=String(u?.id??u?.uid??u?.userId??u?.user_id??u?.uniqueId??u?.unique_id??meta.userId??userName(d)).trim()||String(meta.userId||userName(d));
  const name=String(userName(d)||meta.name||'誰か');
  touchListener(d,"event",0,0,"",meta);
  const lv=levelMetaFromUser(u);
  if(!viewerStats.has(id)) viewerStats.set(id,{id,name,likes:0,giftValue:0,gifts:0,comments:0,follows:0,gifterLevel:null,memberLevel:null});
  const v=viewerStats.get(id); v.name=name||v.name;
  if(meta.gifterLevel!=null) v.gifterLevel=Math.max(Number(v.gifterLevel)||0,Number(meta.gifterLevel)||0);
  if(meta.memberLevel!=null) v.memberLevel=Math.max(Number(v.memberLevel)||0,Number(meta.memberLevel)||0);
  if(lv.gifterLevel!=null) v.gifterLevel=Math.max(Number(v.gifterLevel)||0,lv.gifterLevel);
  if(lv.memberLevel!=null) v.memberLevel=Math.max(Number(v.memberLevel)||0,lv.memberLevel);
  return v;
}
function loadMonthlyUserStats(){
  try{
    if(!fs.existsSync(MONTHLY_USER_STATS_PATH)){fs.writeFileSync(MONTHLY_USER_STATS_PATH,JSON.stringify({},null,2));return {};}
    const raw=JSON.parse(fs.readFileSync(MONTHLY_USER_STATS_PATH,"utf8"));
    return raw&&typeof raw==="object"?raw:{};
  }catch{return {};}
}
let monthlySaveTimer=null;
function saveMonthlyUserStats(){
  if(monthlySaveTimer) return;
  monthlySaveTimer=setTimeout(()=>{
    monthlySaveTimer=null;
    try{fs.writeFileSync(MONTHLY_USER_STATS_PATH,JSON.stringify(monthlyUserStats,null,2));}catch{}
  },1000);
}
let monthlyUserStats=loadMonthlyUserStats();
function loadCumulativeUserStats(){
  try{if(fs.existsSync(CUMULATIVE_USER_STATS_PATH)){const raw=JSON.parse(fs.readFileSync(CUMULATIVE_USER_STATS_PATH,"utf8"));if(raw&&typeof raw==="object")return raw;}}catch{}
  const out={};
  try{
    const history=fs.existsSync(LIVE_HISTORY_PATH)?JSON.parse(fs.readFileSync(LIVE_HISTORY_PATH,"utf8")):[];
    for(const live of (Array.isArray(history)?history:[])){
      for(const r of (Array.isArray(live?.likeRanking)?live.likeRanking:[])){
        const id=String(r?.id||r?.name||"").trim();if(!id)continue;if(!out[id])out[id]={id,name:String(r?.name||"誰か"),likes:0,gifts:0,giftValue:0,comments:0};out[id].name=String(r?.name||out[id].name||"誰か");out[id].likes+=Number(r?.likes||0)||0;
      }
      for(const r of (Array.isArray(live?.giftRanking)?live.giftRanking:[])){
        const id=String(r?.id||r?.name||"").trim();if(!id)continue;if(!out[id])out[id]={id,name:String(r?.name||"誰か"),likes:0,gifts:0,giftValue:0,comments:0};out[id].name=String(r?.name||out[id].name||"誰か");out[id].gifts+=Number(r?.gifts||0)||0;out[id].giftValue+=Number(r?.value||0)||0;
      }
      for(const r of (Array.isArray(live?.commentRanking)?live.commentRanking:[])){
        const id=String(r?.id||r?.name||"").trim();if(!id)continue;if(!out[id])out[id]={id,name:String(r?.name||"誰か"),likes:0,gifts:0,giftValue:0,comments:0};out[id].name=String(r?.name||out[id].name||"誰か");out[id].comments+=Number(r?.comments||0)||0;
      }
    }
  }catch{}
  try{fs.writeFileSync(CUMULATIVE_USER_STATS_PATH,JSON.stringify(out,null,2));}catch{}
  return out;
}
let cumulativeUserStats=loadCumulativeUserStats();
for(const x of Object.values(cumulativeUserStats||{})){ if(x && typeof x==="object" && !Number.isFinite(Number(x.giftValue))) x.giftValue=0; }
let cumulativeSaveTimer=null;
function saveCumulativeUserStats(){
  if(cumulativeSaveTimer) return;
  cumulativeSaveTimer=setTimeout(()=>{
    cumulativeSaveTimer=null;
    try{fs.writeFileSync(CUMULATIVE_USER_STATS_PATH,JSON.stringify(cumulativeUserStats,null,2));}catch{}
  },1000);
}
function cumulativeUser(d){
  const u=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??d?.userData??{};const id=String(u?.id??u?.uid??u?.userId??u?.user_id??u?.uniqueId??u?.unique_id??userName(d)).trim()||userName(d);const name=String(userName(d)||"誰か");
  if(!cumulativeUserStats[id])cumulativeUserStats[id]={id,name,likes:0,gifts:0,giftValue:0,comments:0};const x=cumulativeUserStats[id];x.name=name||x.name;return x;
}
function cumulativeLike(d,delta){const n=Math.max(0,Math.floor(Number(delta)||0));if(!n)return;const x=cumulativeUser(d);x.likes+=n;saveCumulativeUserStats();}
function cumulativeGift(d,delta,diamondValue=0){const n=Math.max(0,Math.floor(Number(delta)||0));const v=Math.max(0,Number(diamondValue)||0);if(!n && !v)return;const x=cumulativeUser(d);x.gifts+=n;x.giftValue+=v;saveCumulativeUserStats();}
function cumulativeComment(d,delta=1){const n=Math.max(0,Math.floor(Number(delta)||0));if(!n)return;const x=cumulativeUser(d);x.comments+=n;saveCumulativeUserStats();}
function cumulativeEntry(d){
  const x=cumulativeUser(d);
  // monthlyEntry() がこの日の入室を記録した後、その日数を累計へ同期。
  x.entries=totalEntryDaysForUser(x.id);
  saveCumulativeUserStats();
}
function allEntryDatesForUser(id){
  const days=new Set();
  for(const [key,users] of Object.entries(monthlyUserStats||{})){
    if(key.startsWith('__') || !users || typeof users!=="object") continue;
    const u=users[id];
    if(u && Array.isArray(u.entryDays)){
      for(const day of u.entryDays){
        const v=String(day||'').trim();
        if(v) days.add(v);
      }
    }
  }
  return [...days].sort().reverse();
}
function totalEntryDaysForUser(id){
  return allEntryDatesForUser(id).length;
}
function rebuildCumulativeEntryDays(){
  let changed=false;
  for(const x of Object.values(cumulativeUserStats||{})){
    const n=totalEntryDaysForUser(String(x.id));
    if(Number(x.entries||0)!==n){ x.entries=n; changed=true; }
  }
  // 月次データ側にだけ存在するユーザーも累計一覧へ反映。
  for(const [key,users] of Object.entries(monthlyUserStats||{})){
    if(key.startsWith('__') || !users || typeof users!=="object") continue;
    for(const [id,u] of Object.entries(users)){
      if(!u || typeof u!=="object" || !u.id || !Array.isArray(u.entryDays) || !u.entryDays.length) continue;
      if(!cumulativeUserStats[id]) cumulativeUserStats[id]={id:String(u.id),name:String(u.name||"誰か"),likes:0,gifts:0,comments:0,entries:0};
      const n=totalEntryDaysForUser(id);
      if(cumulativeUserStats[id].entries!==n) { cumulativeUserStats[id].entries=n; changed=true; }
      if(u.name) cumulativeUserStats[id].name=u.name;
    }
  }
  if(changed) saveCumulativeUserStats();
}
function cumulativeSnapshot(){return {users:Object.values(cumulativeUserStats).map(x=>({id:x.id,name:x.name,likes:Number(x.likes||0),gifts:Number(x.gifts||0),comments:Number(x.comments||0),giftValue:Number(x.giftValue||0),entries:Number(x.entries||0),entryDates:allEntryDatesForUser(String(x.id))}))};}
function jstMonthDay(){return new Intl.DateTimeFormat("ja-JP",{timeZone:"Asia/Tokyo",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date()).replaceAll("/","-");}
function monthKeyFromDay(day){return String(day).slice(0,7);}
function monthlyUser(d){
  const u=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??d?.userData??{};
  const id=String(u?.id??u?.uid??u?.userId??u?.user_id??u?.uniqueId??u?.unique_id??userName(d)).trim()||userName(d);
  const name=String(userName(d)||"誰か");
  const month=monthKeyFromDay(jstMonthDay());
  if(!monthlyUserStats[month]) monthlyUserStats[month]={};
  if(!monthlyUserStats[month][id]) monthlyUserStats[month][id]={id,name,likes:0,gifts:0,giftValue:0,entryDays:[]};
  const x=monthlyUserStats[month][id]; x.name=name||x.name;
  return x;
}
function monthlyEntry(d){
  const x=monthlyUser(d); const day=jstMonthDay();
  if(!Array.isArray(x.entryDays)) x.entryDays=[];
  if(!x.entryDays.includes(day)){x.entryDays.push(day);x.entryDays.sort();saveMonthlyUserStats();return true;}
  return false;
}
function monthlyLike(d,delta){
  const n=Math.max(0,Math.floor(Number(delta)||0)); if(!n)return; const x=monthlyUser(d); x.likes+=n; saveMonthlyUserStats();
}
function monthlyGift(d,delta,diamondValue=0){
  const n=Math.max(0,Math.floor(Number(delta)||0)); const v=Math.max(0,Number(diamondValue)||0); if(!n && !v)return; const x=monthlyUser(d); x.gifts+=n; x.giftValue=Number(x.giftValue||0)+v; saveMonthlyUserStats();
}
function monthlyComment(d,delta=1){
  const n=Math.max(0,Math.floor(Number(delta)||0)); if(!n)return; const x=monthlyUser(d); x.comments=Number(x.comments||0)+n; saveMonthlyUserStats();
}
function migrateMonthlyCommentsFromHistory(){
  try{
    const month=monthKeyFromDay(jstMonthDay()); if(monthlyUserStats.__commentsHistoryMigrated===month)return;
    const history=fs.existsSync(LIVE_HISTORY_PATH)?JSON.parse(fs.readFileSync(LIVE_HISTORY_PATH,"utf8")):[];
    for(const live of (Array.isArray(history)?history:[])){
      const day=new Date(Number(live?.startedAt||0)).toLocaleDateString("sv-SE",{timeZone:"Asia/Tokyo"});
      if(monthKeyFromDay(day)!==month)continue;
      for(const r of (Array.isArray(live?.commentRanking)?live.commentRanking:[])){
        const id=String(r?.id||r?.name||"").trim();if(!id)continue;if(!monthlyUserStats[month])monthlyUserStats[month]={};
        if(!monthlyUserStats[month][id])monthlyUserStats[month][id]={id,name:String(r?.name||"誰か"),likes:0,gifts:0,comments:0,entryDays:[]};
        const x=monthlyUserStats[month][id];x.name=String(r?.name||x.name||"誰か");x.comments=Number(x.comments||0)+(Number(r?.comments||0)||0);
      }
    }
    monthlyUserStats.__commentsHistoryMigrated=month;saveMonthlyUserStats();
  }catch{}
}
migrateMonthlyCommentsFromHistory();
rebuildCumulativeEntryDays();
function migrateGiftValuesFromHistory(){
  try{
    const migratedKey="__giftValueHistoryMigrated";
    if(cumulativeUserStats[migratedKey]) return;
    const history=fs.existsSync(LIVE_HISTORY_PATH)?JSON.parse(fs.readFileSync(LIVE_HISTORY_PATH,"utf8")):[];
    const currentMonth=monthKeyFromDay(jstMonthDay());
    const histCum=new Map();
    const histMonth=new Map();
    for(const live of (Array.isArray(history)?history:[])){
      const day=new Date(Number(live?.startedAt||0)).toLocaleDateString("sv-SE",{timeZone:"Asia/Tokyo"});
      const month=monthKeyFromDay(day);
      for(const r of (Array.isArray(live?.giftRanking)?live.giftRanking:[])){
        const id=String(r?.id||r?.name||"").trim(); if(!id) continue;
        const value=Math.max(0,Number(r?.value||0)||0);
        if(value>0) histCum.set(id,(histCum.get(id)||0)+value);
        if(month===currentMonth) histMonth.set(id,(histMonth.get(id)||0)+value);
      }
    }
    for(const [id,v] of histCum){
      if(!cumulativeUserStats[id]) cumulativeUserStats[id]={id,name:"誰か",likes:0,gifts:0,giftValue:0,comments:0};
      cumulativeUserStats[id].giftValue=Math.max(Number(cumulativeUserStats[id].giftValue||0),v);
    }
    if(!monthlyUserStats[currentMonth]) monthlyUserStats[currentMonth]={};
    for(const [id,v] of histMonth){
      if(!monthlyUserStats[currentMonth][id]) monthlyUserStats[currentMonth][id]={id,name:"誰か",likes:0,gifts:0,giftValue:0,entryDays:[]};
      monthlyUserStats[currentMonth][id].giftValue=Math.max(Number(monthlyUserStats[currentMonth][id].giftValue||0),v);
    }
    cumulativeUserStats[migratedKey]=true;
    saveCumulativeUserStats(); saveMonthlyUserStats();
  }catch(e){ log(`⚠️ ギフトダイヤ移行失敗: ${e?.message||e}`); }
}
migrateGiftValuesFromHistory();
function monthlySnapshot(){
  const month=monthKeyFromDay(jstMonthDay()); const src=monthlyUserStats[month]||{};
  const rows=Object.values(src).filter(x=>x&&typeof x==="object"&&x.id).map(x=>({id:x.id,name:x.name,likes:Number(x.likes||0),gifts:Number(x.gifts||0),comments:Number(x.comments||0),giftValue:Number(x.giftValue||0),entryDays:Array.isArray(x.entryDays)?x.entryDays.length:0,entryDates:Array.isArray(x.entryDays)?[...new Set(x.entryDays.map(String))].sort().reverse():[]}));
  return {month,users:rows};
}
function addDashboardLog(text){ eventLog.unshift({time:new Date().toLocaleTimeString('ja-JP'),text:String(text)}); if(eventLog.length>300) eventLog.length=300; }
function dashboardSnapshot(){
  const likes=[...likeRanking.values()].sort((a,b)=>b.likes-a.likes||a.name.localeCompare(b.name,'ja')).slice(0,100).map((x,i)=>({rank:i+1,...x}));
  const gifts=[...giftRanking.values()].sort((a,b)=>b.value-a.value||a.name.localeCompare(b.name,'ja')).slice(0,100).map((x,i)=>({rank:i+1,...x}));
  const types=[...giftTypeRanking.values()].sort((a,b)=>b.value-a.value||a.name.localeCompare(b.name,'ja')).slice(0,50).map((x,i)=>({rank:i+1,...x}));
  const comments=[...commentRanking.values()].sort((a,b)=>b.comments-a.comments||a.name.localeCompare(b.name,'ja')).slice(0,100).map((x,i)=>({rank:i+1,...x}));
  const entries=[...entryRanking.values()].sort((a,b)=>b.lastSeen-a.lastSeen).slice(0,100).map((x,i)=>({rank:i+1,...x}));
  const viewers=[...viewerStats.values()].sort((a,b)=>{const as=a.likes+a.giftValue+a.follows*300+a.comments*10,bs=b.likes+b.giftValue+b.follows*300+b.comments*10;return bs-as||a.name.localeCompare(b.name,'ja')}).slice(0,100).map((x,i)=>({rank:i+1,...x,score:x.likes+x.giftValue+x.follows*300+x.comments*10}));
  return {connected, totalLikes:liveLikeTotal,receivedLikes:receivedLikeTotal,viewers:viewerStats.size,totalGiftCount,totalGiftValue,totalComments,totalFollows,entryCount:entryRanking.size,likeRanking:likes,giftRanking:gifts,giftTypes:types,commentRanking:comments,entryRanking:entries,viewerRanking:viewers,logs:eventLog,startedAt:liveStartedAt,monthly:monthlySnapshot(),cumulative:cumulativeSnapshot()};
}

async function patchPirateTok() {
  // PirateTok 0.1.5 normally gets ttwid from GET https://www.tiktok.com/.
  // TikTok can return HTTP 200 without a ttwid Set-Cookie, which causes
  // "ttwid: no ttwid cookie in response" and prevents the LIVE websocket
  // from starting.  Patch the installed library once so it falls back to
  // ByteDance's ttwid union registration endpoint.
  const ttwidFile = path.join(__dirname, "node_modules", "piratetok-live-js", "dist", "auth", "ttwid.js");
  if (!fs.existsSync(ttwidFile)) {
    log(`⚠️ PirateTokのttwid.jsが見つかりません: ${ttwidFile}`);
    return false;
  }
  let src = fs.readFileSync(ttwidFile, "utf8");
  if (src.includes("KAITO_TTWID_UNION_FALLBACK")) return true;

  const needle = 'throw new Error(`ttwid: no ttwid cookie in response (status ${resp.status})`);';
  if (!src.includes(needle)) {
    log("⚠️ PirateTokのttwid.jsに想定のttwidエラー箇所が見つかりませんでした");
    return false;
  }
  const replacement = [
    '/* KAITO_TTWID_UNION_FALLBACK */',
    '    try {',
    '      // Node fetch環境によってはSet-Cookieを取得できないため、',
    '      // fallbackだけはnode:httpsで生のレスポンスヘッダーを取得する。',
    '      const unionBody = JSON.stringify({',
    '        region: "jp",',
    '        aid: 1768,',
    '        needFid: false,',
    '        service: "www.ixigua.com",',
    '        migrate_info: { ticket: "", source: "node" },',
    '        cbUrlProtocol: "https",',
    '        union: true',
    '      });',
    '      const unionCookie = await new Promise((resolve, reject) => {',
    '        const req = https.request("https://ttwid.bytedance.com/ttwid/union/register/", {',
    '          method: "POST",',
    '          headers: {',
    '            "Content-Type": "application/json",',
    '            "Content-Length": Buffer.byteLength(unionBody),',
    '            "User-Agent": ua,',
    '            "Accept": "application/json, text/plain, */*"',
    '          },',
    '          timeout: Math.max(3000, timeoutMs)',
    '        }, res2 => {',
    '          const cookies = res2.headers["set-cookie"] || [];',
    '          const list = Array.isArray(cookies) ? cookies : [cookies];',
    '          for (const cookie of list) {',
    '            const match = String(cookie || "").match(/(?:^|;\s*)ttwid=([^;]+)/);',
    '            if (match?.[1]) {',
    '              res2.resume();',
    '              resolve(match[1]);',
    '              return;',
    '            }',
    '          }',
    '          res2.resume();',
    '          resolve("");',
    '        });',
    '        req.on("error", reject);',
    '        req.on("timeout", () => req.destroy(new Error("ttwid union timeout")));',
    '        req.write(unionBody);',
    '        req.end();',
    '      });',
    '      if (unionCookie) return unionCookie;',
    '    } catch (_) {}',
    '    throw new Error("ttwid: no ttwid cookie in response (status " + resp.status + ")");'
  ].join("\n");
  src = src.replace(needle, replacement);
  fs.writeFileSync(ttwidFile, src);
  log("🔧 ttwid取得にByteDance union/registerフォールバックを追加しました");
  return true;
}

const GIFT_CATALOG_PATH = path.join(__dirname, "gift-catalog.json");
const DEFAULT_GIFT_CATALOG = [
  { id: "", jaName: "人気UP", internalName: "Popular Vote", diamondCount: 1, source: "known" },
  { id: "", jaName: "マネーガン", internalName: "Money Gun", diamondCount: 500, source: "known" }
];
function normalizeCatalogText(v){ return String(v ?? "").trim().normalize("NFKC").replace(/[\u200B-\u200D\uFEFF]/g, "").replace(/\s+/g, " ").toLowerCase(); }
function loadGiftCatalog(){
  try{
    if(!fs.existsSync(GIFT_CATALOG_PATH)) fs.writeFileSync(GIFT_CATALOG_PATH, JSON.stringify(DEFAULT_GIFT_CATALOG,null,2));
    const raw=JSON.parse(fs.readFileSync(GIFT_CATALOG_PATH,"utf8"));
    const rows=Array.isArray(raw)?raw:[];
    const map=new Map();
    for(const x of [...DEFAULT_GIFT_CATALOG,...rows]){
      const internalName=String(x?.internalName||x?.name||"").trim();
      const jaName=String(x?.jaName||"").trim();
      const id=String(x?.id||"").trim();
      if(!internalName && !jaName && !id) continue;
      const key=id||normalizeCatalogText(internalName)||normalizeCatalogText(jaName);
      map.set(key,{...x,internalName,jaName,id,diamondCount:Math.max(0,Number(x?.diamondCount??x?.diamond_count??0)||0),source:String(x?.source||"learned")});
    }
    return [...map.values()];
  }catch{return DEFAULT_GIFT_CATALOG.map(x=>({...x}));}
}
let giftCatalog=loadGiftCatalog();
function saveGiftCatalog(){ try{ fs.writeFileSync(GIFT_CATALOG_PATH,JSON.stringify(giftCatalog,null,2)); }catch(e){ log(`⚠️ ギフトカタログ保存失敗: ${e?.message||e}`); } }
function upsertGiftCatalog(entry){
  const internalName=String(entry?.internalName||"").trim(); const id=String(entry?.id||"").trim();
  const hasJaName=Object.prototype.hasOwnProperty.call(entry||{},"jaName");
  const hasDiamond=Object.prototype.hasOwnProperty.call(entry||{},"diamondCount");
  const idx=giftCatalog.findIndex(x=>(id && String(x?.id||"")===id) || (internalName && normalizeCatalogText(x?.internalName)===normalizeCatalogText(internalName)));
  const existing=idx>=0?giftCatalog[idx]:{};
  const jaName=hasJaName ? String(entry?.jaName||"").trim() : String(existing?.jaName||"").trim();
  const diamondCount=hasDiamond ? Math.max(0,Number(entry?.diamondCount)||0) : Math.max(0,Number(existing?.diamondCount)||0);
  if(!internalName && !id && !jaName) return null;
  const next={...existing,...entry,internalName:internalName||String(existing?.internalName||"").trim(),jaName,id:id||String(existing?.id||"").trim(),diamondCount,updatedAt:new Date().toISOString()};
  if(idx>=0) giftCatalog[idx]=next; else giftCatalog.push(next);
  if(giftCatalog.length>3000) giftCatalog=giftCatalog.slice(-3000);
  saveGiftCatalog(); return next;
}
function giftCatalogSearch(q=""){
  const needle=normalizeCatalogText(q);
  return giftCatalog.filter(x=>!needle || [x.jaName,x.internalName,x.id,String(x.diamondCount)].some(v=>normalizeCatalogText(v).includes(needle)))
    .sort((a,b)=>Number(b?.diamondCount||0)-Number(a?.diamondCount||0) || String(a?.jaName||a?.internalName||"").localeCompare(String(b?.jaName||b?.internalName||""),"ja"));
}
function giftInternalNameForSetting(name){
  const raw=String(name||"").trim();
  if(!raw) return raw;
  const hit=giftCatalog.find(x=>x?.jaName && normalizeCatalogText(x.jaName)===normalizeCatalogText(raw));
  return hit?.internalName ? String(hit.internalName).trim() : raw;
}
function giftDisplayName(internalName){
  const raw=String(internalName||"").trim();
  if(!raw) return raw;
  const hit=giftCatalog.find(x=>x?.internalName && normalizeCatalogText(x.internalName)===normalizeCatalogText(raw) && x?.jaName);
  return hit?.jaName ? String(hit.jaName).trim() : raw;
}
function giftSettingMatches(settingName, receivedInternalName){
  const setting=String(settingName||"").trim();
  const received=String(receivedInternalName||"").trim();
  if(!setting || !received) return false;
  if(normalizeCatalogText(setting)===normalizeCatalogText(received)) return true;
  const settingInternal=giftInternalNameForSetting(setting);
  const receivedInternal=giftInternalNameForSetting(received);
  return !!settingInternal && !!receivedInternal && normalizeCatalogText(settingInternal)===normalizeCatalogText(receivedInternal);
}

let activeProfile="live1";
function activeVoiceConfig(){ return profiles[activeProfile] || {}; }

let liveCheckTimer = null;
let liveSetupRunning = false;

function scheduleTikTokLiveCheck(delayMs = 30000) {
  if (liveCheckTimer) clearTimeout(liveCheckTimer);
  liveCheckTimer = setTimeout(async () => {
    liveCheckTimer = null;
    if (!USERNAME || liveSetupRunning || activeTikTokClient) return;

    try {
      const { TikTokLiveClient } = await import("piratetok-live-js");
      let online = true;
      try {
        online = await TikTokLiveClient.checkOnline(USERNAME, 10000);
      } catch (checkErr) {
        // 事前のLIVE判定だけ失敗しても、実際の接続を試せるようにする。
        // checkOnlineの一時的なHTTP障害で接続自体を止めない。
        log(`⚠️ LIVE事前確認に失敗しました。直接接続を試します: ${checkErr?.message || checkErr}`);
        online = true;
      }
      if (online) {
        log(`🔎 TikTok LIVE開始を検出: @${USERNAME} → 接続します`);
        setupTikTok(USERNAME);
      } else {
        broadcast({ type: "connection", connected: false, status: "TikTok LIVE 未配信（待機中）" });
        log(`⏸️ @${USERNAME} は現在LIVEしていません。再接続せず待機します`);
        scheduleTikTokLiveCheck(30000);
      }
    } catch (e) {
      log(`⚠️ LIVE状態確認エラー: ${e?.message || e}`);
      scheduleTikTokLiveCheck(30000);
    }
  }, delayMs);
}

async function setupTikTok(username = USERNAME, options = {}) {
  const prepareOnly = options?.prepareOnly === true;
  USERNAME = String(username || "").replace(/^@/, "").trim();
  if (!USERNAME) throw new Error("TikTok IDが空です");
  if (liveSetupRunning) return;
  // 新しいLIVE接続を開始したら、LIVEダッシュボードをリセット。
  resetDashboardStats();
  scheduleDashboardBroadcast();
  liveSetupRunning = true;
  try {
    await patchPirateTok();
    const { TikTokLiveClient } = await import("piratetok-live-js");

    // 通常接続では配信中かどうかを確認。擬似テスト準備モードではTikTokへ接続せず、
    // 本番と同じギフトハンドラだけを構築する。
    let online = true;
    if (!prepareOnly) {
      try {
        online = await TikTokLiveClient.checkOnline(USERNAME, 10000);
      } catch (checkErr) {
        log(`⚠️ LIVE事前確認に失敗しました。直接接続を試します: ${checkErr?.message || checkErr}`);
        online = true;
      }
    }
    if (!online) {
      connected = false;
      broadcast({ type: "connection", connected: false, status: "TikTok LIVE 未配信（待機中）" });
      log(`⏸️ @${USERNAME} は現在LIVEしていません。再接続せず待機します`);
      liveSetupRunning = false;
      scheduleTikTokLiveCheck(30000);
      return;
    }

    const ownIdentity=prepareOnly ? null : await resolveOwnTikTokIdentity(USERNAME);
    if(ownIdentity){
      log(`🆔 配信者IDを取得：@${ownIdentity.uniqueId} / ${ownIdentity.id}`);
    } else {
      OWN_USER_ID=""; OWN_UNIQUE_ID=normalizedTikTokId(USERNAME);
      log(`🆔 配信者の数値IDを取得できませんでした。バトルではID照合を継続します`);
    }

    // ttwidはPirateTokの自動取得を基本にし、TikTokがCookieを返さない場合は
    // 起動時に追加したByteDance union/registerフォールバックへ切り替えます。
    log("🔐 ttwidは自動取得＋フォールバックを使用します");

    const { EventType, LikeAccumulator } = await import("piratetok-live-js");

    // TikTokのWebcastChatMessageには、コメント本文とは別に
    // repeated EmoteWithIndex emotesList = 13; が入ります。
    // piratetok-live-js 0.1.5 の標準schemaにはこのフィールドが無いため、
    // 接続後ではなくデコード前に同じprotobuf Rootへ動的追加します。
    // これにより通常コメントに埋め込まれたエモートIDも受信できます。
    try {
      const pkgDir = path.dirname(fileURLToPath(import.meta.resolve("piratetok-live-js")));
      const schemaMod = await import(pathToFileURL(path.join(pkgDir, "proto/schema.js")).href);
      const protobuf = await import("protobufjs");
      const { Type, Field } = protobuf.default || protobuf;
      const protoRoot = schemaMod.root;
      let emoteWithIndexType = null;
      try { emoteWithIndexType = protoRoot.lookupType("EmoteWithIndex"); } catch {}
      if (!emoteWithIndexType) {
        protoRoot.add(new Type("EmoteWithIndex")
          .add(new Field("index", 1, "int64"))
          .add(new Field("emote", 2, "Emote")));
      }
      const chatType = protoRoot.lookupType("WebcastChatMessage");
      if (chatType && !chatType.fields.emotesList) {
        chatType.add(new Field("emotesList", 13, "EmoteWithIndex", "repeated"));
      }
      protoRoot.resolveAll();
      log("😊 WebcastChatMessage.emotesList(13) を有効化しました");
    } catch (schemaErr) {
      log(`⚠️ エモートprotobuf schema補正に失敗: ${schemaErr?.message || schemaErr}`);
    }
    if (activeTikTokClient) {
      try { await activeTikTokClient.disconnect?.(); } catch {}
      activeTikTokClient = null;
    }
    // フォロー重複防止用のSetは、参照する前に必ず初期化する。
    // 以前は followedUserIds.clear() が const 宣言より先に実行され、
    // 「Cannot access 'followedUserIds' before initialization」が発生していた。
    const followedUserIds = new Set();
    followedUserIds.clear();
    const client = new TikTokLiveClient(USERNAME)
      .language("ja")
      .region("JP")
      .maxRetries(2)
      .staleTimeout(90000)
      ;
    activeTikTokClient = client;


    client.on(EventType.connected, d => {
      connected = true;
      liveStartedAt = liveStartedAt || Date.now();
      log(`📡 TikTok LIVE 接続成功 (roomId: ${d?.roomId ?? "unknown"})`);
      broadcast({ type: "connection", connected: true, status: "TikTok LIVE 接続済み" });
    });

    // TikTok combo gifts send a running total in repeatCount (1 -> 2 -> 3...).
    // Do NOT rely on the library streak helper here: LIVE events can arrive with
    // repeated/late snapshots, and a final event can be followed by a duplicate.
    // We track the highest count ourselves and only play the newly-added delta.
    const giftStreaks = new Map();
    const finalizedGiftGroups = new Map();
    const processedMsgIds = new Set();
    const recentVoiceEvents = new Map();

    setInterval(() => {
      const cutoff = Date.now() - 15000;
      for (const [key, at] of finalizedGiftGroups) {
        if (at < cutoff) finalizedGiftGroups.delete(key);
      }
      for (const [key, entry] of giftStreaks) {
        if (!entry || (Date.now() - entry.lastSeen) >= 60000) giftStreaks.delete(key);
      }
    }, 5000).unref?.();

    const likeAccumulator = new LikeAccumulator();
    // 起動後最初に届くTikTok累計いいねを「基準値」として採用する。
    // これより前の累計は誰かの今回分としてランキングへ加算しない。
    let likeFallbackTotal = null;
    let likeMilestone = 0;
    let likeSoundMilestone = 0;
    let likeBaselineInitialized = false;

    function emitGiftVoice(d, amount=1) {
      const gift = String(d?.gift?.name ?? "").trim();
      const sender = userName(d);
      if (!gift) return false;

      const cfg = activeVoiceConfig();
      const resolvedGift = giftInternalNameForSetting(gift);
      const sounds = (Array.isArray(cfg[gift]) ? cfg[gift] : Array.isArray(cfg[resolvedGift]) ? cfg[resolvedGift] : []).filter(x => x?.enabled !== false);
      if (sounds.length === 0) {
        log(`🎁 ${sender} → ${gift} ×${amount}（音声設定なし）`);
        return false;
      }

      const incomingCount = Math.max(1, Math.min(1000, Math.floor(Number(amount) || 1)));
      const everyState = getGiftVoiceEvery(activeProfile, gift);
      const total = everyState.remainder + incomingCount;
      const playCount = Math.floor(total / everyState.every);
      everyState.remainder = total % everyState.every;
      if(!giftVoiceEvery[activeProfile]) giftVoiceEvery[activeProfile]={};
      giftVoiceEvery[activeProfile][everyState.key]={every:everyState.every,remainder:everyState.remainder};
      saveGiftVoiceEvery();
      if(playCount<=0){ log(`🎁 [${profileNames[activeProfile] || activeProfile}] ${sender} → ${gift} ×${incomingCount}（${everyState.every}個ごと / 次回まで${everyState.every-everyState.remainder}個）`); return true; }
      for (let i = 0; i < playCount; i++) {
        const chosen = sounds[Math.floor(Math.random() * sounds.length)];
        broadcastVoiceEvent({
          type: "giftVoice",
          gift,
          sender,
          url: chosen.url,
          soundName: chosen.name || "sound",
          volume: Math.max(0, Math.min(1, Number(chosen.volume ?? 1)))
        });
        log(`🎁 [${profileNames[activeProfile] || activeProfile}] ${sender} → ${gift} ${playCount > 1 ? `(${i + 1}/${playCount}) ` : ""}🔊 ${chosen.name || "sound"}`);
      }
      return true;
    }

    const handledCommentIds = new Map();
    function commentMsgId(d){
      return String(d?.common?.msgId ?? d?.common?.msgID ?? d?.msgId ?? d?.msgID ?? "").trim();
    }
    function rememberCommentId(d){
      const id=commentMsgId(d);
      if(!id) return false;
      const now=Date.now();
      for(const [k,t] of handledCommentIds) if(now-t>15000) handledCommentIds.delete(k);
      if(handledCommentIds.has(id)) return true;
      handledCommentIds.set(id,now);
      return false;
    }
    function textFromBarrageText(t){
      if(!t) return "";
      const pieces=Array.isArray(t?.pieces)?t.pieces:[];
      const pieceText=pieces.map(p=>String(p?.stringValue ?? p?.userValue?.user?.nickname ?? "")).join("");
      return String(pieceText || t?.defaultPattern || t?.content || "").trim();
    }
    function barrageCommentUser(d){
      const ug=d?.userGradeParam, fg=d?.fansLevelParam;
      const u=ug?.user ?? fg?.user ?? d?.user ?? d?.userDetails ?? null;
      if(u) return u;
      const pieces=[...(d?.content?.pieces||[]),...(d?.commonBarrageContent?.pieces||[])];
      for(const p of pieces){ if(p?.userValue?.user) return p.userValue.user; }
      return null;
    }

    client.on(EventType.chat, d => {
      if(rememberCommentId(d)) return;
      // コメントはギフレベ/ファンレベの有無に関係なく必ず受信・集計する。
      const comment = String(d?.content ?? d?.comment ?? d?.message?.content ?? d?.message?.comment ?? "").trim();
      const sender = userName(d) || "誰か";
      totalComments += 1;
      updateBingoDashboardMetrics();

      let dv = null;
      try {
        dv = dashboardUser(d);
      } catch (err) {
        // 任意のユーザー情報が欠けていてもコメント処理を止めない。
        const u = d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData ?? {};
        const fallbackId = String(u?.id ?? u?.uid ?? u?.userId ?? u?.user_id ?? u?.uniqueId ?? u?.unique_id ?? sender).trim() || sender;
        dv = { id: fallbackId, name: sender, likes: 0, giftValue: 0, gifts: 0, comments: 0, follows: 0, gifterLevel: null, memberLevel: null };
        if (!viewerStats.has(fallbackId)) viewerStats.set(fallbackId, {...dv});
      }

      dv.comments += 1;
      monthlyComment(d, 1);
      cumulativeComment(d, 1);
      const commentUser = commentRanking.get(dv.id) || {id: dv.id, name: sender, comments: 0, gifterLevel: null, memberLevel: null};
      commentUser.name = sender || commentUser.name;
      commentUser.gifterLevel = dv.gifterLevel ?? commentUser.gifterLevel;
      commentUser.memberLevel = dv.memberLevel ?? commentUser.memberLevel;
      commentUser.comments += 1;
      commentRanking.set(dv.id, commentUser);
      touchListener(d,"comment",1,0,comment);
      addDashboardLog(`💬 ${sender} → ${comment || "コメント"}`);
      const birthdayId=birthdayUserId(d,sender);
      const parsedBirthday=parseBirthday(comment);
      if(parsedBirthday){
        const prev=birthdayUsers[birthdayId];
        birthdayUsers[birthdayId]={id:birthdayId,name:sender,month:parsedBirthday.month,day:parsedBirthday.day,updatedAt:new Date().toISOString()};
        saveBirthdays();
        const action=prev ? `変更 ${prev.month}月${prev.day}日 → ${parsedBirthday.month}月${parsedBirthday.day}日` : `登録 ${parsedBirthday.month}月${parsedBirthday.day}日`;
        log(`🎂 誕生日${action}：${sender} (@${birthdayId})`);
        broadcast({type:"birthdayRegistered",user:{id:birthdayId,name:sender},birthday:parsedBirthday,updated:!!prev,previous:prev?{month:prev.month,day:prev.day}:null});
      } else {
        const bd=birthdayUsers[birthdayId];
        const today=birthdayTodayMonthDay();
        if(bd && bd.month===today.month && bd.day===today.day){
          const key=`${birthdayId}:${today.month}-${today.day}`;
          if(!birthdayNotifiedToday.has(key)){
            birthdayNotifiedToday.add(key);
            log(`🎉 誕生日コメント：${sender} (@${birthdayId})`);
            broadcast({type:"birthdayToday",user:{id:birthdayId,name:sender},birthday:{month:bd.month,day:bd.day}});
          }
        }
      }
      scheduleDashboardBroadcast();

      // TikTok comment emotes are normally embedded in WebcastChatMessage.emotes.
      // PirateTok's current JS schema did not expose field 13, so patching the
      // local protobuf schema above lets us receive the actual emoteId here.
      const embeddedEmotes = Array.isArray(d?.emotesList) ? d.emotesList : (Array.isArray(d?.emotes) ? d.emotes : []);
      if (embeddedEmotes.length) emoteDebug("chatEmotes", {sender, emotes: embeddedEmotes});
      for (const item of embeddedEmotes) {
        const emoteId = String(item?.emote?.emoteId ?? item?.emoteId ?? item?.id ?? item?.emote?.id ?? "").trim();
        if (!emoteId) continue;
        const emoteName = String(item?.emote?.name ?? item?.emoteName ?? item?.emote?.emoteId ?? emoteId).trim();
        const msgId = String(d?.common?.msgId ?? d?.common?.msgID ?? d?.msgId ?? "");
        const key = `${msgId}:${emoteId}:${item?.index ?? ""}`;
        if (recentEmoteEvents.has(key)) continue;
        recentEmoteEvents.set(key, Date.now());
        setTimeout(() => recentEmoteEvents.delete(key), 5000);

        const sounds = activeEmoteConfig()[emoteId];
        log(`😊 [${profileNames[activeProfile] || activeProfile}] ${sender} → エモートID:${emoteId}`);
        if (Array.isArray(sounds) && sounds.length) {
          const chosen = sounds[Math.floor(Math.random() * sounds.length)];
          broadcastVoiceEvent({
            type: "emoteVoice", emoteId, emoteName, sender,
            url: chosen.url, soundName: chosen.name || "sound",
            volume: Number(chosen.volume ?? 1), profile: activeProfile
          });
        }
      }

      if (!comment) {
        log(`💬 コメント受信（本文なし）`);
        return;
      }
      broadcast({type:"chat", sender, comment, profile:activeProfile,
        profileName:profileNames[activeProfile] || activeProfile});
      log(`💬 [${profileNames[activeProfile] || activeProfile}] ${sender} → ${comment}`);
    });

    // 一部のTikTok配信ではギフレベ0/バッジ無しユーザーのコメントが
    // WebcastBarrageMessage(COMMONBARRAGE/NORMAL) 側で届くことがある。
    // 通常のWebcastChatMessageと同じコメントとして扱い、重複はmsgIdで除外する。
    client.on(EventType.barrage, d => {
      const msgType=Number(d?.msgType ?? d?.msg_type ?? 0);
      if(msgType!==3 && msgType!==100) return;
      if(rememberCommentId(d)) return;
      const comment=textFromBarrageText(d?.content) || textFromBarrageText(d?.commonBarrageContent);
      if(!comment) return;
      const u=barrageCommentUser(d) || {};
      const sender=String(u?.nickname ?? u?.uniqueId ?? u?.unique_id ?? u?.displayName ?? "誰か");
      totalComments += 1;
      updateBingoDashboardMetrics();
      let dv=dashboardUser({user:u});
      dv.comments += 1;
      monthlyComment({user:u},1);
      cumulativeComment({user:u},1);
      const commentUser=commentRanking.get(dv.id)||{id:dv.id,name:sender,comments:0,gifterLevel:null,memberLevel:null};
      commentUser.name=sender||commentUser.name; commentUser.gifterLevel=dv.gifterLevel??commentUser.gifterLevel; commentUser.memberLevel=dv.memberLevel??commentUser.memberLevel; commentUser.comments+=1; commentRanking.set(dv.id,commentUser);
      touchListener({user:u},"comment",1,0,comment,{userId:dv.id,name:sender});
      addDashboardLog(`💬 ${sender} → ${comment}`);
      scheduleDashboardBroadcast();
      broadcast({type:"chat",sender,comment,profile:activeProfile,profileName:profileNames[activeProfile]||activeProfile});
      log(`💬 [${profileNames[activeProfile]||activeProfile}] ${sender} → ${comment}`);
    });

    // PirateTok uses emoteChat (not emote) for TikTok comment emotes.
    // Keep extraction deliberately tolerant because the decoded protobuf shape
    // can differ between TikTok emote variants.
    if (EventType.emoteChat) {
      client.on(EventType.emoteChat, d => {
        const sender = userName(d);
        emoteDebug("emoteChat", d);
        const found = [];

        // Explicitly read TikTok's WebcastEmoteChatMessage.emoteList and WebcastChatMessage.emotesList.
        for (const list of [d?.emoteList, d?.emotesList, d?.emotes].filter(Array.isArray)) {
          for (const item of list) {
            const id = item?.emoteId ?? item?.emote_id ?? item?.id ?? item?.emote?.emoteId ?? item?.emote?.id;
            const name = item?.name ?? item?.emoteName ?? item?.emote_name ?? item?.emote?.name ?? id;
            if (id !== undefined && id !== null && String(id).trim()) found.push({id:String(id).trim(), name:String(name ?? id).trim()});
          }
        }

        const walk = (value, parent = null) => {
          if (!value || typeof value !== "object") return;
          if (Array.isArray(value)) {
            for (const item of value) walk(item, parent);
            return;
          }

          const id = value.emoteId ?? value.emote_id ?? value.id ?? value.emote?.id ?? value.emote?.emoteId;
          const name = value.emoteName ?? value.emote_name ?? value.name ?? value.emote?.name ?? value.emote?.emoteName;
          if (id !== undefined && id !== null && String(id).trim()) {
            found.push({
              id: String(id).trim(),
              name: String(name ?? id).trim()
            });
          }
          for (const [key, child] of Object.entries(value)) {
            // Avoid walking huge binary-ish fields.
            if (key === "payload" || key === "raw" || key === "bytes") continue;
            walk(child, value);
          }
        };

        walk(d);

        const unique = [];
        const seen = new Set();
        for (const item of found) {
          const key = `${item.id}::${item.name}`;
          if (seen.has(key)) continue;
          seen.add(key);
          unique.push(item);
        }

        if (!unique.length) {
          log(`😊 [${profileNames[activeProfile] || activeProfile}] ${sender} → エモート受信（ID取得不可）`);
          log(`🧪 エモート受信データ: ${JSON.stringify(d).slice(0, 1000)}`);
          return;
        }

        for (const {id: emoteId, name: emoteName} of unique) {
          const commonId = String(d?.common?.msgId ?? d?.common?.msgID ?? d?.msgId ?? "");
          const key = `${commonId}:${emoteId}:event`;
          if (recentEmoteEvents.has(key)) continue;
          recentEmoteEvents.set(key, Date.now());
          setTimeout(() => recentEmoteEvents.delete(key), 5000);

          const sounds = activeEmoteConfig()[emoteId];
          log(`😊 [${profileNames[activeProfile] || activeProfile}] ${sender} → ${emoteName} (ID:${emoteId})`);
          if (!Array.isArray(sounds) || !sounds.length) continue;
          const chosen = sounds[Math.floor(Math.random() * sounds.length)];
          broadcastVoiceEvent({
            type: "emoteVoice",
            emoteId,
            emoteName,
            sender,
            url: chosen.url,
            soundName: chosen.name || "sound",
            volume: Number(chosen.volume ?? 1),
            profile: activeProfile
          });
        }
      });
    }

    if (EventType.member) {
      client.on(EventType.member, d => {
        const sender = userName(d);
        const mu=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??{};
        dashboardEntry(d,{
          gifterLevel: extractBadgeLevel(mu, 8),
          memberLevel: Math.max(extractBadgeLevel(mu, 10), Number(mu?.fansClub?.data?.level ?? mu?.fansClub?.level) || 0) || null
        });
        if (monthlyEntry(d)) cumulativeEntry(d);
        touchListener(d,"entry",1);
        broadcast({type:"member", sender, profile:activeProfile, profileName:profileNames[activeProfile] || activeProfile, monthly:monthlySnapshot()});
        addDashboardLog(`🚪 ${sender} が入室`);
        scheduleDashboardBroadcast();
      });
    }
    if (EventType.barrage) {
      client.on(EventType.barrage, d => {
        emoteDebug("barrage", d);
        const x=dashboardBarrageEntry(d);
        if(!x) return;
        const sender=x.name;
        const entryData=x._data || d;
        if (monthlyEntry(entryData)) cumulativeEntry(entryData);
        touchListener(entryData,"entry",1,{userId:x.id,name:sender});
        broadcast({type:"member", sender, profile:activeProfile, profileName:profileNames[activeProfile] || activeProfile, monthly:monthlySnapshot()});
        // 高ギフレベ・メンレベ入室も「入室」ログとして残す。
        // EventType.join 側でも同じ入室が来る場合があるため、短時間の重複を抑止する。
        const levelKey = `${String(x.id)}:${String(sender)}:${Math.floor(Date.now()/5000)}`;
        if (!globalThis.__highLevelJoinLogKeys) globalThis.__highLevelJoinLogKeys = new Set();
        if (!globalThis.__highLevelJoinLogKeys.has(levelKey)) {
          globalThis.__highLevelJoinLogKeys.add(levelKey);
          setTimeout(() => globalThis.__highLevelJoinLogKeys.delete(levelKey), 7000);
          const lvText = [x.gifterLevel ? `🎁Lv${x.gifterLevel}` : "", x.memberLevel ? `👥Lv${x.memberLevel}` : ""].filter(Boolean).join(" ");
          addDashboardLog(`🚪 ${sender} が入室${lvText ? ` (${lvText})` : ""}`);
        }
        scheduleDashboardBroadcast();
      });
    }
    if (EventType.join) {
      client.on(EventType.join, d => {
        const sender = userName(d);
        if (!sender || sender === "誰か") return;
        const ju=d?.user??d?.userDetails??d?.userInfo??d?.from??d?.sender??{};
        dashboardEntry(d,{
          gifterLevel: extractBadgeLevel(ju, 8),
          memberLevel: Math.max(extractBadgeLevel(ju, 10), Number(ju?.fansClub?.data?.level ?? ju?.fansClub?.level) || 0) || null
        });
        if (monthlyEntry(d)) cumulativeEntry(d);
        touchListener(d,"entry",1);
        broadcast({type:"member", sender, profile:activeProfile, profileName:profileNames[activeProfile] || activeProfile, monthly:monthlySnapshot()});
        scheduleDashboardBroadcast();
      });
    }

    client.on(EventType.like, d => {
      const stats = likeAccumulator.process(d || {});
      // TikTokの「LIVE累計いいね」を優先して扱う。
      // count は今回イベント分、total はLIVE開始からの累計なので、
      // カウントダウンの「○いいねごと」判定には total を使用する。
      const rawCount = Number(d?.count ?? d?.likeCount ?? d?.like_count ?? 0);
      const rawTotal = Number(d?.total ?? d?.totalLikeCount ?? d?.total_like_count ?? 0);
      let delta = Number.isFinite(rawCount) && rawCount > 0 ? Math.floor(rawCount) : 0;
      if (Number.isFinite(rawTotal) && rawTotal > 0) {
        const currentTotal = Math.floor(rawTotal);
        if (!likeBaselineInitialized) {
          likeFallbackTotal = currentTotal;
          likeBaselineInitialized = true;
          liveLikeTotal = currentTotal;
          // 受信いいねは「このLIVE中に受信したいいね」のみ。
          // 起動時のTikTok累計いいねは受信分に含めない。
          receivedLikeTotal = 0;
          // 起動前の累計をランキングには加算しない。
          likeMilestone = Math.floor(currentTotal / Math.max(1, Math.floor(Number(countdownSettings.likeThreshold) || 1000)));
          const socialLikeCfg = activeSocialConfig();
          const socialLikeThreshold = Math.max(1, Math.floor(Number(socialLikeCfg.likeThreshold) || 1000));
          likeSoundMilestone = Math.floor(currentTotal / socialLikeThreshold);
          broadcast({type:"likeRanking", totalLikes:liveLikeTotal, viewers:likeRanking.size, ranking:[...likeRanking.values()].map((x,i)=>({rank:i+1,...x}))});
          scheduleDashboardBroadcast();
          log(`❤️ 起動時の累計いいねを基準値として設定：${currentTotal.toLocaleString()}（起動前分は加算しません）`);
          delta = 0;
        } else {
          const totalDelta = currentTotal - Number(likeFallbackTotal || 0);
          delta = totalDelta > 0 ? Math.floor(totalDelta) : 0;
          likeFallbackTotal = Math.max(Number(likeFallbackTotal || 0), currentTotal);
        }
      }
      const accumulatorDelta = Number(stats?.eventLikeCount);
      if (delta <= 0 && Number.isFinite(accumulatorDelta) && accumulatorDelta > 0) delta = Math.floor(accumulatorDelta);
      delta = Math.max(0, delta);
      const sender = userName(d);

      if (delta > 0) {
        // 表示と加算判定はTikTok側が持つLIVE累計いいね数を使用する。
        // total が取れないイベントだけ、受信したdeltaをフォールバックする。
        if (Number.isFinite(rawTotal) && rawTotal > 0) {
          // TikTok累計いいねはTikTok側の累計値をそのまま表示。
          // 受信いいねはLIVE中に増えた差分だけを加算する。
          liveLikeTotal = Math.floor(rawTotal);
          receivedLikeTotal += delta;
        } else {
          receivedLikeTotal += delta;
          updateBingoDashboardMetrics();
          // totalが取得できない場合だけ受信累計を表示値としてフォールバック。
          liveLikeTotal = receivedLikeTotal;
        }
        const user = d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData ?? {};
        const userId = String(user?.id ?? user?.uid ?? user?.uniqueId ?? user?.unique_id ?? sender).trim() || sender;
        const dv = dashboardUser(d);
        dv.likes += delta;
        addDashboardLog(`❤️ ${sender} がいいね ×${delta}`);

        const current = likeRanking.get(userId) || { id: userId, name: sender, likes: 0, gifterLevel: null, memberLevel: null };
        current.name = sender || current.name || "誰か";
        current.gifterLevel = dv.gifterLevel ?? current.gifterLevel; current.memberLevel = dv.memberLevel ?? current.memberLevel;
        current.likes += delta;
        likeRanking.set(userId, current);
        monthlyLike(d, delta);
        cumulativeLike(d, delta);
        touchListener(d,"like",delta);

        const ranking = [...likeRanking.values()]
          .sort((a, b) => b.likes - a.likes || a.name.localeCompare(b.name, "ja"))
          .slice(0, 100)
          .map((x, i) => ({ rank: i + 1, ...x }));
        broadcast({type:"likeRanking",totalLikes:liveLikeTotal,viewers:likeRanking.size,ranking});
        scheduleDashboardBroadcast();

        // TikTokのLIVE累計いいね数を基準に、設定した区切りの到達回数を判定する。
        const threshold = Math.max(1, Math.floor(Number(countdownSettings.likeThreshold) || 1000));
        const currentMilestone = Math.floor(liveLikeTotal / threshold);
        const previousMilestone = likeMilestone;
        if (currentMilestone > previousMilestone) {
          const crossed = currentMilestone - previousMilestone;
          likeMilestone = currentMilestone;
          const addEach = Math.max(0, Math.floor(Number(countdownSettings.likeAddValue) || 0));
          const countdownAdd = addEach * crossed;
          if (countdownAdd > 0) {
            broadcast({
              type:"countdownSocial",
              socialType:"like",
              sender,
              addValue:countdownAdd,
              label:`いいね ${threshold.toLocaleString("ja-JP")}ごと`
            });
          }
          log(`❤️ TikTok累計いいね ${liveLikeTotal.toLocaleString()}（今回+${delta}）→ ${threshold.toLocaleString()}ごとの到達 ×${crossed}`);
        }

        // いいねSEはカウントダウンのいいね設定とは完全分離。
        // ギフト音声設定で指定した閾値を、ライブ中に受信したいいね累計が跨いだ時に再生する。
        // カウントダウン側の閾値が違っていても、いいねSEは独立して判定する。
        const socialLikeCfg = activeSocialConfig();
        const socialLikeThreshold = Math.max(1, Math.floor(Number(socialLikeCfg.likeThreshold) || 1000));
        const socialLikeSounds = (Array.isArray(socialLikeCfg.likeSounds) ? socialLikeCfg.likeSounds : []).filter(x => x?.enabled !== false && x?.url);
        const currentSoundMilestone = Math.floor(liveLikeTotal / socialLikeThreshold);
        const previousSoundMilestone = likeSoundMilestone;
        if (currentSoundMilestone > previousSoundMilestone) {
          const crossed = currentSoundMilestone - previousSoundMilestone;
          likeSoundMilestone = currentSoundMilestone;
          if (socialLikeSounds.length) {
            // 複数SEが登録されている場合は、到達するたびランダムに1つ再生。
            for (let i = 0; i < crossed; i++) {
              const chosen = socialLikeSounds[Math.floor(Math.random() * socialLikeSounds.length)];
              broadcastVoiceEvent({
                type: "socialVoice",
                socialType: "like",
                sender,
                url: chosen.url,
                soundName: chosen.name || "sound",
                volume: Number(chosen.volume ?? 1)
              });
            }
          }
          log(`🔊 いいねSE：${liveLikeTotal.toLocaleString("ja-JP")} / ${socialLikeThreshold.toLocaleString("ja-JP")}ごと → ${crossed}回`);
        }
      }
    });

    client.on(EventType.follow, d => {
      const sender = userName(d);
      const user = d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData ?? {};
      const userId = String(user?.id ?? user?.uid ?? user?.uniqueId ?? user?.unique_id ?? sender).trim() || sender;
      if (followedUserIds.has(userId)) {
        log(`➕ フォロー再受信: ${sender}（加算なし）`);
        return;
      }
      followedUserIds.add(userId);
      const cfg = activeSocialConfig();
      const sounds = (Array.isArray(cfg.followSounds) ? cfg.followSounds : []).filter(x => x?.enabled !== false);
      totalFollows += 1;
      const dv = dashboardUser(d); dv.follows += 1;
      addDashboardLog(`➕ ${sender} がフォロー`);
      scheduleDashboardBroadcast();
      log(`➕ フォロー: ${sender}`);
      const countdownAdd = Math.max(0, Math.floor(Number(countdownSettings.followAddValue) || 0));
      if (countdownAdd > 0) broadcast({type:"countdownSocial", socialType:"follow", sender, addValue:countdownAdd, label:"フォロー"});
      if (!sounds.length) return;
      const chosen = sounds[Math.floor(Math.random() * sounds.length)];
      broadcast({type:"follow", sender, profile:activeProfile, profileName:profileNames[activeProfile] || activeProfile});
      broadcastVoiceEvent({
        type: "socialVoice",
        socialType: "follow",
        sender,
        url: chosen.url,
        soundName: chosen.name || "sound",
        volume: Number(chosen.volume ?? 1)
      });
    });

    function handleGiftEvent(d) {
      // 本番ギフトと擬似ギフトは必ずこの共通ハンドラを通る。
      const isPseudoTest = !!d?.__pseudoTest;
      const gift = String(d?.gift?.name ?? "").trim();
      if (!gift) return;
      const receivedGiftId=String(d?.gift?.id ?? d?.gift?.giftId ?? d?.giftId ?? "").trim();
      const receivedDiamond=Math.max(0,Number(d?.gift?.diamondCount ?? d?.diamondCount ?? 0)||0);
      if (!isPseudoTest) upsertGiftCatalog({id:receivedGiftId,internalName:gift,diamondCount:receivedDiamond,source:"received"});

      const sender = userName(d);
      // 受信単位の識別は表示名ではなくTikTokのユーザーIDを優先する。
      // 同名・表示名変更があっても、別ユーザーのコンボを混同しないため。
      const giftUser = d?.user ?? d?.userDetails ?? d?.userInfo ?? d?.from ?? d?.sender ?? d?.userData ?? {};
      const giftUserId = String(
        giftUser?.id ?? giftUser?.uid ?? giftUser?.userId ?? giftUser?.user_id ??
        giftUser?.uniqueId ?? giftUser?.unique_id ?? d?.userId ?? d?.uid ?? sender
      ).trim() || sender;
      const giftType = Number(d?.gift?.type ?? 0) || 0;
      const isCombo = giftType === 1;
      const groupId = String(d?.groupId ?? d?.gift?.groupId ?? "").trim();
      const msgId = String(d?.msgId ?? d?.common?.msgId ?? d?.common?.msgID ?? "").trim();
      const repeatCount = Math.max(1, Math.floor(Number(d?.repeatCount ?? d?.gift?.repeatCount ?? 1) || 1));
      const repeatEnd = Number(d?.repeatEnd ?? d?.gift?.repeatEnd ?? 0) || 0;

      // 通常ギフトは「1イベント=1個」。同じ人・同じギフトでも別msgIdなら別受信。
      // コンボはgroupId単位でrepeatCountの増加分を処理する。
      if (msgId) {
        if (processedMsgIds.has(msgId)) { log(`↩️ 重複ギフトイベントを無視: ${msgId}`); return; }
        processedMsgIds.add(msgId);
        if (processedMsgIds.size > 5000) processedMsgIds.delete(processedMsgIds.values().next().value);
      }

      let delta = 0;
      const now = Date.now();
      if (isCombo && groupId) {
        // コンボの状態は「ユーザーID + ギフトID + groupId」で管理する。
        // 少額/高額を問わず同じルールで、同一ユーザーの同一コンボだけを累積する。
        // giftIdが無い配信データにも対応するため、内部名をフォールバックにする。
        const transactionGiftKey = receivedGiftId || normalizedGiftName(gift);
        const transactionKey = `group:${giftUserId}::${transactionGiftKey}::${groupId}`;
        const finalized = finalizedGiftGroups.get(transactionKey);

        // repeatEnd=1 の直後にTikTok側から同じコンボの遅延/重複イベントが
        // 別msgIdで届くことがある。終了直後だけは「前回の最終値」を保持し、
        // 同じgroupIdを二重計上しない。一定時間後に同じgroupIdが再利用された場合は
        // 新しい取引として扱えるようにTTLを設ける。
        if (finalized && (now - finalized.at) < 15000) {
          delta = Math.max(0, repeatCount - Math.max(0, Number(finalized.lastCount) || 0));
          if (delta > 0) {
            // 終了済み取引では、遅延イベントで最終値が増えた場合だけ差分を受け付ける。
            finalized.lastCount = Math.max(Number(finalized.lastCount) || 0, repeatCount);
            finalized.at = now;
            finalizedGiftGroups.set(transactionKey, finalized);
          } else {
            delta = 0;
          }
        } else {
          const prev = giftStreaks.get(transactionKey);
          const prevCount = prev ? Math.max(0, Number(prev.lastCount) || 0) : 0;
          delta = Math.max(0, repeatCount - prevCount);
          if (repeatEnd === 1) {
            giftStreaks.delete(transactionKey);
            finalizedGiftGroups.set(transactionKey, { lastCount: Math.max(prevCount, repeatCount), at: now });
          } else {
            giftStreaks.set(transactionKey, { lastCount: Math.max(prevCount, repeatCount), lastSeen: now });
          }
        }
      } else if (isCombo) {
        delta = repeatCount;
      } else {
        // piratetok-live-js の GiftStreakTracker と同じ扱い。非コンボは常に1個。
        delta = 1;
      }

            if (delta <= 0) {
        log(`⏳ ${sender} → ${gift} 合計${repeatCount}（今回追加0・groupId:${groupId || "なし"}）`);
        return;
      }
      updateBingoProgress("gift",delta,gift);

      const catalogRow=giftCatalog.find(x=>(receivedGiftId && String(x?.id||"")===receivedGiftId) || normalizeCatalogText(x?.internalName)===normalizeCatalogText(gift));
      const diamondPer=Math.max(0,Number(d?.gift?.diamondCount??d?.diamondCount??catalogRow?.diamondCount??0)||0);
      const value=diamondPer*delta;
      // 受信1回ごとの最終確定値を同じ共通処理で扱う。
      // 高額ギフトでも特別分岐せず、単価×今回増加数でコインを算出する。
      const gv=dashboardUser(d);
      const contributorId=String(gv.id||sender||"").trim();
      updateBingoContributor(contributorId, sender, value);
      handleTimerGift(sender,gift,value);
      totalGiftCount+=delta; totalGiftValue+=value; gv.gifts+=delta; gv.giftValue+=value;
      monthlyGift(d, delta, value);
      cumulativeGift(d, delta, value);
      touchListener(d,"gift",delta,value);
      const gr=giftRanking.get(gv.id)||{id:gv.id,name:sender,gifts:0,value:0,gifterLevel:null,memberLevel:null}; gr.name=sender||gr.name; gr.gifterLevel=gv.gifterLevel??gr.gifterLevel; gr.memberLevel=gv.memberLevel??gr.memberLevel; gr.gifts+=delta; gr.value+=value; giftRanking.set(gv.id,gr);
      const gt=giftTypeRanking.get(gift)||{name:gift,gifts:0,value:0}; gt.gifts+=delta; gt.value+=value; giftTypeRanking.set(gift,gt);
      broadcast({type:"gift", sender, gift, amount:delta, coinValue:value, profile:activeProfile, profileName:profileNames[activeProfile] || activeProfile});
      addDashboardLog(`🎁 ${sender} → ${gift} ×${delta}${value?` (${value} diamond)`:''}`);
      const rouletteGift=Array.isArray(countdownSettings.rouletteGifts)?countdownSettings.rouletteGifts.find(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift)):null;const directMultiplierGift=Array.isArray(countdownSettings.directMultiplierGifts)?countdownSettings.directMultiplierGifts.find(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift)):null;
      if(directMultiplierGift){ log(`🎰 倍ルーレット直接発動ギフト一致: 「${gift}」 ← 設定「${directMultiplierGift.gift}」 / ${sender} ×${delta}`); }const fixedAddGift=Array.isArray(countdownSettings.fixedAddGifts)?countdownSettings.fixedAddGifts.find(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift)):null;const instantZeroGift=Array.isArray(countdownSettings.instantZeroGifts)?countdownSettings.instantZeroGifts.find(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift)):null;if(instantZeroGift){log(`⚡ 即0ギフト一致: 「${gift}」 / ${sender} ×${delta}`);broadcast({type:"countdownInstantZero",sender,gift,amount:delta});}const voiceOnly=Array.isArray(countdownSettings.voiceOnlyGifts)?countdownSettings.voiceOnlyGifts.find(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift)):null;if(directMultiplierGift){broadcast({type:"countdownDirectMultiplierRoulette",sender,gift,amount:delta});}else if(rouletteGift){broadcast({type:"countdownRoulette",sender,gift,winRate:rouletteGift.winRate,amount:delta});}else if(voiceOnly?.url){broadcast({type:"countdownVoiceGift",sender,gift,url:voiceOnly.url,soundName:voiceOnly.soundName||"SE"});}else if(fixedAddGift){broadcast({type:"countdownGift",sender,gift,amount:delta,coinValue:value,addValue:Number(fixedAddGift.addValue)||0,subtractValue:0,deduction:false,fixedAdd:true});}const deductionEnabled=Array.isArray(countdownSettings.deductionGifts)&&countdownSettings.deductionGifts.some(x=>x?.enabled!==false&&giftSettingMatches(x?.gift,gift));const countdownDelta=rouletteGift?(value>0?value:0):(voiceOnly?0:(fixedAddGift?0:(deductionEnabled&&value>0?-value:(value>0?value:0))));broadcast({type:"countdownGift",sender,gift,amount:delta,coinValue:value,addValue:countdownDelta>0?countdownDelta:0,subtractValue:countdownDelta<0?Math.abs(countdownDelta):0,deduction:deductionEnabled});
      scheduleDashboardBroadcast();
      log(`⚡ ${sender} → ${gift} 合計${repeatCount} / 今回+${delta}（${repeatEnd === 1 ? "確定" : "コンボ継続"}・groupId:${groupId || "なし"}）`);
      emitGiftVoice(d, delta);
    }
    // 本番のTikTokギフトイベントを、上で構築した共通ハンドラへ接続。
    // v11でギフト処理本体を関数化した際にリスナー登録が抜けると、
    // 受信イベントが来ても処理されないため、ここで明示的に登録する。
    client.on(EventType.gift, d => handleGiftEvent(d));

    pseudoGiftHandler = handleGiftEvent;

    if (EventType.linkMicBattle) {
      client.on(EventType.linkMicBattle, d => {
        const battleId=String(d?.id||d?.battleId||d?.common?.msgId||"");
        const participants=battleParticipantNames(d);
        if(!participants.length){ addDashboardLog("🥊 バトル開始を検知（参加者情報なし）"); broadcast({type:"battle",data:{event:"start",battleId,participants:[]}}); return; }
        // 自分側は「接続ID(USERNAME)とbattleUsersのuniqueIdが一致した参加者」を唯一の基準にする。
        // 一致しない場合は先頭参加者を自分扱いしない（左右を誤るため）。
        const normalizedUsername=normalizedTikTokId(OWN_UNIQUE_ID||USERNAME);
        const own=findOwnParticipant(participants);
        const ownHostId=String(own?.id||"");
        currentBattle={battleId,startedAt:Date.now(),participants,ownHostId,ownUniqueId:normalizedUsername,ownResolved:!!own,scores:{},scoreHistory:[],gloves:[],mode:"individual",teams:[]};
        const teamSnap=battleTeamSnapshot(d,participants,ownHostId); currentBattle.mode=teamSnap.mode; currentBattle.teams=teamSnap.teams;
        addDashboardLog(own ? `🥊 バトル開始：自分=@${normalizedUsername} を左側に固定` : `🥊 バトル開始：自分=@${normalizedUsername} を参加者IDから特定できませんでした`);
        broadcast({type:"battle",data:{event:"start",battleId,participants,ownHostId,ownUniqueId:normalizedUsername,ownResolved:!!own,ownUserId:OWN_USER_ID,mode:currentBattle.mode,teams:currentBattle.teams,ownTeamId:teamSnap.ownTeamId}});
      });
    }
    if (EventType.linkMicArmies) {
      client.on(EventType.linkMicArmies, d => {
        if(!currentBattle){
          const participants=battleParticipantNames(d);
          const own=findOwnParticipant(participants);
          currentBattle={battleId:String(d?.id||d?.battleId||""),startedAt:Date.now(),participants,ownHostId:String(own?.id||""),ownUniqueId:normalizedTikTokId(OWN_UNIQUE_ID||USERNAME),ownResolved:!!own,scores:{},scoreHistory:[],gloves:[],mode:"individual",teams:[]};
        }
        // バトルスコア更新時にも自分のIDを再照合して、左右が入れ替わらないようにする。
        const scoreParticipants=battleParticipantNames(d);
        if(scoreParticipants.length){
          const merged=[...(currentBattle.participants||[])];
          for(const p of scoreParticipants){
            const same=merged.find(x=>normalizedTikTokId(x?.uniqueId)===normalizedTikTokId(p?.uniqueId) || (p.id && String(x?.id)===String(p.id)));
            if(same){ same.id=same.id||p.id; same.name=same.name||p.name; same.uniqueId=same.uniqueId||p.uniqueId; }
            else merged.push(p);
          }
          const targetOwn=normalizedTikTokId(currentBattle.ownUniqueId||OWN_UNIQUE_ID||USERNAME);
          const detectedInMerged=merged.find(p=>(OWN_USER_ID && String(p?.id||"")===String(OWN_USER_ID)) || normalizedTikTokId(p?.uniqueId)===targetOwn);
          const orderedMerged=(detectedInMerged?[detectedInMerged,...merged.filter(p=>p!==detectedInMerged)]:merged).slice(0,4);
          currentBattle.participants=orderedMerged;
          const detectedOwn=findOwnParticipant(orderedMerged);
          if(detectedOwn){ currentBattle.ownHostId=String(detectedOwn.id||""); currentBattle.ownResolved=true; }
          if(!currentBattle.ownResolved){
            const target=normalizedTikTokId(currentBattle.ownUniqueId||OWN_UNIQUE_ID||USERNAME);
            for(const item of (Array.isArray(d?.battleItems)?d.battleItems:[])){
              const hostId=String(item?.hostUserId??"");
              if(!hostId) continue;
              const hit=(String(hostId)===String(OWN_USER_ID)) || (Array.isArray(item?.battleGroups)?item.battleGroups:[]).some(g=>(Array.isArray(g?.users)?g.users:[]).some(u=>normalizedTikTokId(u?.uniqueId??u?.unique_id??u?.displayId)===target || String(u?.id??u?.userId??u?.uid??"")===String(OWN_USER_ID)));
              if(hit){ currentBattle.ownHostId=String(OWN_USER_ID||hostId); currentBattle.ownResolved=true; break; }
            }
          }
          const teamSnap=battleTeamSnapshot(d,currentBattle.participants,currentBattle.ownHostId); currentBattle.mode=teamSnap.mode; currentBattle.teams=teamSnap.teams;
        }
        const scores=battleScoreMap(d);
        if(Object.keys(scores).length===0){
          addDashboardLog(`🥊 バトルスコアをまだ取得できませんでした（ID照合は継続中）`);
        } else {
          addDashboardLog(`🥊 バトルスコア更新：${Object.keys(scores).length}人分`);
        }
        currentBattle.scores={...currentBattle.scores,...scores};
        currentBattle.scoreHistory.push({time:Date.now(),scores:{...currentBattle.scores}});
        if(currentBattle.scoreHistory.length>300) currentBattle.scoreHistory.shift();
        const status=Number(d?.battleStatus||0);
        broadcast({type:"battle",data:{event:"score",battleId:currentBattle.battleId,scores:currentBattle.scores,status,participants:currentBattle.participants,ownHostId:currentBattle.ownHostId,ownUniqueId:currentBattle.ownUniqueId,ownUserId:OWN_USER_ID,mode:currentBattle.mode,teams:currentBattle.teams,ownTeamId:(battleTeamSnapshot(d,currentBattle.participants,currentBattle.ownHostId)?.ownTeamId||"")}});
        if(status===3) finalizeBattle("battleStatus=ENDED");
      });
    }

    // 現在の piratetok-live-js では新しい BattleItemCard が未定義のため、
    // 未知イベントとして届いた場合でも検知状況を記録する。
    // 取得者を推測せず、実際のイベントが来たことだけを表示する。
    if (EventType.unknown) {
      client.on(EventType.unknown, d => {
        const method=String(d?.method||"");
        // TikTok側の新しい/未対応イベントも、Emote/Barrage/Member/Chat系だけ
        // 最小限ログへ残す。これで「そもそもイベントが届いていない」のか
        // 「届いているがprotobufデコードできていない」のかを切り分けられる。
        if (/Emote|Barrage|Member|Chat/i.test(method)) {
          const payload=d?.payload;
          const payloadLength=payload?.length ?? payload?.byteLength ?? 0;
          emoteDebug("unknownMethod", {method,payloadLength});
        }
        if (/BattleItemCard|Battle.*Card|battle.*item/i.test(method)) {
          addDashboardLog(`🧤 バトルアイテムイベントを検知：${method}`);
          if (currentBattle) {
            currentBattle.gloveDiagnostics=currentBattle.gloveDiagnostics||[];
            currentBattle.gloveDiagnostics.push({time:Date.now(),method});
            if(currentBattle.gloveDiagnostics.length>50) currentBattle.gloveDiagnostics.shift();
          }
          broadcast({type:"battle",data:{event:"gloveDetected",battleId:currentBattle?.battleId||"",method}});
        }
      });
    }

    client.on(EventType.disconnected, d => {
      // LIVE終了レポートは「LIVE終了」ボタンから明示的に保存する。
      // 一時的な切断では履歴を自動保存しない。
      connected = false;
      log("🔌 TikTok LIVE 接続が切れました");
      broadcast({ type: "connection", connected: false, status: "TikTok LIVE 未接続" });
    });

    if (prepareOnly) {
      // TikTokには接続しない。ここまでで本番と同じhandleGiftEventを構築済み。
      // 擬似送信後も通常接続を妨げないようクライアント参照だけ解放する。
      activeTikTokClient = null;
      connected = false;
      liveSetupRunning = false;
      broadcast({ type: "connection", connected: false, status: "擬似ギフトテスト準備完了（TikTok未接続）" });
      log("🧪 擬似ギフトテスト用の本番ギフト処理を準備しました（TikTok未接続）");
      return;
    }

    log(`🔌 TikTok LIVEへ接続を開始: @${USERNAME}`);
    await client.connect();
    // connect()後もWSS接続は継続するため、ここでconnected=falseや
    // activeTikTokClient=nullへ戻さない。connected/disconnectedイベントで管理する。
    liveSetupRunning = false;
    log("📡 TikTok LIVE接続処理が完了しました。接続状態を維持します");
  } catch (e) {
    connected = false;
    const errText = String(e?.message || e || "");
    // LIVE終了直後などに返る「not currently live」は接続障害ではなく待機状態。
    const notLive = /not currently live|currently live|is not live|not live/i.test(errText);
    if (notLive) {
      broadcast({ type: "connection", connected: false, status: "TikTok LIVE 未配信（待機中）" });
      log(`⏸️ TikTok LIVEが終了/未配信になりました。待機します: ${errText}`);
    } else {
      broadcast({ type: "connection", connected: false, status: "接続エラー" });
      log(`❌ TikTok接続エラー: ${errText}`);
    }
    liveSetupRunning = false;
    activeTikTokClient = null;
    scheduleTikTokLiveCheck(notLive ? 5000 : 30000);
  } finally {
    liveSetupRunning = false;
  }
}

let connected = false;

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 30_000_000) {
        reject(new Error("ファイルが大きすぎます"));
        req.destroy();
      }
    });
    req.on("end", () => {
      try { resolve(JSON.parse(body || "{}")); }
      catch (e) { reject(e); }
    });
    req.on("error", reject);
  });
}

function serveStatic(req, res) {
  let pathname = decodeURIComponent(new URL(req.url, `http://${req.headers.host}`).pathname);
  if (pathname === "/") pathname = "/index.html";
  const safe = path.normalize(pathname).replace(/^(\.\.[/\\])+/, "");
  const file = path.join(__dirname, "public", safe);
  if (!file.startsWith(path.join(__dirname, "public"))) {
    res.writeHead(403); return res.end("Forbidden");
  }
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.writeHead(404); return res.end("Not Found");
  }
  const ext = path.extname(file).toLowerCase();
  const types = {
    ".html":"text/html; charset=utf-8",
    ".js":"text/javascript; charset=utf-8",
    ".css":"text/css; charset=utf-8",
    ".json":"application/json; charset=utf-8",
    ".wav":"audio/wav", ".mp3":"audio/mpeg", ".m4a":"audio/mp4",
    ".ogg":"audio/ogg", ".webm":"audio/webm", ".aac":"audio/aac", ".flac":"audio/flac"
  };
  res.writeHead(200, {"Content-Type": types[ext] || "application/octet-stream", "Cache-Control":"no-store"});
  fs.createReadStream(file).pipe(res);
}

const COUNTDOWN_SETTINGS_PATH=path.join(__dirname,"countdown-settings.json");
const COUNTDOWN_AUDIO_DIR=path.join(__dirname,"public","custom-audio","countdown");
fs.mkdirSync(COUNTDOWN_AUDIO_DIR,{recursive:true});
const BINGO_AUDIO_DIR=COUNTDOWN_AUDIO_DIR;
fs.mkdirSync(BINGO_AUDIO_DIR,{recursive:true});
const DEFAULT_COUNTDOWN_SETTINGS={startValue:100,addSoundUrl:"/audio/add.wav",addSoundName:"add.wav",endSoundUrl:"/audio/end.wav",endSoundName:"end.wav",instantZeroSoundUrl:"",instantZeroSoundName:"",deductSoundUrl:"/audio/deduct.wav",deductSoundName:"deduct.wav",followAddValue:0,likeThreshold:1000,likeAddValue:0,deductionGifts:[],voiceOnlyGifts:[],rouletteGifts:[],directMultiplierGifts:[],fixedAddGifts:[],instantZeroGifts:[],rouletteWinRate:50,rouletteDurationSec:30,rouletteSoundUrl:"",rouletteSoundName:"",rouletteStopSoundUrl:"",rouletteStopSoundName:"",rouletteSoundVolume:1,rouletteStopSoundVolume:1,addSoundVolume:1,deductSoundVolume:1,endSoundVolume:1,instantZeroSoundVolume:1,rouletteBgmUrl:"",rouletteBgmName:"",rouletteBgmVolume:0.7};
function loadCountdownSettings(){try{if(!fs.existsSync(COUNTDOWN_SETTINGS_PATH))fs.writeFileSync(COUNTDOWN_SETTINGS_PATH,JSON.stringify(DEFAULT_COUNTDOWN_SETTINGS,null,2));const raw=JSON.parse(fs.readFileSync(COUNTDOWN_SETTINGS_PATH,"utf8"));return {...DEFAULT_COUNTDOWN_SETTINGS,...raw,startValue:Math.max(0,Math.floor(Number(raw?.startValue)||DEFAULT_COUNTDOWN_SETTINGS.startValue)),followAddValue:Math.max(0,Math.floor(Number(raw?.followAddValue)||0)),likeThreshold:Math.max(1,Math.floor(Number(raw?.likeThreshold)||DEFAULT_COUNTDOWN_SETTINGS.likeThreshold)),likeAddValue:Math.max(0,Math.floor(Number(raw?.likeAddValue)||0)),deductionGifts:Array.isArray(raw?.deductionGifts)?raw.deductionGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift):[],voiceOnlyGifts:Array.isArray(raw?.voiceOnlyGifts)?raw.voiceOnlyGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),url:String(x?.url||"").trim(),soundName:String(x?.soundName||x?.name||"SE").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift&&x.url):[],rouletteGifts:Array.isArray(raw?.rouletteGifts)?raw.rouletteGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false,winRate:Math.max(0,Math.min(100,Number(x?.winRate??raw?.rouletteWinRate??DEFAULT_COUNTDOWN_SETTINGS.rouletteWinRate)||0))})).filter(x=>x.gift):[],directMultiplierGifts:Array.isArray(raw?.directMultiplierGifts)?raw.directMultiplierGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift):[],fixedAddGifts:Array.isArray(raw?.fixedAddGifts)?raw.fixedAddGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false,addValue:Math.max(0,Math.floor(Number(x?.addValue)||0))})).filter(x=>x.gift&&x.addValue>0):[],instantZeroGifts:Array.isArray(raw?.instantZeroGifts)?raw.instantZeroGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift):[],rouletteWinRate:Math.max(0,Math.min(100,Number(raw?.rouletteWinRate??DEFAULT_COUNTDOWN_SETTINGS.rouletteWinRate)||DEFAULT_COUNTDOWN_SETTINGS.rouletteWinRate)),rouletteDurationSec:Math.max(1,Math.min(3600,Math.floor(Number(raw?.rouletteDurationSec)||DEFAULT_COUNTDOWN_SETTINGS.rouletteDurationSec))),rouletteSoundUrl:String(raw?.rouletteSoundUrl||"").trim(),rouletteSoundName:String(raw?.rouletteSoundName||"").trim(),rouletteStopSoundUrl:String(raw?.rouletteStopSoundUrl||"").trim(),rouletteStopSoundName:String(raw?.rouletteStopSoundName||"").trim(),rouletteBgmUrl:String(raw?.rouletteBgmUrl||"").trim(),rouletteBgmName:String(raw?.rouletteBgmName||"").trim(),rouletteBgmVolume:Math.max(0,Math.min(1,Number(raw?.rouletteBgmVolume??DEFAULT_COUNTDOWN_SETTINGS.rouletteBgmVolume)||0)),rouletteSoundVolume:Math.max(0,Math.min(1,Number(raw?.rouletteSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.rouletteSoundVolume))),rouletteStopSoundVolume:Math.max(0,Math.min(1,Number(raw?.rouletteStopSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.rouletteStopSoundVolume))),addSoundVolume:Math.max(0,Math.min(1,Number(raw?.addSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.addSoundVolume))),deductSoundVolume:Math.max(0,Math.min(1,Number(raw?.deductSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.deductSoundVolume))),endSoundVolume:Math.max(0,Math.min(1,Number(raw?.endSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.endSoundVolume))),instantZeroSoundVolume:Math.max(0,Math.min(1,Number(raw?.instantZeroSoundVolume??DEFAULT_COUNTDOWN_SETTINGS.instantZeroSoundVolume))),instantZeroSoundUrl:String(raw?.instantZeroSoundUrl||"").trim(),instantZeroSoundName:String(raw?.instantZeroSoundName||"").trim()};}catch{return {...DEFAULT_COUNTDOWN_SETTINGS}}}
let countdownSettings=loadCountdownSettings();
function saveCountdownSettings(){fs.writeFileSync(COUNTDOWN_SETTINGS_PATH,JSON.stringify(countdownSettings,null,2));}


const TIMER_SETTINGS_PATH=path.join(__dirname,"timer-settings.json");
const DEFAULT_TIMER_SETTINGS={startSeconds:0,addGifts:[],subtractGifts:[],addSoundUrl:"",addSoundName:"",subtractSoundUrl:"",subtractSoundName:"",endSoundUrl:"",endSoundName:"",instantZeroSoundUrl:"",instantZeroSoundName:"",instantZeroGifts:[],addSoundVolume:1,subtractSoundVolume:1,endSoundVolume:1,instantZeroSoundVolume:1,homeGiftVolume:1};
function loadTimerSettings(){try{if(!fs.existsSync(TIMER_SETTINGS_PATH))fs.writeFileSync(TIMER_SETTINGS_PATH,JSON.stringify(DEFAULT_TIMER_SETTINGS,null,2));const x=JSON.parse(fs.readFileSync(TIMER_SETTINGS_PATH,"utf8"));return {...DEFAULT_TIMER_SETTINGS,...x,addGifts:Array.isArray(x?.addGifts)?x.addGifts.map(g=>({coins:Math.max(1,Math.floor(Number(g?.coins??g?.coinValue)||1)),seconds:Math.max(1,Math.floor(Number(g?.seconds)||1)),enabled:g?.enabled!==false})).filter(g=>g.coins):[],subtractGifts:Array.isArray(x?.subtractGifts)?x.subtractGifts.map(g=>({coins:Math.max(1,Math.floor(Number(g?.coins??g?.coinValue)||1)),seconds:Math.max(1,Math.floor(Number(g?.seconds)||1)),enabled:g?.enabled!==false})).filter(g=>g.coins):[],instantZeroGifts:Array.isArray(x?.instantZeroGifts)?x.instantZeroGifts.map(g=>({gift:String(g?.gift||g?.name||"").trim(),enabled:g?.enabled!==false})).filter(g=>g.gift):[],startSeconds:Math.max(0,Math.min(864000,Math.floor(Number(x?.startSeconds)||0))),addSoundVolume:Math.max(0,Math.min(1,Number(x?.addSoundVolume??1))),subtractSoundVolume:Math.max(0,Math.min(1,Number(x?.subtractSoundVolume??1))),endSoundVolume:Math.max(0,Math.min(1,Number(x?.endSoundVolume??1))),instantZeroSoundVolume:Math.max(0,Math.min(1,Number(x?.instantZeroSoundVolume??1))),homeGiftVolume:Math.max(0,Math.min(1,Number(x?.homeGiftVolume??1)))};}catch{return {...DEFAULT_TIMER_SETTINGS}}}
let timerSettings=loadTimerSettings(); function saveTimerSettings(){fs.writeFileSync(TIMER_SETTINGS_PATH,JSON.stringify(timerSettings,null,2));}
let timerState={active:false,seconds:timerSettings.startSeconds,addTotal:0,subtractTotal:0,ended:false};
let timerInstantZeroTimer=null;
function clearTimerInstantZero(){if(timerInstantZeroTimer){clearTimeout(timerInstantZeroTimer);timerInstantZeroTimer=null;}}
function timerSnapshot(){return {settings:timerSettings,state:timerState};}
function timerBroadcast(){broadcast({type:"timerState",state:timerState,settings:timerSettings});}
function timerReset(){clearTimerInstantZero();timerState={active:true,seconds:Math.max(0,timerSettings.startSeconds),addTotal:0,subtractTotal:0,ended:false};timerBroadcast();}
function timerFinish(reason="timeout",sender=""){clearTimerInstantZero();if(timerState.ended)return;const previousSeconds=Number(timerState.seconds||0);timerState.seconds=0;timerState.ended=true;timerState.active=false;broadcast({type:"timerZero",reason,sender:String(sender||""),previousSeconds,state:timerState});timerBroadcast();}
function timerInstantZero(sender="即0"){
  if(timerState.ended || timerInstantZeroTimer) return;
  const previousSeconds=Math.max(0,Math.floor(Number(timerState.seconds)||0));
  if(previousSeconds<=0){timerFinish("instantZero",sender);return;}
  // 即0はサーバー側でも5秒間は元の数字を保持し、画面側の演出と同期させる。
  // ここで0へ変更してしまうと、SSEのtimerStateが先に届いて即0表示になってしまう。
  timerState.active=false;
  broadcast({type:"timerZero",reason:"instantZero",sender:String(sender||""),previousSeconds,state:timerState});
  timerInstantZeroTimer=setTimeout(()=>{
    timerInstantZeroTimer=null;
    if(timerState.ended)return;
    timerState.seconds=0;
    timerState.ended=true;
    timerState.active=false;
    timerBroadcast();
  },5000);
}
setInterval(()=>{if(!timerState.active)return;timerState.seconds=Math.max(0,Number(timerState.seconds||0)-1);if(timerState.seconds<=0){timerFinish("timeout");return;}timerBroadcast();},1000);
function timerAdjust(delta,reason="manual",meta={}){if(!timerState.active)return;const n=Math.floor(Number(delta)||0);if(!n)return;const before=timerState.seconds;timerState.seconds=Math.max(0,Math.min(864000,before+n));if(n>0)timerState.addTotal+=n;else timerState.subtractTotal+=Math.abs(n);if(timerState.seconds<=0){timerFinish("adjust",String(meta?.sender||""));return;}broadcast({type:"timerAdjust",delta:n,reason,sender:String(meta?.sender||""),state:timerState});timerBroadcast();}
function handleTimerGift(sender,gift,value){if(!timerState.active||value<=0)return;const instant=Array.isArray(timerSettings.instantZeroGifts)&&timerSettings.instantZeroGifts.some(x=>x.enabled!==false&&String(x.gift||"").trim()===String(gift||"").trim());if(instant){timerInstantZero(sender);return;}const add=[...timerSettings.addGifts].filter(x=>x.enabled!==false&&Number(value)===Number(x.coins||0))[0];const sub=[...timerSettings.subtractGifts].filter(x=>x.enabled!==false&&Number(value)===Number(x.coins||0))[0];if(add){timerAdjust(add.seconds,"giftAdd",{sender});return;}if(sub){timerAdjust(-sub.seconds,"giftSubtract",{sender});}}

const BINGO_SETTINGS_PATH=path.join(__dirname,"bingo-settings.json");
const BINGO_TEMPLATES_PATH=path.join(__dirname,"bingo-templates.json");
const DEFAULT_BINGO_SIZE=3;
function blankBingoCell(){return {type:"manual",gift:"",contributorDigits:3,target:1,label:"手動達成"};}
const DEFAULT_BINGO_AUDIO={markSoundUrl:"",markSoundName:"",bingoSoundUrl:"",bingoSoundName:"",markSoundVolume:1,bingoSoundVolume:1};
function normalizeBingoCell(x){
  const type=["gift","like","comment","contributor","manual"].includes(String(x?.type||""))?String(x.type):"manual";
  const target=Math.max(1,Math.min(999999999999,Math.floor(Number(x?.target)||1)));
  const gift=String(x?.gift||"").trim();
  const contributorDigits=Math.max(1,Math.min(9,Math.floor(Number(x?.contributorDigits)||3)));
  const label=String(x?.label||"").trim().slice(0,80);
  return {type,gift,contributorDigits,target,label};
}
function normalizeBingoSettings(x){
  const size=[3,4,5].includes(Number(x?.size))?Number(x.size):DEFAULT_BINGO_SIZE;
  const count=size*size;
  const cells=Array.from({length:count},(_,i)=>normalizeBingoCell(Array.isArray(x?.cells)?x.cells[i]:null));
  return {size,cells,updatedAt:String(x?.updatedAt||""),markSoundUrl:String(x?.markSoundUrl||""),markSoundName:String(x?.markSoundName||""),bingoSoundUrl:String(x?.bingoSoundUrl||""),bingoSoundName:String(x?.bingoSoundName||""),markSoundVolume:Math.max(0,Math.min(1,Number(x?.markSoundVolume??1))),bingoSoundVolume:Math.max(0,Math.min(1,Number(x?.bingoSoundVolume??1)))};
}
function loadBingoSettings(){
  try{
    if(!fs.existsSync(BINGO_SETTINGS_PATH)) fs.writeFileSync(BINGO_SETTINGS_PATH,JSON.stringify({size:3,cells:Array.from({length:9},blankBingoCell()),...DEFAULT_BINGO_AUDIO},null,2));
    return normalizeBingoSettings(JSON.parse(fs.readFileSync(BINGO_SETTINGS_PATH,"utf8")));
  }catch{return {size:3,cells:Array.from({length:9},blankBingoCell())};}
}
let bingoSettings=loadBingoSettings();
function saveBingoSettings(){fs.writeFileSync(BINGO_SETTINGS_PATH,JSON.stringify(bingoSettings,null,2));}
function loadBingoTemplates(){try{if(!fs.existsSync(BINGO_TEMPLATES_PATH))fs.writeFileSync(BINGO_TEMPLATES_PATH,"[]");const a=JSON.parse(fs.readFileSync(BINGO_TEMPLATES_PATH,"utf8"));return Array.isArray(a)?a:[];}catch{return [];}}
let bingoTemplates=loadBingoTemplates();
function saveBingoTemplates(){fs.writeFileSync(BINGO_TEMPLATES_PATH,JSON.stringify(bingoTemplates,null,2));}
let bingoState={active:false,size:bingoSettings.size,cells:[],lines:[],startedAt:"",completed:false};
let bingoContributorTotals=new Map();
let bingoQualifiedContributors=new Set();
let bingoLikeBaseline=0;
let bingoCommentBaseline=0;
function resetBingoState(){bingoContributorTotals=new Map();for(const [id,u] of viewerStats.entries()){const v=Math.max(0,Number(u?.giftValue||0));if(v>0)bingoContributorTotals.set(String(id),v);}bingoQualifiedContributors=new Set();bingoLikeBaseline=Math.max(0,Number(receivedLikeTotal||0));bingoCommentBaseline=Math.max(0,Number(totalComments||0));bingoState={active:true,size:bingoSettings.size,cells:bingoSettings.cells.map(x=>({progress:0,achieved:false})),lines:[],startedAt:new Date().toISOString(),completed:false};broadcast({type:"bingoState",state:bingoState});}
function bingoLineKeys(size){const lines=[];for(let r=0;r<size;r++)lines.push(Array.from({length:size},(_,c)=>r*size+c));for(let c=0;c<size;c++)lines.push(Array.from({length:size},(_,r)=>r*size+c));lines.push(Array.from({length:size},(_,i)=>i*size+i));lines.push(Array.from({length:size},(_,i)=>i*size+(size-1-i)));return lines;}
function checkBingo(){const size=bingoState.size;const achieved=bingoState.cells.map(x=>!!x?.achieved);const lines=bingoLineKeys(size).map((cells,i)=>({index:i,cells,bingo:cells.every(n=>achieved[n])})).filter(x=>x.bingo).map(x=>x.index);const old=bingoState.lines||[];bingoState.lines=lines;bingoState.completed=lines.length>0;return lines.filter(x=>!old.includes(x));}
function bingoLabel(cell){if(cell.label)return cell.label;if(cell.type==="gift")return `${cell.gift||"ギフト"} ${cell.target}個`;if(cell.type==="like")return `いいね ${cell.target.toLocaleString("ja-JP")}`;if(cell.type==="comment")return `コメント ${cell.target}件`;if(cell.type==="contributor")return `${cell.contributorDigits||3}桁貢献者 ${cell.target}人`;return "手動達成";}
function updateBingoDashboardMetrics(){
  if(!bingoState.active)return;
  const likeDelta=Math.max(0,Number(receivedLikeTotal||0)-Number(bingoLikeBaseline||0));
  const commentDelta=Math.max(0,Number(totalComments||0)-Number(bingoCommentBaseline||0));
  let changed=[];
  for(let i=0;i<bingoSettings.cells.length;i++){
    const cfg=bingoSettings.cells[i],st=bingoState.cells[i];
    if(!cfg||!st||st.achieved)continue;
    if(cfg.type==='like'){st.progress=Math.min(cfg.target,likeDelta);if(st.progress>=cfg.target){st.progress=cfg.target;st.achieved=true;changed.push(i);}}
    else if(cfg.type==='comment'){st.progress=Math.min(cfg.target,commentDelta);if(st.progress>=cfg.target){st.progress=cfg.target;st.achieved=true;changed.push(i);}}
  }
  const newLines=checkBingo();
  if(changed.length||newLines.length)broadcast({type:"bingoAchieved",cells:changed,lines:newLines,state:bingoState,sounds:{mark:bingoSettings.markSoundUrl,bingo:bingoSettings.bingoSoundUrl,markVolume:bingoSettings.markSoundVolume,bingoVolume:bingoSettings.bingoSoundVolume}});
  else broadcast({type:"bingoState",state:bingoState});
}
function updateBingoProgress(type, amount=1, giftName=""){
  if(!bingoState.active)return;
  let changed=[];
  for(let i=0;i<bingoSettings.cells.length;i++){
    const cfg=bingoSettings.cells[i], st=bingoState.cells[i]; if(!cfg||!st||st.achieved)continue;
    let match=false;
    if(cfg.type==="gift") match=!!cfg.gift && giftSettingMatches(cfg.gift,giftName);
    else if(cfg.type===type) match=true;
    if(!match)continue;
    st.progress=Math.min(cfg.target,Number(st.progress||0)+Math.max(0,Number(amount)||0));
    if(st.progress>=cfg.target){st.progress=cfg.target;st.achieved=true;changed.push(i);}
  }
  const newLines=checkBingo();
  if(changed.length||newLines.length) broadcast({type:"bingoAchieved",cells:changed,lines:newLines,state:bingoState,sounds:{mark:bingoSettings.markSoundUrl,bingo:bingoSettings.bingoSoundUrl,markVolume:bingoSettings.markSoundVolume,bingoVolume:bingoSettings.bingoSoundVolume}});
  else broadcast({type:"bingoState",state:bingoState});
}
function updateBingoContributor(userId,userName,coinValue){
  if(!bingoState.active||!userId||coinValue<=0)return;
  const id=String(userId);
  const prev=Number(bingoContributorTotals.get(id)||0);
  const next=prev+Number(coinValue||0);
  bingoContributorTotals.set(id,next);
  let changed=[];
  for(let i=0;i<bingoSettings.cells.length;i++){
    const cfg=bingoSettings.cells[i],st=bingoState.cells[i];
    if(!cfg||!st||st.achieved||cfg.type!=="contributor")continue;
    const digits=Math.max(1,Math.min(9,Math.floor(Number(cfg.contributorDigits)||3)));
    const threshold=10**(digits-1);
    if(prev<threshold && next>=threshold && !bingoQualifiedContributors.has(`${i}:${id}`)){
      bingoQualifiedContributors.add(`${i}:${id}`);
      st.progress=Math.min(cfg.target,Number(st.progress||0)+1);
      if(st.progress>=cfg.target){st.progress=cfg.target;st.achieved=true;changed.push(i);}
    }
  }
  if(!changed.length){broadcast({type:"bingoState",state:bingoState});return;}
  const newLines=checkBingo();
  broadcast({type:"bingoAchieved",cells:changed,lines:newLines,state:bingoState,sounds:{mark:bingoSettings.markSoundUrl,bingo:bingoSettings.bingoSoundUrl,markVolume:bingoSettings.markSoundVolume,bingoVolume:bingoSettings.bingoSoundVolume}});
}
function bingoSnapshot(){return {settings:bingoSettings,state:bingoState,templates:bingoTemplates.map(x=>({id:x.id,name:x.name,size:x.size,cells:x.cells}))};}

const BIRTHDAY_AUDIO_PATH=path.join(__dirname,"birthday-audio.json");
function loadBirthdayAudio(){try{if(!fs.existsSync(BIRTHDAY_AUDIO_PATH)){fs.writeFileSync(BIRTHDAY_AUDIO_PATH,JSON.stringify({url:"",name:""},null,2));return {url:"",name:""};}const d=JSON.parse(fs.readFileSync(BIRTHDAY_AUDIO_PATH,"utf8"));return {url:String(d?.url||""),name:String(d?.name||"")};}catch{return {url:"",name:""};}}
let birthdayAudio=loadBirthdayAudio();
function saveBirthdayAudio(){fs.writeFileSync(BIRTHDAY_AUDIO_PATH,JSON.stringify(birthdayAudio,null,2));}

function isMacOS(){ return process.platform === "darwin"; }
function loadMacSettings(){
  try {
    if(!fs.existsSync(MAC_SETTINGS_PATH)) return {preventLidSleep:false};
    const d=JSON.parse(fs.readFileSync(MAC_SETTINGS_PATH,"utf8"));
    return {preventLidSleep:d?.preventLidSleep===true};
  } catch { return {preventLidSleep:false}; }
}
function saveMacSettings(v){ fs.writeFileSync(MAC_SETTINGS_PATH, JSON.stringify({preventLidSleep:!!v},null,2)); }
async function setMacLidSleepDisabled(enabled){
  if(!isMacOS()) throw new Error("この機能はMacでのみ利用できます。");
  const value=enabled?"1":"0";
  // AC電源時だけフタ閉じスリープを抑止。バッテリー時は通常通りスリープする。
  const script=`do shell script "pmset -a disablesleep ${value}" with administrator privileges`;
  await execFileAsync("osascript",["-e",script],{timeout:30000});
  macLidSleepDisabled=!!enabled;
  saveMacSettings(macLidSleepDisabled);
}
async function restoreMacLidSleep(){
  if(!isMacOS() || !macLidSleepDisabled) return;
  try {
    const script='do shell script "pmset -a disablesleep 0" with administrator privileges';
    await execFileAsync("osascript",["-e",script],{timeout:30000});
  } catch {}
  macLidSleepDisabled=false;
  saveMacSettings(false);
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, `http://${req.headers.host}`);
  if(u.pathname==="/countdown" && req.method==="GET"){const f=path.join(__dirname,"public","countdown.html");res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return fs.createReadStream(f).pipe(res);}
  if(u.pathname==="/timer" && req.method==="GET"){const f=path.join(__dirname,"public","timer.html");res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return fs.createReadStream(f).pipe(res);}
  if(u.pathname==="/timer-settings" && req.method==="GET"){res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});return res.end(JSON.stringify(timerSnapshot()));}
  if(u.pathname==="/timer-settings" && req.method==="POST"){readBody(req).then(d=>{try{timerSettings={...timerSettings,startSeconds:Math.max(0,Math.min(864000,Math.floor(Number(d?.startSeconds)||0))),addGifts:Array.isArray(d?.addGifts)?d.addGifts.map(x=>({coins:Math.max(1,Math.floor(Number(x?.coins??x?.coinValue)||1)),seconds:Math.max(1,Math.floor(Number(x?.seconds)||1)),enabled:x?.enabled!==false})).filter(x=>x.coins).slice(0,100):[],subtractGifts:Array.isArray(d?.subtractGifts)?d.subtractGifts.map(x=>({coins:Math.max(1,Math.floor(Number(x?.coins??x?.coinValue)||1)),seconds:Math.max(1,Math.floor(Number(x?.seconds)||1)),enabled:x?.enabled!==false})).filter(x=>x.coins).slice(0,100):[],addSoundUrl:String(d?.addSoundUrl||timerSettings.addSoundUrl||""),addSoundName:String(d?.addSoundName||timerSettings.addSoundName||""),subtractSoundUrl:String(d?.subtractSoundUrl||timerSettings.subtractSoundUrl||""),subtractSoundName:String(d?.subtractSoundName||timerSettings.subtractSoundName||""),endSoundUrl:String(d?.endSoundUrl||timerSettings.endSoundUrl||""),endSoundName:String(d?.endSoundName||timerSettings.endSoundName||""),instantZeroSoundUrl:String(d?.instantZeroSoundUrl||timerSettings.instantZeroSoundUrl||""),instantZeroSoundName:String(d?.instantZeroSoundName||timerSettings.instantZeroSoundName||""),instantZeroGifts:Array.isArray(d?.instantZeroGifts)?d.instantZeroGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift).slice(0,100):[],addSoundVolume:Math.max(0,Math.min(1,Number(d?.addSoundVolume??timerSettings.addSoundVolume??1))),subtractSoundVolume:Math.max(0,Math.min(1,Number(d?.subtractSoundVolume??timerSettings.subtractSoundVolume??1))),endSoundVolume:Math.max(0,Math.min(1,Number(d?.endSoundVolume??timerSettings.endSoundVolume??1))),instantZeroSoundVolume:Math.max(0,Math.min(1,Number(d?.instantZeroSoundVolume??timerSettings.instantZeroSoundVolume??1))),homeGiftVolume:Math.max(0,Math.min(1,Number(d?.homeGiftVolume??timerSettings.homeGiftVolume??1)))};saveTimerSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,...timerSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"タイマー設定を保存できませんでした"}));}});return;}
  if(u.pathname==="/timer-action" && req.method==="POST"){readBody(req).then(d=>{try{const a=String(d?.action||"");if(a==="start"||a==="reset")timerReset();else if(a==="add")timerAdjust(Math.max(1,Math.floor(Number(d?.seconds)||0)),String(d?.reason||"manualAdd"),{sender:String(d?.sender||"手動加算")});else if(a==="subtract")timerAdjust(-Math.max(1,Math.floor(Number(d?.seconds)||0)),String(d?.reason||"manualSubtract"),{sender:String(d?.sender||"手動減算")});else if(a==="stop"){clearTimerInstantZero();timerState.active=false;timerBroadcast();}else if(a==="instantZero")timerInstantZero(String(d?.sender||"即0テスト"));else throw new Error("不明な操作です");res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,...timerSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"タイマー操作に失敗しました"}));}});return;}
  if(u.pathname==="/timer-audio" && req.method==="POST"){readBody(req).then(d=>{try{const type=String(d?.type||""),data=String(d?.dataUrl||""),original=String(d?.fileName||"sound");if(type!=="add"&&type!=="subtract"&&type!=="end"&&type!=="instantZero")throw new Error("タイマーSEの種類が不正です");const m=data.match(/^data:audio\/([^;]+);base64,(.+)$/);if(!m)throw new Error("音声ファイルを読み込めませんでした");const ext=(path.extname(original).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";const file=`timer-${type}-${Date.now()}.${ext}`;fs.writeFileSync(path.join(COUNTDOWN_AUDIO_DIR,file),Buffer.from(m[2],"base64"));const url=`/custom-audio/countdown/${file}`;if(type==="add"){timerSettings.addSoundUrl=url;timerSettings.addSoundName=original}else if(type==="subtract"){timerSettings.subtractSoundUrl=url;timerSettings.subtractSoundName=original}else if(type==="end"){timerSettings.endSoundUrl=url;timerSettings.endSoundName=original}else{timerSettings.instantZeroSoundUrl=url;timerSettings.instantZeroSoundName=original}saveTimerSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,...timerSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}});return;}
  if(u.pathname==="/bingo" && req.method==="GET"){const f=path.join(__dirname,"public","bingo.html");res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return fs.createReadStream(f).pipe(res);}
  if(u.pathname==="/bingo-settings-ui" && req.method==="GET"){const f=path.join(__dirname,"public","bingo-settings.html");res.writeHead(200,{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store"});return fs.createReadStream(f).pipe(res);}
  if(u.pathname==="/bingo-settings" && req.method==="GET"){res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});return res.end(JSON.stringify(bingoSnapshot()));}
  if(u.pathname==="/bingo-settings" && req.method==="POST"){readBody(req).then(d=>{try{bingoSettings=normalizeBingoSettings(d);bingoSettings.updatedAt=new Date().toISOString();saveBingoSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,...bingoSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"ビンゴ設定を保存できませんでした"}));}});return;}
  if(u.pathname==="/bingo-action" && req.method==="POST"){readBody(req).then(d=>{try{const action=String(d?.action||"");if(action==="start"||action==="reset"){resetBingoState();}else if(action==="manualIncrement"){const i=Math.floor(Number(d?.index));if(!Number.isInteger(i)||i<0||i>=bingoState.cells.length)throw new Error("ビンゴのマス番号が不正です");const cfg=bingoSettings.cells[i],st=bingoState.cells[i];if(cfg.type!=="manual")throw new Error("手動加算は手動マスでのみ使用できます");if(!st.achieved){st.progress=Math.min(cfg.target,Number(st.progress||0)+1);if(st.progress>=cfg.target){st.progress=cfg.target;st.achieved=true;const newLines=checkBingo();broadcast({type:"bingoAchieved",cells:[i],lines:newLines,state:bingoState,sounds:{mark:bingoSettings.markSoundUrl,bingo:bingoSettings.bingoSoundUrl,markVolume:bingoSettings.markSoundVolume,bingoVolume:bingoSettings.bingoSoundVolume}});}else broadcast({type:"bingoState",state:bingoState});}}else if(action==="manual"){const i=Math.floor(Number(d?.index));if(!Number.isInteger(i)||i<0||i>=bingoState.cells.length)throw new Error("ビンゴのマス番号が不正です");const st=bingoState.cells[i];st.achieved=!st.achieved;st.progress=st.achieved?bingoSettings.cells[i].target:0;const newLines=checkBingo();broadcast({type:"bingoAchieved",cells:st.achieved?[i]:[],lines:newLines,state:bingoState,sounds:{mark:bingoSettings.markSoundUrl,bingo:bingoSettings.bingoSoundUrl,markVolume:bingoSettings.markSoundVolume,bingoVolume:bingoSettings.bingoSoundVolume}});}else if(action==="stop"){bingoState.active=false;broadcast({type:"bingoState",state:bingoState});}else throw new Error("不明な操作です");res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,...bingoSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"ビンゴ操作に失敗しました"}));}});return;}
  if(u.pathname==="/bingo-templates" && req.method==="POST"){readBody(req).then(d=>{try{const action=String(d?.action||"save");if(action==="save"){const name=String(d?.name||"").trim();if(!name)throw new Error("テンプレート名を入力してください");const cells=normalizeBingoSettings(d).cells;const size=normalizeBingoSettings(d).size;const item={id:`bingo-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,name:name.slice(0,40),size,cells};bingoTemplates=bingoTemplates.filter(x=>x.name!==item.name);bingoTemplates.push(item);saveBingoTemplates();}else if(action==="delete"){const id=String(d?.id||"");bingoTemplates=bingoTemplates.filter(x=>x.id!==id);saveBingoTemplates();}else throw new Error("不明な操作です");res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,templates:bingoTemplates}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"テンプレート操作に失敗しました"}));}});return;}

  if(u.pathname==="/countdown-settings" && req.method==="GET"){res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});return res.end(JSON.stringify(countdownSettings));}
  if(u.pathname==="/gift-catalog" && req.method==="GET"){
    const q=String(u.searchParams.get("q")||"");
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify({ok:true,query:q,count:giftCatalogSearch(q).length,gifts:giftCatalogSearch(q).slice(0,500)}));
  }
  if(u.pathname==="/gift-catalog" && req.method==="POST"){
    readBody(req).then(d=>{try{
      const internalName=String(d?.internalName||"").trim();
      const id=String(d?.id||"").trim();
      const jaNameInput=String(d?.jaName||"").trim();
      const existingIdx=giftCatalog.findIndex(x=>(id && String(x?.id||"")===id) || (internalName && normalizeCatalogText(x?.internalName)===normalizeCatalogText(internalName)) || (jaNameInput && normalizeCatalogText(x?.jaName)===normalizeCatalogText(jaNameInput)));
      if(existingIdx<0){
        if(!internalName && !id) throw new Error("ギフト内部名が取得できませんでした");
        const created=upsertGiftCatalog({id,internalName,jaName:jaNameInput,diamondCount:Number(d?.diamondCount)||0,source:"received"});
        if(!created) throw new Error("ギフト情報がありません");
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
        return res.end(JSON.stringify({ok:true,gift:created}));
      }
      const existing=giftCatalog[existingIdx];
      if(d?.action==="deleteGift"){
        const removed=giftCatalog.splice(existingIdx,1)[0];
        saveGiftCatalog();
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
        return res.end(JSON.stringify({ok:true,gift:removed}));
      }
      const jaName=String(d?.jaName||"").trim();
      const row=upsertGiftCatalog({id:String(existing?.id||id).trim(),internalName:String(existing?.internalName||internalName).trim(),jaName:jaName||String(existing?.jaName||"").trim(),diamondCount:Number(existing?.diamondCount)||0,source:existing?.source||"received"});
      if(!row) throw new Error("ギフト情報がありません");
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,gift:row}));
    }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}});return;
  }
  if(u.pathname==="/gift-pseudo-test" && req.method==="POST"){readBody(req).then(async d=>{try{
    // 擬似送信は必ず本番と同じ共通ギフトハンドラを経由する。
    // 既存LIVE接続中ならそのハンドラをそのまま利用し、未準備時だけ一度だけ構築する。
    for(let i=0;i<50 && typeof pseudoGiftHandler!=="function";i++){
      if(!liveSetupRunning) break;
      await new Promise(r=>setTimeout(r,100));
    }
    if(typeof pseudoGiftHandler!=="function" && !liveSetupRunning){
      const savedUsername=USERNAME;
      try { await setupTikTok("pseudo-test", {prepareOnly:true}); } finally { USERNAME=savedUsername; }
    }
    if(typeof pseudoGiftHandler!=="function") throw new Error("ギフト受信処理の準備ができていません。LIVE接続完了後にもう一度お試しください。");
    const gift=String(d?.gift||"").trim();
    const coins=Math.max(0,Math.floor(Number(d?.coins)||0));
    const count=Math.max(1,Math.min(10000,Math.floor(Number(d?.count)||1)));
    if(!gift) throw new Error("ギフト名を入力してください");
    const now=Date.now();
    const msgId=`pseudo-${now}-${Math.random().toString(36).slice(2)}`;
    const synthetic={
      gift:{name:gift,diamondCount:coins,type:count>1?1:0},
      groupId:count>1 ? `pseudo-${now}-${Math.random().toString(36).slice(2)}` : "",
      repeatCount:count, comboCount:count, groupCount:count, totalCount:count,
      repeatEnd:1, msgId,
      user:{id:"pseudo_test",nickname:"擬似送信テスト",uniqueId:"pseudo_test"},
      userDetails:{id:"pseudo_test",displayName:"擬似送信テスト",uniqueId:"pseudo_test"},
      common:{msgId},
      __pseudoTest:true
    };
    await Promise.resolve(pseudoGiftHandler(synthetic));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
    res.end(JSON.stringify({ok:true,gift,coins,count}));
  }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"擬似送信に失敗しました"}));}});return;}
  if(u.pathname==="/countdown-settings" && req.method==="POST"){readBody(req).then(d=>{try{const startValue=Math.max(0,Math.min(999999999999,Math.floor(Number(d.startValue))));const followAddValue=Math.max(0,Math.min(999999999999,Math.floor(Number(d.followAddValue)||0)));const likeThreshold=Math.max(1,Math.min(999999999999,Math.floor(Number(d.likeThreshold)||1000)));const likeAddValue=Math.max(0,Math.min(999999999999,Math.floor(Number(d.likeAddValue)||0)));const deductionGifts=Array.isArray(d.deductionGifts)?d.deductionGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift).slice(0,100):[];const voiceOnlyGifts=Array.isArray(d.voiceOnlyGifts)?d.voiceOnlyGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),url:String(x?.url||"").trim(),soundName:String(x?.soundName||x?.name||"SE").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift&&x.url).slice(0,100):[];const rouletteGifts=Array.isArray(d.rouletteGifts)?d.rouletteGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false,winRate:Math.max(0,Math.min(100,Number(x?.winRate??d?.rouletteWinRate??countdownSettings.rouletteWinRate??50)||0))})).filter(x=>x.gift).slice(0,100):[];const directMultiplierGifts=Array.isArray(d.directMultiplierGifts)?d.directMultiplierGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift).slice(0,100):[];const fixedAddGifts=Array.isArray(d.fixedAddGifts)?d.fixedAddGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false,addValue:Math.max(-999999999999,Math.min(999999999999,Math.floor(Number(x?.addValue)||0)))} )).filter(x=>x.gift&&x.addValue!==0).slice(0,100):[];const instantZeroGifts=Array.isArray(d.instantZeroGifts)?d.instantZeroGifts.map(x=>({gift:String(x?.gift||x?.name||"").trim(),enabled:x?.enabled!==false})).filter(x=>x.gift).slice(0,100):[];const rouletteWinRate=Math.max(0,Math.min(100,Number(d.rouletteWinRate??countdownSettings.rouletteWinRate??50)||0));const rouletteDurationSec=Math.max(1,Math.min(3600,Math.floor(Number(d.rouletteDurationSec??countdownSettings.rouletteDurationSec??30)||30)));const rouletteSoundUrl=String(d.rouletteSoundUrl??countdownSettings.rouletteSoundUrl??"").trim();const rouletteSoundName=String(d.rouletteSoundName??countdownSettings.rouletteSoundName??"").trim();const rouletteStopSoundUrl=String(d.rouletteStopSoundUrl??countdownSettings.rouletteStopSoundUrl??"").trim();const rouletteStopSoundName=String(d.rouletteStopSoundName??countdownSettings.rouletteStopSoundName??"").trim();const rouletteBgmUrl=String(d.rouletteBgmUrl??countdownSettings.rouletteBgmUrl??"").trim();const rouletteBgmName=String(d.rouletteBgmName??countdownSettings.rouletteBgmName??"").trim();const rouletteBgmVolume=Math.max(0,Math.min(1,Number(d.rouletteBgmVolume??countdownSettings.rouletteBgmVolume??0.7)));const rouletteSoundVolume=Math.max(0,Math.min(1,Number(d.rouletteSoundVolume??countdownSettings.rouletteSoundVolume??1)));const rouletteStopSoundVolume=Math.max(0,Math.min(1,Number(d.rouletteStopSoundVolume??countdownSettings.rouletteStopSoundVolume??1)));const addSoundVolume=Math.max(0,Math.min(1,Number(d.addSoundVolume??countdownSettings.addSoundVolume??1)));const deductSoundVolume=Math.max(0,Math.min(1,Number(d.deductSoundVolume??countdownSettings.deductSoundVolume??1)));const endSoundVolume=Math.max(0,Math.min(1,Number(d.endSoundVolume??countdownSettings.endSoundVolume??1)));const instantZeroSoundVolume=Math.max(0,Math.min(1,Number(d.instantZeroSoundVolume??countdownSettings.instantZeroSoundVolume??1)));const deductSoundUrl=String(d.deductSoundUrl||countdownSettings.deductSoundUrl||"").trim();const deductSoundName=String(d.deductSoundName||countdownSettings.deductSoundName||"deduct.wav").trim();const instantZeroSoundUrl=String(d.instantZeroSoundUrl??countdownSettings.instantZeroSoundUrl??"").trim();const instantZeroSoundName=String(d.instantZeroSoundName??countdownSettings.instantZeroSoundName??"").trim();if(!Number.isFinite(startValue))throw new Error("初期数字が不正です");countdownSettings={...countdownSettings,startValue,followAddValue,likeThreshold,likeAddValue,deductionGifts,voiceOnlyGifts,rouletteGifts,directMultiplierGifts,fixedAddGifts,instantZeroGifts,rouletteWinRate,rouletteDurationSec,rouletteSoundUrl,rouletteSoundName,rouletteStopSoundUrl,rouletteStopSoundName,rouletteBgmUrl,rouletteBgmName,rouletteBgmVolume,rouletteSoundVolume,rouletteStopSoundVolume,addSoundVolume,deductSoundVolume,endSoundVolume,instantZeroSoundVolume,deductSoundUrl,deductSoundName,instantZeroSoundUrl,instantZeroSoundName};saveCountdownSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,countdownSettings}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}});return;}
  if(u.pathname==="/countdown-voice-gift" && req.method==="POST"){readBody(req).then(d=>{try{const gift=String(d.gift||"").trim(),data=String(d.dataUrl||""),original=String(d.fileName||"sound");if(!gift)throw new Error("ギフト名を入力してください");const m=data.match(/^data:audio\/([^;]+);base64,(.+)$/);if(!m)throw new Error("音声ファイルを読み込めませんでした");const ext=(path.extname(original).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";const file=`voice-gift-${Date.now()}.${ext}`;fs.writeFileSync(path.join(COUNTDOWN_AUDIO_DIR,file),Buffer.from(m[2],"base64"));const url=`/custom-audio/countdown/${file}`;if(!Array.isArray(countdownSettings.voiceOnlyGifts))countdownSettings.voiceOnlyGifts=[];countdownSettings.voiceOnlyGifts=countdownSettings.voiceOnlyGifts.filter(x=>String(x?.gift||"")!==gift);countdownSettings.voiceOnlyGifts.push({gift,url,soundName:original,enabled:true});saveCountdownSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,countdownSettings}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}});return;}
  if(u.pathname==="/bingo-audio" && req.method==="POST"){readBody(req).then(d=>{try{
    const type=String(d?.type||""); const data=String(d?.dataUrl||""); const original=String(d?.fileName||"sound");
    if(type!=="bingoMark"&&type!=="bingoComplete") throw new Error("ビンゴSEの種類が不正です");
    const m=data.match(/^data:audio\/([^;]+);base64,(.+)$/); if(!m) throw new Error("音声ファイルを読み込めませんでした");
    const ext=(path.extname(original).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";
    const file=`${type}-${Date.now()}.${ext}`; fs.writeFileSync(path.join(BINGO_AUDIO_DIR,file),Buffer.from(m[2],"base64"));
    const url=`/custom-audio/countdown/${file}`;
    if(type==="bingoMark"){bingoSettings.markSoundUrl=url;bingoSettings.markSoundName=original;} else {bingoSettings.bingoSoundUrl=url;bingoSettings.bingoSoundName=original;}
    saveBingoSettings(); broadcast({type:"bingoAudioUpdated",settings:bingoSettings});
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}); res.end(JSON.stringify({ok:true,settings:bingoSettings}));
  }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"ビンゴSEを保存できませんでした"}));}});return;}
  if(u.pathname==="/countdown-audio" && req.method==="POST"){readBody(req).then(d=>{try{const type=String(d.type||""),data=String(d.dataUrl||""),original=String(d.fileName||"sound");if(type!=="add"&&type!=="deduct"&&type!=="end"&&type!=="roulette"&&type!=="rouletteStop"&&type!=="rouletteBgm"&&type!=="instantZero"&&type!=="bingoMark"&&type!=="bingoComplete")throw new Error("音声タイプが不正です");const m=data.match(/^data:audio\/([^;]+);base64,(.+)$/);if(!m)throw new Error("音声ファイルを読み込めませんでした");const ext=(path.extname(original).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";const file=`${type}-${Date.now()}.${ext}`;fs.writeFileSync(path.join(COUNTDOWN_AUDIO_DIR,file),Buffer.from(m[2],"base64"));const url=`/custom-audio/countdown/${file}`;if(type==="add"){countdownSettings.addSoundUrl=url;countdownSettings.addSoundName=original}else if(type==="deduct"){countdownSettings.deductSoundUrl=url;countdownSettings.deductSoundName=original}else if(type==="roulette"){countdownSettings.rouletteSoundUrl=url;countdownSettings.rouletteSoundName=original}else if(type==="rouletteStop"){countdownSettings.rouletteStopSoundUrl=url;countdownSettings.rouletteStopSoundName=original}else if(type==="rouletteBgm"){countdownSettings.rouletteBgmUrl=url;countdownSettings.rouletteBgmName=original}else if(type==="instantZero"){countdownSettings.instantZeroSoundUrl=url;countdownSettings.instantZeroSoundName=original}else if(type==="bingoMark"){bingoSettings.markSoundUrl=url;bingoSettings.markSoundName=original;saveBingoSettings()}else if(type==="bingoComplete"){bingoSettings.bingoSoundUrl=url;bingoSettings.bingoSoundName=original;saveBingoSettings()}else{countdownSettings.endSoundUrl=url;countdownSettings.endSoundName=original}saveCountdownSettings();res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,countdownSettings,bingoSettings:bingoSnapshot()}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}});return;}

  if (u.pathname === "/birthdays" && req.method === "GET") {
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(birthdaySnapshot()));
  }
  if (u.pathname === "/birthdays" && req.method === "POST") {
    readBody(req).then(d=>{try{
      const id=String(d?.id||"").trim(), name=String(d?.name||"誰か").trim()||"誰か";
      const month=Math.floor(Number(d?.month)||0), day=Math.floor(Number(d?.day)||0);
      const max=[31,29,31,30,31,30,31,31,30,31,30,31][month-1]||0;
      if(!id||month<1||month>12||day<1||day>max) throw new Error("誕生日が不正です");
      const prev=birthdayUsers[id]; birthdayUsers[id]={id,name,month,day,updatedAt:new Date().toISOString()}; saveBirthdays();
      log(`🎂 誕生日${prev?"変更":"登録"}（管理）：${name} (@${id}) → ${month}月${day}日`);
      broadcast({type:"birthdayRegistered",user:{id,name},birthday:{month,day},updated:!!prev,previous:prev?{month:prev.month,day:prev.day}:null,managed:true});
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,birthday:birthdayUsers[id]}));
    }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}}); return;
  }
  if (u.pathname === "/birthdays" && req.method === "DELETE") {
    readBody(req).then(d=>{
      const id=String(d?.id||"").trim();
      if(!id || !birthdayUsers[id]){res.writeHead(404,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({error:"登録が見つかりません"}));}
      const old=birthdayUsers[id]; delete birthdayUsers[id]; saveBirthdays();
      log(`🗑️ 誕生日削除：${old.name} (@${id}) ${old.month}月${old.day}日`);
      broadcast({type:"birthdayDeleted",user:{id,name:old.name},birthday:{month:old.month,day:old.day}});
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true}));
    }); return;
  }
  if (u.pathname === "/birthday-audio" && req.method === "POST") {
    readBody(req).then(d=>{try{
      const data=String(d?.dataUrl||""), original=String(d?.fileName||"birthday-se");
      const m=data.match(/^data:audio\/([^;]+);base64,(.+)$/); if(!m) throw new Error("音声ファイルを読み込めませんでした");
      const ext=(path.extname(original).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";
      const file=`birthday-${Date.now()}.${ext}`; fs.writeFileSync(path.join(BIRTHDAY_AUDIO_DIR,file),Buffer.from(m[2],"base64"));
      const url=`/custom-audio/birthday/${file}`; birthdayAudio={url,name:original}; saveBirthdayAudio();
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,birthdayAudio}));
    }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}}); return;
  }
  if (u.pathname === "/birthday-audio" && req.method === "GET") {
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}); return res.end(JSON.stringify(birthdayAudio));
  }

  if (u.pathname === "/events") {
    const eventRole = String(u.searchParams.get("role") || "main").toLowerCase();
    res.writeHead(200, {
      "Content-Type":"text/event-stream; charset=utf-8",
      "Cache-Control":"no-cache, no-transform",
      "Connection":"keep-alive"
    });
    res.write(`data: ${JSON.stringify({type:"connection", connected, status: connected ? "TikTok LIVE 接続済み" : "TikTok LIVE 接続中..."})}\n\n`);
    res.write(`data: ${JSON.stringify({type:"bingoState", state:bingoState})}\n\n`);
    browserClients.add(res);
    if (eventRole === "countdown") countdownClients.add(res);
    if (eventRole === "timer") timerClients.add(res);
    if (eventRole === "bingo") bingoClients.add(res);
    req.on("close", () => {
      browserClients.delete(res);
      countdownClients.delete(res);
      timerClients.delete(res);
      bingoClients.delete(res);
    });
    return;
  }

  if (u.pathname === "/dashboard" && req.method === "GET") {
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(dashboardSnapshot()));
  }

  if (u.pathname === "/glove-records" && req.method === "GET") {
    const q=String(u.searchParams.get("q")||"").trim();
    const rows=aggregateGloves(q);
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(rows));
  }

  if (u.pathname === "/glove-logs" && req.method === "GET") {
    expireGloves();
    const rows=loadGloveLogs();
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(rows));
  }

  if (u.pathname === "/glove-records" && req.method === "POST") {
    let body=""; req.on("data",c=>body+=c); req.on("end",()=>{
      try{
        expireGloves();
        const d=JSON.parse(body||"{}");
        const name=String(d.name||"").trim().slice(0,80);
        const uniqueId=String(d.uniqueId||"").replace(/^@/,"").trim().slice(0,80);
        const quantity=Math.max(1,Math.min(99,Number(d.quantity)||1));
        const note=String(d.note||"").replace(/\r?\n/g," ").trim().slice(0,160);
        if(!name){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"所有者名を入力してください"}));}
        const rows=loadGloveRecords();
        const now=Date.now();
        const item={id:`glove-${now}-${Math.random().toString(36).slice(2,8)}`,name,uniqueId,quantity,note,recordedAt:now,expiresAt:now+5*24*60*60*1000,username:USERNAME};
        rows.unshift(item); saveGloveRecords(rows); addGloveLog("add",name,quantity,note||"手動記録");
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true,item}));
      }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"入力を読み取れませんでした"}));}
    }); return;
  }

  if (u.pathname === "/glove-add" && req.method === "POST") {
    let body=""; req.on("data",c=>body+=c); req.on("end",()=>{
      try{
        expireGloves();
        const d=JSON.parse(body||"{}");
        const name=String(d.name||"").trim().slice(0,80);
        const uniqueId=String(d.uniqueId||"").replace(/^@/,"").trim().slice(0,80);
        const note=String(d.note||"").replace(/\r?\n/g," ").trim().slice(0,160);
        if(!name){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"所有者名が指定されていません"}));}
        const rows=loadGloveRecords();
        const now=Date.now();
        const item={id:`glove-${now}-${Math.random().toString(36).slice(2,8)}`,name,uniqueId,quantity:1,note:note||"＋1追加",recordedAt:now,expiresAt:now+5*24*60*60*1000,username:USERNAME};
        rows.unshift(item); saveGloveRecords(rows); addGloveLog("add",name,1,note||"＋1追加");
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true,item}));
      }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"グローブ追加に失敗しました"}));}
    }); return;
  }

  if (u.pathname === "/glove-use" && req.method === "POST") {
    let body=""; req.on("data",c=>body+=c); req.on("end",()=>{
      try{
        expireGloves();
        const d=JSON.parse(body||"{}"); const ownerKey=gloveOwnerKey(d.ownerKey||d.name);
        if(!ownerKey){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"所有者が指定されていません"}));}
        const rows=loadGloveRecords(); let target=null;
        for(const row of rows){if(gloveOwnerKey(row.name)===ownerKey && Number(row.quantity||0)>0 && (!target || Number(row.recordedAt||0)<Number(target.recordedAt||0))) target=row;}
        if(!target){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"この所有者のグローブは0個です"}));}
        target.quantity=Math.max(0,Number(target.quantity||0)-1); target.usedAt=Date.now(); saveGloveRecords(rows); addGloveLog("use",target.name,1,"使用");
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:true}));
      }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"使用記録に失敗しました"}));}
    }); return;
  }

  if (u.pathname.startsWith("/glove-owner/") && req.method === "DELETE") {
    const ownerKey=gloveOwnerKey(decodeURIComponent(u.pathname.slice("/glove-owner/".length)));
    const rows=loadGloveRecords(); const matched=rows.filter(x=>gloveOwnerKey(x.name)===ownerKey && Number(x.quantity||0)>0);
    if(!matched.length){res.writeHead(404,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"指定した所有者が見つかりません"}));}
    const qty=matched.reduce((n,x)=>n+Number(x.quantity||0),0); const name=matched[0].name;
    for(const row of rows){if(gloveOwnerKey(row.name)===ownerKey) row.quantity=0;}
    saveGloveRecords(rows); addGloveLog("use",name,qty,"全削除");
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname.startsWith("/glove-records/") && req.method === "DELETE") {
    const id=decodeURIComponent(u.pathname.slice("/glove-records/".length));
    const rows=loadGloveRecords(); const next=rows.filter(x=>String(x.id)!==String(id));
    if(next.length===rows.length){res.writeHead(404,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"指定した記録が見つかりません"}));}
    saveGloveRecords(next); res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname === "/battle-history" && req.method === "POST") {
    let body=""; req.on("data",c=>body+=c); req.on("end",()=>{
      try{
        const d=JSON.parse(body||"{}");
        const opponent=String(d.opponent||"").trim().slice(0,120);
        const result=["WIN","LOSE","DRAW"].includes(String(d.result||""))?String(d.result):"DRAW";
        const ownScore=d.ownScore===""||d.ownScore==null?null:Math.max(0,Number(d.ownScore)||0);
        const opponentScore=d.opponentScore===""||d.opponentScore==null?null:Math.max(0,Number(d.opponentScore)||0);
        const startedAt=Number(d.startedAt)||Date.now();
        const note=String(d.note||"").replace(/\r?\n/g," ").trim().slice(0,240);
        if(!opponent){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"対戦相手を入力してください"}));}
        const item={id:`manual-battle-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,username:USERNAME,startedAt,endedAt:startedAt,result,opponent,ownScore,opponentScore,note,manual:true};
        saveBattleHistoryItem(item);
        res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true,item}));
      }catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"入力を読み取れませんでした"}));}
    }); return;
  }

  if (u.pathname === "/battle-history" && req.method === "GET") {
    const q=String(u.searchParams.get("q")||"").trim().toLowerCase();
    let history=loadBattleHistory();
    if(q) history=history.filter(x=>String(x.username||"").toLowerCase().includes(q)||String(x.result||"").toLowerCase().includes(q)||String(x.opponent||"").toLowerCase().includes(q)||String(x.note||"").toLowerCase().includes(q)||(x.opponents||[]).some(o=>String(o.name||"").toLowerCase().includes(q)||String(o.uniqueId||"").toLowerCase().includes(q)));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(history));
  }

  if (u.pathname.startsWith("/battle-history/") && req.method === "DELETE") {
    const id=decodeURIComponent(u.pathname.slice("/battle-history/".length));
    const history=loadBattleHistory(); const next=history.filter(x=>String(x.id)!==String(id));
    if(next.length===history.length){res.writeHead(404,{"Content-Type":"application/json; charset=utf-8"});return res.end(JSON.stringify({ok:false,error:"指定したバトル履歴が見つかりません"}));}
    fs.writeFileSync(BATTLE_HISTORY_PATH,JSON.stringify(next,null,2));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname === "/battle-history" && req.method === "DELETE") {
    fs.writeFileSync(BATTLE_HISTORY_PATH,JSON.stringify([],null,2));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"}); return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname === "/live-listeners" && req.method === "GET") {
    const rows=[...liveListeners.values()].sort((a,b)=>Date.parse(b.lastActivity||0)-Date.parse(a.lastActivity||0));
    const users=rows.map(r=>{
      const h=listenerHistory[r.id]||{};
      const v=viewerStats.get(r.id)||{};
      const c=commentRanking.get(r.id)||{};
      const e=entryRanking.get(r.id)||{};
      return {id:r.id,name:r.name||h.name||v.name||c.name||e.name||"誰か",visitCount:Number(h.visitCount||h.visitCount===0?h.visitCount:1),firstSeen:h.firstSeen||null,lastSeen:h.lastSeen||r.lastActivity,lastActivity:r.lastActivity,lastComment:r.lastComment||"",likes:Number(v.likes||0),gifts:Number(v.gifts||0),giftValue:Number(v.giftValue||0),comments:Number(c.comments||0),entries:Number(e.entries||0),isNew:Number(h.visitCount||1)<=1};
    });
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify({ok:true,users,count:users.length,startedAt:liveStartedAt}));
  }

  if (u.pathname === "/listener-profile" && req.method === "GET") {const id=String(u.searchParams.get("id")||"").trim();const h=listenerHistory[id]||{};const p=getListenerProfile(id,h.name||"誰か");res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});return res.end(JSON.stringify({ok:true,profile:p||null}));}
  if (u.pathname === "/listener-profile" && req.method === "POST") {let body="";req.on("data",c=>body+=c);req.on("end",()=>{try{const d=JSON.parse(body||"{}");const id=String(d.id||"").trim();const name=String(d.name||"").trim();if(!id)throw new Error("id required");const fields=["name","nickname","gender","genderIdentity","birthDate","birthday","age","birthplace","residence","job","maritalStatus","children","collab","notes"];for(const f of fields)if(Object.prototype.hasOwnProperty.call(d,f))saveProfileField(id,name,f,d[f],"manual");res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});res.end(JSON.stringify({ok:true,profile:getListenerProfile(id,name)}));}catch(e){res.writeHead(400,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:false,error:e.message||String(e)}));}});return;}

  if (u.pathname === "/listener-history" && req.method === "GET") {
    const q=String(u.searchParams.get("q")||"").trim().toLowerCase();
    const id=String(u.searchParams.get("id")||"").trim();
    const all=listenerHistorySnapshot();
    if(id){
      const x=all.find(v=>String(v.id)===id || String(v.name||"").toLowerCase()===id.toLowerCase());
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
      return res.end(JSON.stringify({ok:true,user:x||null}));
    }
    let users=all;
    if(q) users=users.filter(x=>String(x.name||"").toLowerCase().includes(q)||String(x.id||"").toLowerCase().includes(q));
    users=users.map(({days,comments,...x})=>x).sort((a,b)=>Number(b.lastSeen?Date.parse(b.lastSeen):0)-Number(a.lastSeen?Date.parse(a.lastSeen):0));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify({ok:true,users,count:users.length}));
  }

  if (u.pathname === "/live-history" && req.method === "GET") {
    const history=loadLiveHistory();
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify(history));
  }

  if (u.pathname === "/live-end" && req.method === "POST") {
    try {
      const saved = saveLiveHistoryItem();
      if (!saved) {
        res.writeHead(400, {"Content-Type":"application/json; charset=utf-8"});
        return res.end(JSON.stringify({ok:false,error:"保存できるLIVEデータがありません"}));
      }
      broadcast({type:"liveHistorySaved"});
      log(`🏁 LIVE終了：@${USERNAME} の統計・ランキングを保存しました`);
      const client = activeTikTokClient;
      connected = false;
      if (client) { try { await client.disconnect?.(); } catch {} }
      activeTikTokClient = null;
      broadcast({type:"connection",connected:false,status:"LIVE終了・履歴保存済み"});
      resetDashboardStats();
      scheduleDashboardBroadcast();
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true,saved:true}));
    } catch (e) {
      res.writeHead(500,{"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:false,error:e?.message||String(e)}));
    }
  }

  if (u.pathname.startsWith("/live-history/") && req.method === "DELETE") {
    const historyId = decodeURIComponent(u.pathname.slice("/live-history/".length));
    const history = loadLiveHistory();
    const next = history.filter(x => String(x.id) !== String(historyId));
    if (next.length === history.length) {
      res.writeHead(404,{"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:false,error:"指定したLIVE履歴が見つかりません"}));
    }
    fs.writeFileSync(LIVE_HISTORY_PATH,JSON.stringify(next,null,2));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname === "/live-history" && req.method === "DELETE") {
    fs.writeFileSync(LIVE_HISTORY_PATH,JSON.stringify([],null,2));
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify({ok:true}));
  }

  if (u.pathname === "/like-ranking" && req.method === "GET") {
    const ranking = [...likeRanking.values()]
      .sort((a, b) => b.likes - a.likes || a.name.localeCompare(b.name, "ja"))
      .slice(0, 100)
      .map((x, i) => ({ rank: i + 1, ...x }));
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8", "Cache-Control":"no-store"});
    return res.end(JSON.stringify({
      totalLikes: liveLikeTotal,
      viewers: likeRanking.size,
      ranking
    }));
  }

  if (u.pathname === "/voicevox/status" && req.method === "GET") {
    const base = String(u.searchParams.get("url") || VOICEVOX_DEFAULT_URL).replace(/\/+$/,"");
    try {
      const rr = await fetch(base + "/speakers");
      if (!rr.ok) throw new Error(`VOICEVOX HTTP ${rr.status}`);
      const speakers = await rr.json();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true,url:base,speakers}));
    } catch (e) {
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:false,url:base,error:e.message}));
    }
  }

  if (u.pathname === "/voicevox/synthesize" && req.method === "POST") {
    readBody(req).then(async d => {
      const base = String(d.url || VOICEVOX_DEFAULT_URL).replace(/\/+$/,"");
      const text = String(d.text || "").trim();
      const speaker = Number(d.speaker);
      if (!text) throw new Error("読み上げる文章がありません");
      if (!Number.isFinite(speaker)) throw new Error("VOICEVOXの声が選択されていません");
      const qurl = base + "/audio_query?speaker=" + encodeURIComponent(String(speaker)) + "&text=" + encodeURIComponent(text);
      const qr = await fetch(qurl, {method:"POST"});
      if (!qr.ok) throw new Error(`audio_query HTTP ${qr.status}`);
      const query = await qr.json();
      const sr = await fetch(base + "/synthesis?speaker=" + encodeURIComponent(String(speaker)), {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify(query)
      });
      if (!sr.ok) throw new Error(`synthesis HTTP ${sr.status}`);
      const ab = await sr.arrayBuffer();
      res.writeHead(200, {"Content-Type":"audio/wav","Cache-Control":"no-store"});
      res.end(Buffer.from(ab));
    }).catch(e => {
      res.writeHead(500, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({error:e.message}));
    });
    return;
  }

  if (u.pathname === "/tiktok-id" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify({username: USERNAME, connected}));
  }

  if (u.pathname === "/tiktok-id" && req.method === "POST") {
    readBody(req).then(async d => {
      const username=String(d.username || "").replace(/^@/, "").trim();
      if (!/^[A-Za-z0-9._-]{2,50}$/.test(username)) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"TikTok IDを正しく入力してください（@は付けてもOK）"}));
      }
      USERNAME=username;
      OWN_USER_ID=""; OWN_UNIQUE_ID=USERNAME;
      saveTikTokUsername(USERNAME);
      connected=false;
      broadcast({type:"connection",connected:false,status:`@${USERNAME} に接続中...`});
      log(`🎯 TikTok ID変更: @${USERNAME}`);
      setupTikTok(USERNAME);
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,username:USERNAME}));
    }).catch(e=>{res.writeHead(400);res.end(JSON.stringify({error:e.message}))});
    return;
  }

  if (u.pathname === "/profiles" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify({activeProfile, profileNames, profiles, socialConfig:activeSocialConfig()}));
  }

  if (u.pathname === "/profiles/select" && req.method === "POST") {
    readBody(req).then(d => {
      const id=String(d.profile||"").trim();
      if (!profiles[id]) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"ライブ設定が見つかりません"}));
      }
      activeProfile=id;
      if (!giftMemos[id]) giftMemos[id] = {};
      saveGiftMemos();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,activeProfile,profileNames,voiceConfig:activeVoiceConfig(),emoteConfig:activeEmoteConfig(),socialConfig:activeSocialConfig(),giftMemos:activeGiftMemos()}));
    }).catch(e=>{res.writeHead(400);res.end(JSON.stringify({error:e.message}))});
    return;
  }

  if (u.pathname === "/profiles/add" && req.method === "POST") {
    readBody(req).then(d => {
      const used = new Set(Object.keys(profiles));
      let n=1; while (used.has("live"+n)) n++;
      const id="live"+n;
      const name=String(d.name||`ライブ${n}`).trim().slice(0,40) || `ライブ${n}`;
      profiles[id]={};
      profileNames[id]=name;
      activeProfile=id;
      if(!emoteProfiles[id]) emoteProfiles[id]={};
      if(!socialProfiles[id]) socialProfiles[id]=normalizeSocialConfig({});
      if(!giftMemos[id]) giftMemos[id]={};
      saveProfiles(); saveProfileNames(); saveEmoteProfiles(); saveSocialProfiles(); saveGiftMemos();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,activeProfile,profileNames,profiles,voiceConfig:activeVoiceConfig(),socialConfig:activeSocialConfig()}));
    }).catch(e=>{res.writeHead(400);res.end(JSON.stringify({error:e.message}))});
    return;
  }

  if (u.pathname === "/profiles/delete" && req.method === "POST") {
    readBody(req).then(d => {
      const id=String(d.profile||"").trim();
      if (!profiles[id]) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"ライブ設定が見つかりません"}));
      }
      if (Object.keys(profiles).length<=1) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"最後の1つは削除できません"}));
      }
      delete profiles[id]; delete profileNames[id]; delete emoteProfiles[id]; delete socialProfiles[id]; delete giftMemos[id];
      if (activeProfile===id) activeProfile=Object.keys(profiles)[0];
      saveProfiles(); saveProfileNames(); saveEmoteProfiles(); saveSocialProfiles(); saveGiftMemos();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,activeProfile,profileNames,profiles,voiceConfig:activeVoiceConfig(),socialConfig:activeSocialConfig()}));
    }).catch(e=>{res.writeHead(400);res.end(JSON.stringify({error:e.message}))});
    return;
  }

  if (u.pathname === "/profiles/rename" && req.method === "POST") {
    readBody(req).then(d => {
      const id=String(d.profile||"").trim();
      const name=String(d.name||"").trim();
      if (!profiles[id] || !name) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"ライブ名を入力してください"}));
      }
      profileNames[id]=name.slice(0,40);
      saveProfileNames();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,profileNames}));
    }).catch(e=>{res.writeHead(400);res.end(JSON.stringify({error:e.message}))});
    return;
  }

  if (u.pathname === "/voice-memos" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify(activeGiftMemos()));
  }

  if (u.pathname === "/voice-memo" && req.method === "POST") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const memo = String(d.memo ?? "").replace(/\r?\n/g, " ").trim().slice(0, 120);
      const cfg = activeVoiceConfig();
      if (!gift || !cfg[gift]) {
        res.writeHead(404, {"Content-Type":"application/json; charset=utf-8"});
        return res.end(JSON.stringify({error:"ギフト設定が見つかりません"}));
      }
      if (!giftMemos[activeProfile]) giftMemos[activeProfile] = {};
      if (memo) giftMemos[activeProfile][gift] = memo;
      else delete giftMemos[activeProfile][gift];
      saveGiftMemos();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true,giftMemos:activeGiftMemos(),memo}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({error:e?.message || "メモの保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/gift-voice-every" && req.method === "GET") {
    const profile=String(u.searchParams.get("profile")||activeProfile);
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}); return res.end(JSON.stringify(giftVoiceEvery[profile]||{}));
  }
  if (u.pathname === "/gift-voice-every" && req.method === "POST") {
    readBody(req).then(d=>{try{const profile=String(d?.profile||activeProfile),gift=String(d?.gift||"").trim();if(!gift)throw new Error("ギフト名が必要です");const every=Math.max(1,Math.min(999999,Math.floor(Number(d?.every)||1)));const state=setGiftVoiceEvery(profile,gift,every);res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});res.end(JSON.stringify({ok:true,every:state.every,remainder:state.remainder,giftVoiceEvery:giftVoiceEvery[profile]||{}}));}catch(e){res.writeHead(400,{"Content-Type":"application/json"});res.end(JSON.stringify({error:e.message||"保存に失敗しました"}));}}); return;
  }

  if (u.pathname === "/voice-config/share-all" && req.method === "POST") {
    readBody(req).then(d => {
      try {
        const gift = giftInternalNameForSetting(String(d?.gift || "").trim());
        if (!gift) throw new Error("ギフト名が必要です");
        const source = activeVoiceConfig();
        const sounds = Array.isArray(source[gift]) ? source[gift] : [];
        if (!sounds.length) throw new Error("共有するギフトSEが見つかりません");
        const copied = sounds.map(x => ({
          url: String(x?.url || ""),
          name: String(x?.name || "sound"),
          volume: Math.max(0, Math.min(1, Number(x?.volume ?? 1))),
          enabled: x?.enabled !== false
        })).filter(x => x.url);
        if (!copied.length) throw new Error("共有できる音声がありません");

        const requested = Array.isArray(d?.targetProfiles) ? d.targetProfiles.map(x => String(x || "").trim()).filter(Boolean) : [];
        const targets = requested.length ? [...new Set(requested)].filter(id => Object.prototype.hasOwnProperty.call(profileNames, id) && id !== activeProfile).map(id => { if (!profiles[id]) profiles[id] = {}; return id; }) : [];
        if (!targets.length) throw new Error("コピー先のライブを1つ以上選択してください");
        for (const id of targets) profiles[id][gift] = copied.map(x => ({...x}));
        saveProfiles();
        res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
        res.end(JSON.stringify({ok:true,gift,sharedProfiles:targets,voiceConfig:activeVoiceConfig()}));
      } catch(e) {
        res.writeHead(400, {"Content-Type":"application/json; charset=utf-8"});
        res.end(JSON.stringify({error:e?.message || "他ライブ共有に失敗しました"}));
      }
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "他ライブ共有に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/voice-config" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify(activeVoiceConfig()));
  }

  if (u.pathname === "/voice-config" && req.method === "POST") {
    readBody(req).then(d => {
      const giftInput = String(d.gift || "").trim();
      const gift = giftInternalNameForSetting(giftInput);
      const data = String(d.dataUrl || "");
      const fileName = String(d.fileName || "sound");
      if (!gift || !data.startsWith("data:audio/")) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"ギフト名と音声ファイルが必要です"}));
      }
      const match = data.match(/^data:audio\/([^;]+);base64,(.+)$/);
      if (!match) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声ファイルを読み込めませんでした"}));
      }
      const ext = (path.extname(fileName).replace(".","").toLowerCase() || "wav")
        .replace(/[^a-z0-9]/g, "").slice(0,8) || "wav";
      const safeGift = gift.replace(/[^a-zA-Z0-9ぁ-んァ-ヶ一-龯_-]/g, "_").slice(0,50);
      const file = `voice-${Date.now()}-${Math.random().toString(36).slice(2,8)}-${safeGift}.${ext}`;
      fs.writeFileSync(path.join(AUDIO_DIR, file), Buffer.from(match[2], "base64"));
      const url = `/custom-audio/gifts/${file}`;
      if (!profiles[activeProfile][gift]) profiles[activeProfile][gift] = [];
      profiles[activeProfile][gift].push({url, name:fileName, volume:1, enabled:true});
      saveProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true, voiceConfig:activeVoiceConfig()}));
    }).catch(e => {
      res.writeHead(500, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/voice-config/rename" && req.method === "POST") {
    readBody(req).then(d => {
      const oldGift = String(d.oldGift || "").trim();
      const newGift = String(d.newGift || "").trim();
      const cfg = activeVoiceConfig();
      if (!oldGift || !newGift) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"変更前と変更後のギフト名が必要です"}));
      }
      if (!cfg[oldGift]) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"変更前のギフト設定が見つかりません"}));
      }
      if (oldGift !== newGift && cfg[newGift]) {
        res.writeHead(409, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"そのギフト名はすでに設定されています"}));
      }
      if (oldGift !== newGift) {
        cfg[newGift] = cfg[oldGift];
        delete cfg[oldGift];
        const memos = activeGiftMemos();
        if (Object.prototype.hasOwnProperty.call(memos, oldGift)) {
          memos[newGift] = memos[oldGift];
          delete memos[oldGift];
          giftMemos[activeProfile] = memos;
          saveGiftMemos();
        }
        saveProfiles();
      }
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,voiceConfig:activeVoiceConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "ギフト名変更に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/voice-config" && req.method === "DELETE") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const url = String(d.url || "");
      const cfg=activeVoiceConfig();
      if (cfg[gift]) {
        const target = cfg[gift].find(x => x.url === url);
        cfg[gift] = cfg[gift].filter(x => x.url !== url);
        if (target?.url?.startsWith("/custom-audio/gifts/")) {
          const filePath = path.join(AUDIO_DIR, path.basename(target.url));
          try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
        }
        if (!cfg[gift].length) delete cfg[gift];
        saveProfiles();
      }
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true, voiceConfig:activeVoiceConfig()}));
    });
    return;
  }

  if (u.pathname === "/voice-config/delete-gift" && req.method === "POST") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const cfg = activeVoiceConfig();
      if (!gift || !cfg[gift]) {
        res.writeHead(404, {"Content-Type":"application/json; charset=utf-8"});
        return res.end(JSON.stringify({error:"削除するギフト音声が見つかりません"}));
      }
      const sounds = Array.isArray(cfg[gift]) ? cfg[gift] : [];
      for (const sound of sounds) {
        if (sound?.url?.startsWith("/custom-audio/gifts/")) {
          const filePath = path.join(AUDIO_DIR, path.basename(sound.url));
          try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
        }
      }
      delete cfg[gift];
      saveProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true, voiceConfig:activeVoiceConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({error:e?.message || "ギフト音声の削除に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/emote-config" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify(activeEmoteConfig()));
  }

  if (u.pathname === "/emote-config" && req.method === "POST") {
    readBody(req).then(d => {
      const emoteId=String(d.emoteId||"").trim();
      const data=String(d.dataUrl||"");
      const fileName=String(d.fileName||"sound");
      if(!emoteId || !data.startsWith("data:audio/")){
        res.writeHead(400,{"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"エモートIDと音声ファイルが必要です"}));
      }
      const match=data.match(/^data:audio\/([^;]+);base64,(.+)$/);
      if(!match){
        res.writeHead(400,{"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声ファイルを読み込めませんでした"}));
      }
      const ext=(path.extname(fileName).replace(".","").toLowerCase()||"wav").replace(/[^a-z0-9]/g,"").slice(0,8)||"wav";
      const safe=emoteId.replace(/[^a-zA-Z0-9_-]/g,"_").slice(0,60);
      const file=`emote-${Date.now()}-${Math.random().toString(36).slice(2,8)}-${safe}.${ext}`;
      fs.writeFileSync(path.join(AUDIO_DIR,file),Buffer.from(match[2],"base64"));
      const url=`/custom-audio/gifts/${file}`;
      if(!emoteProfiles[activeProfile]) emoteProfiles[activeProfile]={};
      if(!emoteProfiles[activeProfile][emoteId]) emoteProfiles[activeProfile][emoteId]=[];
      emoteProfiles[activeProfile][emoteId].push({url,name:fileName,volume:1});
      saveEmoteProfiles();
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true,emoteConfig:activeEmoteConfig()}));
    }).catch(e=>{res.writeHead(500);res.end(JSON.stringify({error:e.message||"保存に失敗しました"}))});
    return;
  }

  if (u.pathname === "/emote-config" && req.method === "DELETE") {
    readBody(req).then(d=>{
      const emoteId=String(d.emoteId||"").trim(), url=String(d.url||"");
      const cfg=activeEmoteConfig();
      if(cfg[emoteId]){
        cfg[emoteId]=cfg[emoteId].filter(x=>x.url!==url);
        if(!cfg[emoteId].length) delete cfg[emoteId];
        saveEmoteProfiles();
      }
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,emoteConfig:activeEmoteConfig()}));
    });
    return;
  }

  if (u.pathname === "/emote-volume" && req.method === "POST") {
    readBody(req).then(d=>{
      const emoteId=String(d.emoteId||"").trim(), url=String(d.url||"");
      const volume=Math.max(0,Math.min(1,Number(d.volume??1)));
      const cfg=activeEmoteConfig();
      const item=(cfg[emoteId]||[]).find(x=>x.url===url);
      if(item){item.volume=volume;saveEmoteProfiles();}
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,emoteConfig:activeEmoteConfig()}));
    });
    return;
  }

  if (u.pathname === "/social-config" && req.method === "GET") {
    res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
    return res.end(JSON.stringify(activeSocialConfig()));
  }

  if (u.pathname === "/social-config" && req.method === "POST") {
    readBody(req).then(d => {
      const cfg = activeSocialConfig();
      const threshold = Number(d.likeThreshold);
      if (d.likeThreshold !== undefined && (!Number.isFinite(threshold) || threshold < 1)) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"いいね到達数は1以上の数字にしてください"}));
      }
      cfg.likeThreshold = Math.max(1, Math.floor(threshold || cfg.likeThreshold || 1000));
      socialProfiles[activeProfile] = normalizeSocialConfig(cfg);
      saveSocialProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      return res.end(JSON.stringify({ok:true,socialConfig:activeSocialConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "設定保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/social-config/audio" && req.method === "POST") {
    readBody(req).then(d => {
      const type = d.type === "follow" ? "follow" : "like";
      const data = String(d.dataUrl || "");
      const fileName = String(d.fileName || "sound");
      if (!data.startsWith("data:audio/")) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声ファイルが必要です"}));
      }
      const match = data.match(/^data:audio\/([^;]+);base64,(.+)$/);
      if (!match) {
        res.writeHead(400, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声ファイルを読み込めませんでした"}));
      }
      const ext = (path.extname(fileName).replace(".","").toLowerCase() || "wav").replace(/[^a-z0-9]/g,"").slice(0,8) || "wav";
      const safe = type === "follow" ? "follow" : "like";
      const file = `social-${safe}-${Date.now()}-${Math.random().toString(36).slice(2,8)}.${ext}`;
      fs.writeFileSync(path.join(AUDIO_DIR,file), Buffer.from(match[2], "base64"));
      const url = `/custom-audio/gifts/${file}`;
      const cfg = activeSocialConfig();
      const key = type === "follow" ? "followSounds" : "likeSounds";
      cfg[key].push({url,name:fileName,volume:1});
      socialProfiles[activeProfile] = normalizeSocialConfig(cfg);
      saveSocialProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,socialConfig:activeSocialConfig()}));
    }).catch(e => {
      res.writeHead(500, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/social-config/audio" && req.method === "DELETE") {
    readBody(req).then(d => {
      const type = d.type === "follow" ? "follow" : "like";
      const url = String(d.url || "");
      const cfg = activeSocialConfig();
      const key = type === "follow" ? "followSounds" : "likeSounds";
      cfg[key] = (cfg[key] || []).filter(x => x.url !== url);
      socialProfiles[activeProfile] = normalizeSocialConfig(cfg);
      saveSocialProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,socialConfig:activeSocialConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "削除に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/social-config/audio-enabled" && req.method === "POST") {
    readBody(req).then(d => {
      const type = d.type === "follow" ? "follow" : "like";
      const url = String(d.url || "");
      const cfg = activeSocialConfig();
      const key = type === "follow" ? "followSounds" : "likeSounds";
      const item = (cfg[key] || []).find(x => x.url === url);
      if (!item) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声が見つかりません"}));
      }
      item.enabled = d.enabled !== false;
      socialProfiles[activeProfile] = normalizeSocialConfig(cfg);
      saveSocialProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,socialConfig:activeSocialConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "再生設定の保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/social-config/audio-volume" && req.method === "POST") {
    readBody(req).then(d => {
      const type = d.type === "follow" ? "follow" : "like";
      const url = String(d.url || "");
      const volume = Math.max(0, Math.min(1, Number(d.volume ?? 1)));
      const cfg = activeSocialConfig();
      const key = type === "follow" ? "followSounds" : "likeSounds";
      const item = (cfg[key] || []).find(x => x.url === url);
      if (!item) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声が見つかりません"}));
      }
      item.volume = volume;
      socialProfiles[activeProfile] = normalizeSocialConfig(cfg);
      saveSocialProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true,socialConfig:activeSocialConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "音量保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/voice-enabled" && req.method === "POST") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const url = String(d.url || "");
      const sounds = activeVoiceConfig()[gift];
      const item = Array.isArray(sounds) ? sounds.find(x => x.url === url) : null;
      if (!item) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声が見つかりません"}));
      }
      item.enabled = d.enabled !== false;
      saveProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true, voiceConfig:activeVoiceConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "再生設定の保存に失敗しました"}));
    });
    return;
  }

  if (u.pathname === "/voice-volume" && req.method === "POST") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const url = String(d.url || "");
      const volume = Math.max(0, Math.min(1, Number(d.volume ?? 1)));
      const sounds = activeVoiceConfig()[gift];
      const item = Array.isArray(sounds) ? sounds.find(x => x.url === url) : null;
      if (!item) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"音声が見つかりません"}));
      }
      item.volume = volume;
      saveProfiles();
      res.writeHead(200, {"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({ok:true, voiceConfig:activeVoiceConfig()}));
    }).catch(e => {
      res.writeHead(400, {"Content-Type":"application/json"});
      res.end(JSON.stringify({error:e?.message || "音量保存に失敗しました"}));
    });
    return;
  }


  if (u.pathname === "/mac-settings" && req.method === "GET") {
    const saved=loadMacSettings();
    res.writeHead(200,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"});
    return res.end(JSON.stringify({supported:isMacOS(),preventLidSleep:macLidSleepDisabled}));
  }

  if (u.pathname === "/mac-settings" && req.method === "POST") {
    readBody(req).then(async d=>{
      const enabled=d?.preventLidSleep===true;
      await setMacLidSleepDisabled(enabled);
      res.writeHead(200,{"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({supported:true,preventLidSleep:enabled}));
    }).catch(err=>{
      res.writeHead(500,{"Content-Type":"application/json; charset=utf-8"});
      res.end(JSON.stringify({error:String(err?.message||err||"設定に失敗しました")}));
    });
    return;
  }

  if (u.pathname === "/voice-test" && req.method === "POST") {
    readBody(req).then(d => {
      const gift = String(d.gift || "").trim();
      const sounds = (Array.isArray(activeVoiceConfig()[gift]) ? activeVoiceConfig()[gift] : []).filter(x => x?.enabled !== false);
      if (!sounds.length) {
        res.writeHead(404, {"Content-Type":"application/json"});
        return res.end(JSON.stringify({error:"このギフトに音声が設定されていません"}));
      }
      const chosen = sounds[Math.floor(Math.random() * sounds.length)];
      broadcast({type:"giftVoice", gift, sender:"テスト", url:chosen.url, soundName:chosen.name || "sound", volume:Number(chosen.volume ?? 1)});
      res.writeHead(204); return res.end();
    }).catch(() => {res.writeHead(400);res.end();});
    return;
  }

  serveStatic(req, res);
});

let listenRetryCount = 0;
function startHttpServer(){
  const onListening = () => {
    console.log("Kaito Gift Voice Tool v1.5.25");
    console.log(`ブラウザ: http://localhost:${PORT}`);
    console.log(`待受: http://${HOST}:${PORT}`);
    console.log("ギフト音声専用・キュー再生モード");
    if (USERNAME) {
      setupTikTok(USERNAME);
    } else {
      console.log("TikTok ID未設定：ブラウザでIDを入力して「接続」を押してください。");
    }
  };
  const onError = (err) => {
    if (err?.code === "EADDRINUSE" && listenRetryCount < 5) {
      listenRetryCount++;
      log(`⚠️ ポート${PORT}が使用中です。${listenRetryCount}/5回目の再試行をします`);
      setTimeout(() => startHttpServer(), 1000);
      return;
    }
    console.error("❌ HTTPサーバー起動失敗:", err);
    console.error(`確認先: http://${HOST}:${PORT}`);
    process.exitCode = 1;
  };
  server.once("error", onError);
  server.listen(PORT, HOST, onListening);
}
process.on("SIGINT", async()=>{ await restoreMacLidSleep(); process.exit(0); });
process.on("SIGTERM", async()=>{ await restoreMacLidSleep(); process.exit(0); });
process.on("exit",()=>{ if(isMacOS() && macLidSleepDisabled){ try { require("node:child_process").execFileSync("pmset",["-c","disablesleep","0"]); } catch {} } });
startHttpServer();
