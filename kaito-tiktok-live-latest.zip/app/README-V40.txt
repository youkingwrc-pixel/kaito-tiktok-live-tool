V40 接続修正版

V39で発生していた
「ttwid: no ttwid cookie in response (status 200)」
への対策を追加しています。

PirateTokの通常のTikTokトップページからのttwid取得を優先し、
TikTokがHTTP 200を返してもttwid Cookieを付けない場合は
ByteDanceのunion/registerエンドポイントをフォールバックとして使用します。

既存のエモートprotobuf補正、ギフトSEキュー、カウントダウン中のSE二重再生対策などはV39から維持しています。

V41: fixed ttwid fallback patch runtime ReferenceError (resp is not defined). Fallback now builds error message without outer-template interpolation.


V42: カウントダウン中のギフト/いいね/フォローSEを専用キュー化。SEが重ならず、前のSE終了後に次を再生。倍タイムBGMのダッキングもキュー全体に対して維持。
