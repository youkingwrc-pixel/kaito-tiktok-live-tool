Kaito TikTok Live Tool - Windows

1. Open START-HERE.cmd.
2. If Node.js is missing, the launcher downloads and installs Node.js automatically.
3. The tool server opens in a separate black window. Keep that window open while using the tool.
4. Your existing app data files are kept in the app folder.

This launcher uses ASCII-only batch files to avoid Windows code-page problems.
