#!/bin/bash
cd "$(dirname "$0")"
clear
# 既に8787番ポートで古いサーバーが動いている場合は停止
OLD_PIDS=$(lsof -ti tcp:8787 2>/dev/null || true)
if [ -n "$OLD_PIDS" ]; then
  echo "既存のTikTokツールを停止しています..."
  kill $OLD_PIDS 2>/dev/null || true
  sleep 1
fi
echo "======================================"
echo "  Kaito TikTok ギフト音声ツール"
echo "======================================"
echo ""
echo "💻 PC: http://localhost:8787"
echo ""
echo "Node.js依存関係を確認しています..."
# ZIPにnode_modulesが含まれている場合はnpm installを実行しません。
# npm installはネットワーク待ちで止まることがあるため、必要な場合だけ実行します。
if [ -d "node_modules/piratetok-live-js" ] && [ -d "node_modules/playwright" ]; then
  echo "依存関係は準備済みです。npm installはスキップします。"
else
  echo "依存関係が不足しています。npm installを実行します..."
  npm install --no-audit --no-fund
  if [ $? -ne 0 ]; then
    echo ""
    echo "❌ npm installに失敗しました。ネット接続を確認してください。"
    read -n 1 -s -r -p "Enterで終了します..."
    echo ""
    exit 1
  fi
fi

npm start > server.log 2>&1 &
SERVER_PID=$!
cleanup(){
  echo ""
  echo "終了します..."
  kill "$SERVER_PID" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

echo ""
echo "======================================"
echo "💻 PC画面: http://localhost:8787"
echo "======================================"
echo ""
echo "この画面は閉じないでください。"
wait "$SERVER_PID"
