// 起動用エントリーポイント
// 実際のアプリ本体は app/server.mjs にあります。
// start.command は従来どおり、このファイルを npm start で起動します。
import './app/server.mjs';
