@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Kaito TikTok Live Tool

echo ==========================================
echo    Kaito TikTok Live Tool
echo ==========================================
echo.
echo Keep this window open while using the tool.
echo.

set "NODE_EXE="
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LocalAppData%\Programs\nodejs\node.exe" set "NODE_EXE=%LocalAppData%\Programs\nodejs\node.exe"
if not defined NODE_EXE for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"

if not defined NODE_EXE goto INSTALL_NODE

goto NODE_OK

:INSTALL_NODE
echo Node.js was not found.
echo Downloading and installing Node.js LTS...
echo.
set "NODE_MSI=%TEMP%\kaito-node.msi"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$u='https://nodejs.org/dist/v24.21.0/node-v24.21.0-x64.msi'; Invoke-WebRequest -UseBasicParsing -Uri $u -OutFile $env:NODE_MSI"
if errorlevel 1 goto NODE_DOWNLOAD_ERROR
if not exist "%NODE_MSI%" goto NODE_DOWNLOAD_ERROR

echo Starting Node.js installer...
msiexec.exe /i "%NODE_MSI%" /passive /norestart
if errorlevel 1 goto NODE_INSTALL_ERROR
del /q "%NODE_MSI%" >nul 2>&1
set "PATH=%ProgramFiles%\nodejs;%LocalAppData%\Programs\nodejs;%PATH%"
if exist "%ProgramFiles%\nodejs\node.exe" set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
if not defined NODE_EXE if exist "%LocalAppData%\Programs\nodejs\node.exe" set "NODE_EXE=%LocalAppData%\Programs\nodejs\node.exe"
if not defined NODE_EXE for /f "delims=" %%N in ('where.exe node.exe 2^>nul') do if not defined NODE_EXE set "NODE_EXE=%%N"
if not defined NODE_EXE goto NODE_INSTALL_ERROR

goto NODE_OK

:NODE_DOWNLOAD_ERROR
echo.
echo ERROR: Could not download Node.js.
echo Check your internet connection and try again.
pause
exit /b 1

:NODE_INSTALL_ERROR
echo.
echo ERROR: Node.js installation did not complete.
echo If Windows showed a permission prompt, choose Yes and try again.
pause
exit /b 1

:NODE_OK
for %%N in ("%NODE_EXE%") do set "NODE_DIR=%%~dpN"
set "PATH=%NODE_DIR%;%PATH%"
echo Node.js:
"%NODE_EXE%" --version
if errorlevel 1 goto NODE_RUN_ERROR

if not exist "node_modules\piratetok-live-js\package.json" goto INSTALL_PACKAGES
if not exist "node_modules\playwright\package.json" goto INSTALL_PACKAGES
goto PACKAGES_OK

:INSTALL_PACKAGES
echo.
echo Installing required packages...
if not exist "%NODE_DIR%npm.cmd" goto NPM_ERROR
call "%NODE_DIR%npm.cmd" install --no-audit --no-fund
if errorlevel 1 goto PACKAGE_ERROR

:PACKAGES_OK
echo.
echo Starting Kaito TikTok Live Tool...
echo.
start "Kaito TikTok Live Tool - Server" cmd /k ""%NODE_EXE%" "%~dp0server.mjs""
timeout /t 4 /nobreak >nul
start "" "http://127.0.0.1:8787"
echo.
echo Browser opened at http://127.0.0.1:8787
pause
exit /b 0

:NPM_ERROR
echo ERROR: npm.cmd was not found.
pause
exit /b 1

:PACKAGE_ERROR
echo ERROR: Package installation failed.
pause
exit /b 1

:NODE_RUN_ERROR
echo ERROR: Node.js could not be started.
pause
exit /b 1
